# AstroStat Academy — handoff

Design system + high-fidelity prototype of the AstroStat Academy marketing site.
Static files only: **no build step, no bundler, no framework install.** React and
Babel come from a CDN and JSX is transpiled in the browser at load time.

---

## Run it

```bash
npm install     # installs one dev dependency: `serve`
npm run dev     # → http://localhost:4321
```

Then open **http://localhost:4321** — `index.html` is a link index of every page.

A static server is **required**. The pages `fetch()` `assets/schools/data/schools.yaml`,
`participants.csv`, `assets/people/people.yml` and `explorations/world-110m.geojson`;
opening a file over `file://` fails on CORS and the page renders blank.

Any static server works if you'd rather not use npm:

```bash
python3 -m http.server 4321
npx --yes serve -l 4321 .
```

Filenames contain spaces (`Site Overview.html`). Follow the links from `index.html`
rather than typing paths, or percent-encode them (`site/Site%20Overview.html`).

Browser: current Chrome/Firefox/Safari. In-browser Babel logs a "precompile for
production" warning on every page — that is expected, not an error.

---

## What you're looking at

**`site/Site Overview.html` is the style ground truth.** It renders all six site
pages side by side on a pannable design canvas. If a change alters how that file
looks, the change is wrong. Everything else is downstream of it.

The visual system is called **Instrument Panel**: pure-black canvas, warm off-white
("bone") text, deep blue as the active/primary accent, crimson for past/legacy,
hairline panel borders with corner crosshairs, uppercase mono labels, and a
generative code-rain of Greek/maths glyphs behind the hero.

### Layout

```
styles.css              THE entry point. Every page links this one file.
                        @imports, in cascade order (the order is load-bearing):
colors_and_type.css       tokens — palette, type scale, radii, shadows, spacing
css/kit-chrome.css        page chrome, rails, buttons, chips, hex, modules, footer
css/kit-school.css        schools-page sections (planisphere, mission, curriculum)
css/kit-hero.css          hero panel / console
css/kit-terminal.css      personnel terminal (CRT readout)

components/PageHeader/  the one compiler-visible design-system component
                        (.jsx + .d.ts + .card.html — the convention to follow)

site/                   the pages
  Site Overview.html      ← ground truth, loads everything
  Home.html · School Page.html · People Page.html · Pages with hero.html
  site-kit.jsx            chrome components: SiteNav, SiteFooter, Corners, Rail, RailMatrix
  page-home.jsx · page-people.jsx · page-schools.jsx · page-detail.jsx

explorations/           still load-bearing despite the folder name:
  site-effects.jsx        CodeRainBG, HeroWidget, HeroControls, ParamSlider, AstroTerminal
  page-hero-options.jsx   HeroPanel, HeroConsole, PH_CTX
  school-options.jsx      schools-page sections + data derivation
  page-people-terminal.jsx  the personnel terminal (OptConsole et al.)
  design-canvas.jsx       the pan/zoom canvas shell used by the overview pages
  stat-viz.jsx            statistical mini-visualisations
  world-land.js · world-110m.geojson   coastlines for the planisphere
  *-options.html          dead exploration pages, safe to delete

assets/                 logo (bone + black), favicon, papers.json
  people/people.yml        SOURCE OF TRUTH for the roster (+ per-person .md and photos)
  schools/data/            schools.yaml + participants.csv

preview/                small spec cards for the design-system tab
```

### Load order matters

The entry pages load scripts in a fixed order because each module drops its
exports onto `window` (separate Babel scripts don't share scope):

```
design-canvas.jsx → site-effects.jsx → site-kit.jsx → school-options.jsx
→ page-*.jsx → page-people-terminal.jsx → page-hero-options.jsx
```

Reordering breaks references. Each module ends with
`Object.assign(window, { ... })` — that is the export mechanism.

---

## Conventions (see `AGENTS.md`)

1. **Page headers**: always `components/PageHeader`. Never hand-roll one, never
   substitute the generic `.as-eyebrow` / `.as-h1pg` / `.as-p` classes for one.
2. **Colour and type**: tokens from `colors_and_type.css` only —
   `--blue` `#0465ad`, `--red` `#8c0527`, `--bone`, `--ink`, `--teal`, their
   `*-rgb` triplets for alpha, and `--font-*`. Blue = active/current.
   Red = past/legacy.
3. **Roster data**: `assets/people/people.yml`.
4. **No emoji**, ever. Glyphs are typographic (→ ← ☾ ☼ ∩ 〜) or Greek/maths.

---

## Known debt

- **Components still live in `site/` and `explorations/`, not `components/`.**
  Only `PageHeader` is a real design-system component (`.jsx` + `.d.ts`, visible
  to the compiler). The chrome (`SiteNav`, `SiteFooter`, `Rail`, `Corners`), the
  effects, and the hero components should be promoted into `components/<Name>/`
  following the `PageHeader` pattern. This was the next planned step.
- **Off-palette hex values.** `#3b9be0` (the light blue on nearly every accent)
  and `#c8607a` (soft crimson) appear as literals in `css/kit-chrome.css`,
  `css/kit-hero.css` and `site-kit.jsx` but are **not** tokens in
  `colors_and_type.css`, so rule 2 above is violated by the kit itself. They are
  load-bearing for the look — if you tokenise them, keep the rendered value
  identical.
- **`ui_kits/website/` and `deploy/` are stale.** Both recreate an *older*
  version of the site (pill nav, light-theme toggle, rounded cards) and share no
  code with the current system. Nothing in `site/` loads them. Safe to delete.
- **`export/astrostat-site/`** — six frozen standalone HTML snapshots with the
  whole kit inlined into each file. Useful as a reference for a static deploy,
  but they do not track the kit. Regenerate rather than edit.
- **`_ds_bundle.js`, `_ds_manifest.json`, `_adherence.oxlintrc.json`** are
  generated artefacts. Some pages load `_ds_bundle.js` at runtime; do not
  hand-edit it.
- **`uploads/`** is a scratch drop folder (duplicate photos, pasted images).

## Editing rule that has been applied so far

Style moves were done **byte-identically** — CSS text lifted verbatim out of the
JS template literals into `css/*.css`, nothing reformatted or "improved", so the
render is unchanged. Keep that discipline when refactoring further: change
structure or change appearance, never both in one pass.
