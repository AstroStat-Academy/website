# AstroStat Academy — Design System

A design system for **AstroStat Academy**, an organisation that runs intensive
statistics schools and workshops for the astronomical community. The Academy
teaches modern machine learning and high-level statistical tooling to PhD
students and early-career researchers, and is expanding into **hackatons** and
**enterprise consulting**.

> "Astronomy generates petabytes of data. Making sense of it requires rigorous
> statistical thinking." — homepage mission copy

This folder is a self-contained kit: brand voice, colour + type tokens, visual
foundations, iconography notes, ready-to-use CSS variables, preview cards for
the Design System tab, and a high-fidelity UI kit recreating the marketing
website.

---

## Company & product context

| | |
|---|---|
| **Name** | AstroStat Academy |
| **Domain** | https://astrostat.academy/ |
| **What** | Statistics & machine-learning schools/workshops for astronomers |
| **Audience** | PhD students, postdocs, faculty/staff scientists; later, industry & institutions |
| **Tone** | Dark-academic, rigorous, quietly confident, scientific |
| **Roadmap** | Schools (live) → Hackatons (soon) → Consulting (soon) |

### Surfaces / products

There is **one shipping product today: the marketing website.** It is a static
Astro site with React "islands" for interactive pieces. Key surfaces:

- **Home** — animated hero (the "TitleDot" canvas: code-rain → live Gaussian
  histogram / AR(1) time-series with draggable mean & σ widgets), a hexagon
  honeycomb of the three activities, mission/goals cards, people CTA.
- **Schools** — listing with year/topic filters; per-school detail pages with
  lecturers, topics, a Plotly attendance chart, and an interest form.
- **Hackatons** / **Consulting** / **People** — "coming soon" placeholder pages.

The UI kit in `ui_kits/website/` recreates these.

### Sources reviewed

- **Codebase (read-only):** `academy-website-short/` — Astro 4 + React 18 +
  Tailwind CSS 3 + Plotly.js + React Hook Form, TypeScript throughout.
  - Design tokens: `src/styles/tokens.ts` (**source of truth for colour**)
  - Tailwind theme: `tailwind.config.mjs` (Inter font; palette mapped to colours)
  - Shell: `src/layouts/BaseLayout.astro`
  - Effects: `src/components/effects/{CodeRain,TitleDot,Typewriter,SpiralGalaxy}.tsx`
  - UI: `src/components/ui/{Nav,Footer,ThemeToggle}.tsx/.astro`
  - Schools: `src/components/schools/{SchoolCard.astro,SchoolFilter.tsx}`, `src/pages/schools/`
  - Charts/forms: `src/components/charts/AttendanceChart.tsx`, `src/components/forms/ApplicationForm.tsx`
  - Content: `src/content/schools/*.md` (real school copy, 2019–2026)
  - Brand mark: `public/favicon.svg`

> ⚠️ **Stale-asset note.** The codebase `README.md` and `favicon.svg` still
> reference an older theme (navy `#070d1a`, teal `#14b8a6`, blue `#3b82f6`).
> The live palette in `tokens.ts` has since moved to the blue/crimson/bone/black
> system documented below. **Trust `tokens.ts`, not the favicon or the old
> README.** The favicon should be recoloured to the new palette — flagged for
> the user.

---

## Content fundamentals

**Voice.** Institutional but human. The organisation speaks as **"we"**
("We help teams design analyses…", "We aim to raise statistical literacy…").
The reader is addressed as **"you / your"**, and the brand's single rallying
line uses the imperative: **"Take control of your statistics."**

**Register.** Academic and precise without being stuffy. Sentences are
declarative and confident. Mild aspiration is allowed ("today's large surveys
and tomorrow's petabyte telescopes") but never hype. No exclamation marks in
body copy; one is allowed in a success state ("Thank you!").

**Casing.**
- Headings & buttons: **sentence case** ("Our Mission", "Express Interest",
  "Submit Interest", "Meet our people →"). Title Case is used for proper product
  nouns ("Enterprise Consulting", "Schools & Workshops").
- Eyebrows / labels: **UPPERCASE** with wide tracking, often number-prefixed —
  `01 · MISSION`, `02 · GOALS`, `TRAINING`, `CONSULTING`.
- School editions use **Roman numerals**: "AstroStat School VII — Rome 2026".

**Punctuation.** Em-dashes (—) for asides and titles; en-dashes (–) for date and
number ranges ("27–31 July 2026"). Ellipsis "…" in placeholders ("Select…",
"Sending…"). Mid-sentence "and" lists are common.

**Emoji:** **none.** The brand never uses emoji. Where a glyph is needed it uses
typographic/unicode symbols (→ ← ☾ ☼ ∩ 〜) or Greek/maths characters.

**Examples (verbatim from the site):**
- Hero rotating taglines: "Advanced statistics. Taught and applied." /
  "High-level statistical training and expert consulting." / "The statistics
  support you need. Taught and delivered."
- Mission: "AstroStat Academy bridges the gap between modern statistics and
  observational astronomy through hands-on, expert-led schools…"
- CTA buttons: "Meet our people →", "Apply Now", "Submit Interest", "Get in touch".
- Status microcopy: "Past" / "Upcoming" / "Soon".
- Empty states: "No schools match your filters.", "To be announced."

---

## Visual foundations

**Overall vibe — "dark academic / quantitative".** Pure-black canvas, warm
off-white ("bone") text, two saturated primaries (a deep **blue** and a deep
**crimson**), and an ever-present animated **code-rain** of Greek letters and
maths glyphs falling in translucent crimson behind the content. The aesthetic
reads like a terminal-meets-observatory: scientific, a little nocturnal,
data-forward.

### Colour
- **Black-first.** The body background is pure black (`ink #000000`); content
  sits on it at `z-10` above the fixed code-rain canvas. A light theme exists
  (toggle), built on `bone #fbf6ec`.
- Palette is intentionally tiny: **blue, crimson, bone, ink, teal** — nothing
  else. See `colors_and_type.css` and the Colors cards.
- Blue is the primary action / link colour; crimson is reserved for the data
  motif (histograms, the code-rain glyphs, error text, the chart highlight bar);
  teal is a rare tertiary accent (hackatons).
- Colour is applied at low alpha constantly: `text-ink/70`, `border-ink/10`,
  `bg-blue/10`, `from-...to-blue/5`. Opacity tiers (`/85 /70 /65 /55 /45`) do
  the heavy lifting for hierarchy rather than many distinct greys.

### Type
- **Inter** (Google Fonts), weights 400/500/600/700 — the only UI typeface. No
  serif anywhere.
- **Monospace** (`ui-monospace`, system mono) is a deliberate motif: rotating
  taglines, large decorative numbers (`01`/`02`/`03`), the toggle labels, and
  all code-rain glyphs are mono. Mono carries the "quantitative" feel.
- Display headings are bold (700), tight leading; hero hits `text-7xl`. Eyebrows
  are `text-xs`, uppercase, `tracking-widest`.

### Backgrounds & imagery
- **No photography, no stock illustration.** All "imagery" is *generative
  canvas*: `CodeRain` (full-page), `TitleDot` (interactive histogram/time-series
  hero widget), `SpiralGalaxy`. Motifs are statistical: Gaussian curves,
  bar histograms, AR(1) time series, draggable mean/σ controls.
- Card surfaces use soft **diagonal gradients** (`bg-gradient-to-br
  from-white/85 via-bone to-blue/5`, or in dark mode `from-white/10 via-ink
  to-blue/10`) — never flat fills.
- Decorative hexagons use `clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50%
  100%, 0% 75%, 0% 25%)` (pointy-top) tiled as a honeycomb.

### Shape, radius, border
- **Radii:** pills (`rounded-full`) for nav, badges, buttons, chips, inputs;
  `rounded-2xl` (16px) for cards; `rounded-3xl` (24px) for large feature panels.
- **Borders:** hairline, low-alpha — `border border-ink/10` (light) /
  `border-white/10` (dark). Accent borders shift to `border-blue/30` on hover.

### Shadow / elevation
- Shadows are **large, soft, and tinted with the brand colour**, never neutral
  grey. Signature recipe: `shadow-[0_18px_50px_rgba(4,101,173,0.10)]` (blue) and
  `…rgba(140,5,39,0.08)` (crimson) for feature cards;
  `0_16px_40px_rgba(4,101,173,0.08)` for standard cards;
  `0_12px_30px_rgba(4,101,173,0.18)` for buttons.
- The floating nav and code-rain create depth instead of heavy borders.

### Transparency & blur
- The nav is a floating translucent pill: `bg-bone/85 backdrop-blur-md` (light) /
  `bg-ink/90` (dark). Blur is used sparingly — chrome that overlaps the code-rain.

### Motion
- **Code rain:** ~110 ms frame interval; glyphs fall and fade via a
  `destination-out` trail rather than repainting black.
- **Typewriter:** ~72 ms/char typing with random jitter, 28 ms/char delete,
  2.2 s pause after a phrase, blinking block cursor `█` on a 530 ms period.
- **Hover transitions:** `transition-all`, lifts of `-translate-y-0.5`, plus
  colour/border/shadow easing. Cards and buttons rise slightly; hex tiles
  `scale-[1.05]` over 300 ms.
- No bounce, no spring, no long flashy entrances — motion is restrained and
  functional. Respect `prefers-reduced-motion`.

### Hover / press states
- **Hover:** lift (`-translate-y-0.5`), border brightens to the accent
  (`hover:border-blue/30`), shadow deepens, text shifts toward blue
  (`group-hover:text-blue`). Solid buttons go `hover:bg-blue/90`.
- **Active nav item:** filled `bg-blue text-bone` pill.
- **Focus (inputs):** `focus:border-blue` + `focus:ring-2 focus:ring-blue/15`.
- No explicit shrink-on-press; the lift + colour change carries interaction.

### Layout
- Centred column, generous vertical rhythm (`py-16`/`py-24`/`py-32`),
  `max-w-6xl` for listings, `max-w-3xl`/`4xl` for prose, `px-4 sm:px-6` gutters.
- Sticky floating nav (`h-14`, `top-0`, `z-50`); fixed full-bleed code-rain at
  `z-0`; content at `z-10`. Footer is a hairline-topped bar.

See **VISUAL FOUNDATIONS** cards in the Design System tab and
`colors_and_type.css` for exact values.

---

## Iconography

AstroStat Academy has **no icon font and no bespoke icon set.** Iconography is
deliberately minimal and **typographic**:

- **Unicode glyphs as icons:** arrows `→` `←` (links/CTAs), `☾`/`☼` (theme
  toggle), `∩` (histogram view) and `〜` (time-series view) inside the hero
  widget. `█` is the typewriter cursor.
- **Greek letters & maths symbols** are the brand's signature decorative
  "iconography", raining behind every page:
  `αβγδεζηθικλμνξπρστφχψω ΛΦΨΩ Σ ∑ ∏ ∫ ∮ ∂ ∇ ∆ √ ∛ ∝ ∞ ≈ ≅ ≠ ≡ ≤ ≥ ± ∓ × ÷ ∀ ∃ ∈ ∉ ⊂ ⊃ ⊆ ∪ ∩ ∅ ∴ ∵ ⊕ ⊗ ⊙ ℓ ℏ ℝ ℕ ☉ ★ ✦` and digits `0–9`.
- **Large mono numerals** (`01`, `02`, `03`, Roman `VII`) act as visual anchors
  / counters more than decoration.
- **No emoji**, ever.
- **The primary brand asset is the logo** (`assets/logo.svg`, black) — a
  monogram **"A"** built from an observatory/easel form with an embedded **Σ**
  (sigma) and a telescope-pointer stroke; it fuses "astro" + "stat" into one
  mark. Use **`assets/logo-bone.svg`** (bone `#fbf6ec`) on dark surfaces and
  `assets/logo.svg` (black) on light. A logo + organisation-name lockup variant
  exists and should be added when supplied.
- A secondary `assets/favicon.svg` (telescope-aperture mark) also exists but is
  drawn in the *old* palette; prefer the logo above, and regenerate the favicon
  from it.

**Guidance when designing:** prefer a typographic/unicode arrow or maths glyph
over importing an icon library. If a UI genuinely needs line icons (e.g. a
future app), use a thin-stroke set (Lucide / Heroicons outline) at ~1.5px stroke
to match the favicon's stroke weight, and **flag the addition** — it is not in
the current brand.

---

## Index / manifest

Root files:

- **`README.md`** — this document (context, content, visual foundations, iconography).
- **`colors_and_type.css`** — CSS custom properties: raw palette, semantic
  colour roles, type scale, radii, shadows, spacing. Import this first.
- **`SKILL.md`** — Agent-Skill front-matter so this folder works in Claude Code.
- **`assets/`** — brand assets: `logo.svg` (black) + `logo-bone.svg` (bone, for
  dark surfaces) — the primary monogram mark; `favicon.svg` (legacy telescope mark).
- **`preview/`** — small HTML cards that populate the Design System tab
  (colours, type, spacing, shadows, components). Not meant to be shipped.
- **`ui_kits/website/`** — high-fidelity recreation of the marketing site
  (nav, hero, hex honeycomb, cards, school listing/detail, forms, footer) as
  modular JSX components + an interactive `index.html`. See its own README.

Start here: read this README, then `colors_and_type.css`, then open
`ui_kits/website/index.html` and the Design System tab.

## Components

- **PageHeader** — the default page header (panel frame, channel bar, mono kicker, display title, lede). Every page uses it; never hand-roll a header.
