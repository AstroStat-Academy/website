/* People — live from assets/people/people.yml + per-person .md files.
   Same source of truth as the website UI kit; edit those files, not this. */

const PP_BASE = '../assets/people';
const PP_ROLE_META = {
  councellors: { label: 'Councellors', eyebrow: '',    wide: true },
  lecturers:   { label: 'Lecturers',   eyebrow: 'red', wide: false },
  TAs:         { label: 'Teaching assistants', eyebrow: '', wide: false },
  advisors:    { label: 'Advisors',    eyebrow: 'red', wide: false },
};

function ppParseRoster(text) {
  const out = []; let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, '');
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) { cur = { role: sec[1], slugs: [] }; out.push(cur); return; }
    const it = line.match(/^\s*-\s*(.+?)\s*$/);
    if (it && cur) cur.slugs.push(it[1]);
  });
  return out;
}

function ppParsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = { links: {} }; let body = text;
  if (m) {
    body = m[2] || ''; let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s+/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1], val = kv[2].trim();
      if (key === 'links' && val === '') { inLinks = true; return; }
      if (inLinks && indented) { meta.links[key] = val; return; }
      inLinks = false; meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}

function ppInitials(name) {
  const c = name.replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return (c[0][0] + (c[c.length - 1][0] || '')).toUpperCase();
}

function PPAvatar({ person }) {
  const [failed, setFailed] = React.useState(false);
  const show = person.photoUrl && !failed;
  return (
    <span className="as-av" style={{ display: 'grid', placeItems: 'center', overflow: 'hidden',
      fontFamily: 'ui-monospace, monospace', fontWeight: 600, fontSize: 13, color: 'rgba(251,246,236,.7)' }}>
      {show ? (
        <img src={person.photoUrl} alt={person.name}
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          onError={() => setFailed(true)} />
      ) : ppInitials(person.name)}
    </span>
  );
}

function PPWideCard({ person }) {
  return (
    <div className="as-card" style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
      <PPAvatar person={person} />
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 16 }}>{person.name}</div>
        {person.affiliation && <div className="as-mono" style={{ fontSize: 11, color: 'rgba(251,246,236,.5)', margin: '4px 0 8px' }}>{person.affiliation}</div>}
        {person.title && <div className="as-chip">{person.title}</div>}
        {person.bio && <div className="as-p" style={{ fontSize: 13, marginTop: 8 }}>{person.bio}</div>}
      </div>
    </div>
  );
}

function PPCompactCard({ person }) {
  return (
    <div className="as-card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 8 }}>
      <PPAvatar person={person} />
      <div style={{ fontWeight: 600, fontSize: 14 }}>{person.name}</div>
      {person.affiliation && <div className="as-mono" style={{ fontSize: 10, color: 'rgba(251,246,236,.45)' }}>{person.affiliation}</div>}
    </div>
  );
}

async function ppLoad() {
  const roster = ppParseRoster(await fetch(`${PP_BASE}/people.yml`).then(r => { if (!r.ok) throw new Error('people.yml'); return r.text(); }));
  const sections = await Promise.all(roster.map(async ({ role, slugs }) => {
    const people = (await Promise.all(slugs.map(async slug => {
      try {
        const md = await fetch(`${PP_BASE}/${role}/${slug}.md`).then(r => { if (!r.ok) throw new Error(`${role}/${slug}.md`); return r.text(); });
        const p = ppParsePerson(md);
        if (!p.name) p.name = slug;
        p.photoUrl = `${PP_BASE}/${role}/${p.photo || slug + '.jpg'}`;
        return p;
      } catch (e) { console.warn('[people]', e.message); return null; }
    }))).filter(Boolean);
    const meta = PP_ROLE_META[role] || { label: role, eyebrow: '', wide: false };
    return { role, ...meta, people };
  }));
  return sections.filter(s => s.people.length);
}

/* The People page IS the personnel terminal: "Personnel terminal" head,
   "Select a name to open their file.", two-column name grid + CRT dossier.
   Implementation lives in explorations/page-people-terminal.jsx (OptConsole)
   so there is a single version — don't fork it here. */
function PagePeople() {
  return <OptConsole />;
}

/* Coming-soon template — Consulting (red) / Hackatons (blue). Two-primary system. */
function ComingSoon({ active, eyebrow, eyebrowClass, title, body, rain, link }) {
  return (
    <div className="as-page">
      <SiteNav active={active} />
      <div className="as-wrap">
        <div className="as-panel"><Corners />
          <div className="as-soon">
            <div className="as-rain"><CodeRainBG color={rain} alpha={0.4} /></div>
            <div className="as-soon-in">
              <span className={'as-eyebrow ' + eyebrowClass}>{eyebrow}</span>
              <h1 className="as-h1pg" style={{ marginTop: 14 }}>{title}</h1>
              <p className="as-p" style={{ margin: '14px auto 0' }}>{body}</p>
              <div style={{ marginTop: 26 }}><button className={'as-btn ' + (eyebrowClass === 'red' ? 'red' : 'ghost')}>{link} ✉</button></div>
              <div className="as-mono" style={{ fontSize: 11, letterSpacing: '.2em', textTransform: 'uppercase', color: 'rgba(251,246,236,.35)', marginTop: 30 }}>// status: coming soon</div>
            </div>
          </div>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}

function PageConsulting() {
  return <HeroConsole ctx={PH_CTX.consulting} />;
}

function PageHackatons() {
  return <HeroConsole ctx={PH_CTX.hackatons} />;
}

/* Papers that credit the Academy. Fed by /api/papers (NASA ADS full-text
   search on the two acknowledgement phrases); falls back to the committed
   snapshot when the endpoint isn't there. Nothing here is hand-maintained. */
function CreditedPapers() {
  const [state, setState] = React.useState({ status: 'loading', papers: [], updated: null });
  React.useEffect(() => {
    let live = true;
    (async () => {
      const tryFetch = async (u) => {
        const r = await fetch(u);
        if (!r.ok) throw new Error(String(r.status));
        return r.json();
      };
      let data = null;
      try { data = await tryFetch('/api/papers'); }
      catch (e) { try { data = await tryFetch('../assets/papers.json'); } catch (e2) { data = null; } }
      if (!live) return;
      if (!data) setState({ status: 'error', papers: [], updated: null });
      else setState({ status: 'ok', papers: data.papers || [], updated: data.updated || null });
    })();
    return () => { live = false; };
  }, []);

  const byYear = React.useMemo(() => {
    const g = new Map();
    for (const p of state.papers) {
      const y = p.year || '—';
      if (!g.has(y)) g.set(y, []);
      g.get(y).push(p);
    }
    return [...g.entries()].sort((a, b) => Number(b[0]) - Number(a[0]));
  }, [state.papers]);

  const authorLine = (a = []) => {
    if (!a.length) return '';
    const short = a.slice(0, 3).join('; ');
    return a.length > 3 ? short + ' et al.' : short;
  };
  const stamp = state.updated
    ? new Date(state.updated).toISOString().slice(0, 10)
    : null;

  return (
    <div style={{ marginTop: 56 }}>
      <div className="as-eyebrow" style={{ display: 'block' }}>Papers crediting us</div>
      <p className="as-p" style={{ maxWidth: 640, marginTop: 8 }}>
        Collected automatically from published acknowledgements. No list is kept by hand.
      </p>

      {state.status === 'loading' && (
        <div className="as-mono" style={{ fontSize: 12, color: 'var(--fg3)', marginTop: 20 }}>// fetching…</div>
      )}
      {state.status === 'error' && (
        <div className="as-mono" style={{ fontSize: 12, color: 'var(--fg3)', marginTop: 20 }}>// paper list unavailable</div>
      )}
      {state.status === 'ok' && !state.papers.length && (
        <div className="as-mono" style={{ fontSize: 12, color: 'var(--fg3)', marginTop: 20 }}>// no papers indexed yet</div>
      )}

      {state.status === 'ok' && state.papers.length > 0 && (
        <div style={{ marginTop: 24, maxWidth: 760 }}>
          <div className="as-mono" style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, letterSpacing: '.06em', color: 'var(--fg3)', borderBottom: '1px solid var(--border)', paddingBottom: 8 }}>
            <span>{state.papers.length} paper{state.papers.length === 1 ? '' : 's'}</span>
            {stamp && <span>updated {stamp}</span>}
          </div>
          {byYear.map(([year, list]) => (
            <div key={year} style={{ display: 'grid', gridTemplateColumns: '64px minmax(0,1fr)', gap: 16, paddingTop: 18 }}>
              <div className="as-mono" style={{ fontSize: 13, color: 'var(--blue)', paddingTop: 2 }}>{year}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
                {list.map(p => (
                  <div key={p.bibcode} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                    <a href={p.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 15, fontWeight: 600, lineHeight: 1.4, color: 'var(--fg1)', textDecoration: 'none' }}>{p.title}</a>
                    <div style={{ fontSize: 13, color: 'var(--fg3)', lineHeight: 1.5 }}>{authorLine(p.authors)}</div>
                    <div className="as-mono" style={{ display: 'flex', flexWrap: 'wrap', gap: 14, fontSize: 11, letterSpacing: '.04em', color: 'var(--fg4)' }}>
                      {p.journal && <span>{p.journal}</span>}
                      {p.arxiv && <span>arXiv:{p.arxiv}</span>}
                      {typeof p.citations === 'number' && <span>{p.citations} cited</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* Acknowledge — how to credit the Academy in published work. */
function PageAcknowledge() {
  const ACK = 'We wish to thank the AstroStat Academy for providing training on the analysis methods adopted in this work.';
  const [copied, setCopied] = React.useState(false);
  const ct = React.useRef(null);
  const copy = () => {
    try {
      if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(ACK); }
      else { throw new Error('fallback'); }
    } catch (e) {
      try {
        const ta = document.createElement('textarea');
        ta.value = ACK; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.focus(); ta.select();
        document.execCommand('copy'); document.body.removeChild(ta);
      } catch (e2) { /* ignore */ }
    }
    setCopied(true);
    clearTimeout(ct.current);
    ct.current = setTimeout(() => setCopied(false), 2000);
  };
  React.useEffect(() => () => clearTimeout(ct.current), []);
  return (
    <div className="as-page">
      <SiteNav active="acknowledge" />
      <div className="as-wrap">
        <div className="as-panel"><Corners />
          <Rail n="06" label="Credit" variant="glyph">
            <span className="as-eyebrow">Acknowledge us</span>
            <h1 className="as-h1pg" style={{ marginTop: 10 }}>Crediting<br />AstroStat Academy</h1>
            <p className="as-p">If a school, hackaton or consulting engagement contributed to your research, a short acknowledgement in your paper or talk helps us keep the programme running and reach new groups.</p>

            <div className="as-eyebrow" style={{ marginTop: 32, display: 'block' }}>Suggested acknowledgement</div>
            <div className="as-mono" style={{ position: 'relative', border: '1px solid rgba(251,246,236,.25)', background: 'rgba(255,255,255,.03)', padding: '30px 22px 20px', fontSize: 14, lineHeight: 1.65, color: 'rgba(251,246,236,.82)', maxWidth: 640, marginTop: 12, fontStyle: 'italic' }}>
              <span style={{ position: 'absolute', top: 6, left: 16, fontSize: 44, lineHeight: 1, color: '#3b9be0', fontFamily: 'Georgia, serif' }}>“</span>
              {ACK}
            </div>
            <div style={{ display: 'flex', gap: 12, marginTop: 16, position: 'relative' }}>
              <span style={{ position: 'absolute', bottom: 'calc(100% + 8px)', left: 0, whiteSpace: 'nowrap', fontFamily: 'ui-monospace,monospace', fontSize: 11, letterSpacing: '.06em', color: '#fff', background: '#0465ad', padding: '6px 10px', opacity: copied ? 1 : 0, transform: copied ? 'translateY(0)' : 'translateY(4px)', pointerEvents: 'none', transition: 'opacity .18s, transform .18s' }}>Text copied to clipboard</span>
              <button className="as-btn solid" onClick={copy}>Copy text</button>
            </div>

            <CreditedPapers />
          </Rail>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}

Object.assign(window, { PagePeople, ComingSoon, PageConsulting, PageHackatons, PageAcknowledge, CreditedPapers });
