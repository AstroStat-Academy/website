/* School detail — header band, description, lecturers, topics, attendance chart, interest form. */
function PageDetail() {
  const bars = [30, 45, 55, 62, 70, 50, 85];
  return (
    <div className="as-page">
      <SiteNav active="schools" />
      <div className="as-wrap">
        <div className="as-panel"><Corners />
          {/* header band */}
          <div style={{ padding: '34px 36px', borderBottom: '1px solid rgba(251,246,236,.22)' }}>
            <button className="as-btn ghost" style={{ padding: '6px 12px', fontSize: 11 }}>← All schools</button>
            <div style={{ marginTop: 16, display: 'flex', gap: 10, alignItems: 'center' }}>
              <span className="as-badge">Upcoming</span>
              <span className="as-mono" style={{ fontSize: 11, color: 'rgba(251,246,236,.5)' }}>27–31 JUL 2026 · ROME</span>
            </div>
            <h1 className="as-h1pg" style={{ marginTop: 14 }}>Bayesian Inference<br />for Astronomy</h1>
            <p className="as-p">Five days of hierarchical modelling, MCMC and posterior diagnostics, applied to real survey data with daily hands-on labs.</p>
            <div style={{ marginTop: 20 }}><button className="as-btn solid">Apply Now</button></div>
          </div>

          <Rail n="A" label="Overview">
            <h2 className="as-h2">What you'll learn</h2>
            <p className="as-p">From the foundations of probability to building and checking full hierarchical models, you'll leave able to design, fit and critique a Bayesian analysis end to end — and to read the literature with a sharper eye.</p>
          </Rail>

          <Rail n="B" label="Faculty" accent="red">
            <h2 className="as-h2">Lecturers</h2>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 18 }}>
              {['Inference & priors', 'MCMC & diagnostics', 'Hierarchical models', 'Model checking'].map((r, i) => (
                <div key={i} className="as-card" style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                  <span className="as-av"></span>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 15 }}>Lecturer {i + 1}</div>
                    <div className="as-mono" style={{ fontSize: 11, color: 'rgba(251,246,236,.5)', marginTop: 4 }}>{r}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="as-eyebrow" style={{ marginTop: 30, display: 'block' }}>Topics</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 }}>
              {['Bayesian', 'Deep Learning', 'MCMC', 'Gaussian Proc.', 'AI Agents', 'Diagnostics'].map(t => <span key={t} className="as-chip">{t}</span>)}
            </div>
          </Rail>

          <Rail n="C" label="History">
            <h2 className="as-h2">Attendance history</h2>
            <p className="as-p">Applications have grown each year — this cohort (crimson) is the largest yet.</p>
            <div className="as-chart" style={{ marginTop: 18, maxWidth: 460 }}>
              {bars.map((h, i) => <i key={i} className={i === bars.length - 1 ? 'hi' : ''} style={{ height: h + '%' }}></i>)}
            </div>
          </Rail>

          <Rail n="D" label="Apply" accent="red">
            <h2 className="as-h2">Express interest</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 18, maxWidth: 460 }}>
              <div className="as-field">Full name *</div>
              <div className="as-field">Email *</div>
              <div className="as-field">Career stage ▾</div>
              <button className="as-btn solid" style={{ justifyContent: 'center' }}>Submit Interest</button>
            </div>
          </Rail>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
window.PageDetail = PageDetail;
