/* Schools — listing: page header, filters, responsive card grid. */
const SCHOOLS = [
  { status: 'Upcoming', year: '2026', title: 'Bayesian Inference for Astronomy', place: 'Rome', topics: ['Bayesian', 'MCMC'] },
  { status: 'Past', year: '2025', title: 'Deep Learning on the GPU', place: 'Heidelberg', topics: ['Deep L.', 'GPU'] },
  { status: 'Past', year: '2025', title: 'Time Series & Variability', place: 'Leiden', topics: ['Time ser.'] },
  { status: 'Past', year: '2024', title: 'Machine Learning Foundations', place: 'Paris', topics: ['Bayesian', 'ML'] },
  { status: 'Past', year: '2024', title: 'Gaussian Processes in Practice', place: 'Geneva', topics: ['GP', 'Kernels'] },
  { status: 'Past', year: '2023', title: 'Hierarchical Models', place: 'Munich', topics: ['Bayesian'] },
];

function SchoolCard({ s }) {
  const up = s.status === 'Upcoming';
  return (
    <div className="as-card" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span className={'as-badge' + (up ? '' : ' muted')}>{s.status}</span>
        <span className="as-mono" style={{ fontSize: 11, color: 'rgba(251,246,236,.45)' }}>{s.year}</span>
      </div>
      <div style={{ fontWeight: 600, fontSize: 17, lineHeight: 1.2 }}>{s.title}</div>
      <div className="as-mono" style={{ fontSize: 11, color: 'rgba(251,246,236,.5)' }}>{s.place}</div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 2 }}>
        {s.topics.map(t => <span key={t} className="as-chip">{t}</span>)}
      </div>
    </div>
  );
}

function PageSchools() {
  return (
    <div className="as-page">
      <SiteNav active="schools" />
      <div className="as-wrap">
        <div className="as-panel"><Corners />
          <Rail n="02" label="Training">
            <span className="as-eyebrow">Schools</span>
            <h1 className="as-h1pg" style={{ marginTop: 10 }}>Residential schools<br />in statistical astronomy</h1>
            <p className="as-p">Week-long intensives taught by working researchers. Lectures in the morning, hands-on labs in the afternoon, real data throughout.</p>

            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginTop: 26, flexWrap: 'wrap' }}>
              <button className="as-btn ghost">Year ▾</button>
              <button className="as-btn ghost">Topic ▾</button>
              <span className="as-mono" style={{ fontSize: 11, color: 'rgba(251,246,236,.45)', marginLeft: 'auto' }}>{SCHOOLS.length} schools found</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginTop: 16 }}>
              {SCHOOLS.map((s, i) => <SchoolCard key={i} s={s} />)}
            </div>
          </Rail>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
window.PageSchools = PageSchools;
