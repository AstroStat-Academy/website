# AstroStat Academy — static site

Deploy this folder as-is to Vercel (no build step).

## Option 1 — CLI
    npm i -g vercel
    cd deploy
    vercel        # preview
    vercel --prod # production

When asked for framework preset choose **Other**; leave build command and
output directory empty.

## Option 2 — Git
Push this folder to a GitHub repo, then on vercel.com: New Project → import
the repo → Framework preset **Other** → Root Directory `deploy` (if you
pushed the whole design system) → Deploy.

## Notes
- Fully static: React, ReactDOM and Babel load from unpkg at runtime, and the
  `.jsx` files are transpiled in the browser. Nothing to install.
- The People page reads `assets/people/people.yml` plus
  `assets/people/<role>/<slug>.md` over fetch. Those per-person markdown
  files are not in the project yet, so that page will come up empty until they
  are added.
- For a faster production site, pre-compile the `.jsx` files and swap the
  development React builds for `react.production.min.js`.

## Live paper list (Crediting page)

`api/papers.js` returns every paper whose acknowledgements contain either

- "Summer School for Astrostatistics in Crete"
- "AstroStat Academy"

Discovery runs against NASA ADS, which indexes full text (arXiv's own API
searches only title/abstract/authors, so it cannot see acknowledgements).
Results carry arXiv IDs and link to arxiv.org.

    vercel env add ADS_TOKEN     # free: https://ui.adsabs.harvard.edu/user/settings/token

Cached at the edge for 24h, and `vercel.json` runs a daily cron at 05:00 UTC
to refresh it. Without the token the endpoint returns an empty list and the
page says so; nothing breaks.
