/* AstroStat Academy — UI kit: People page
   Renders LIVE from the roster + per-person files under assets/people/:

       assets/people/people.yml          section -> ordered list of slugs
       assets/people/<role>/<slug>.md    front-matter (name, affiliation,
                                         title, photo, links) + bio body
       assets/people/<role>/<slug>.jpg   headshot (optional)

   To change the page, edit those files — NOT this component.
   Remove a slug from people.yml and the person drops off the page while
   their .md / .jpg stay on disk. */

const PEOPLE_BASE = 'assets/people';

// Section labels + layout, keyed by the role folder name.
const ROLE_META = {
  councellors: { label: 'Councellors', wide: true },
  lecturers:   { label: 'Lecturers',   wide: false },
  TAs:         { label: 'Teaching assistants', wide: false },
  advisors:    { label: 'Advisors',    wide: false },
};

/* ── tiny parsers (no deps) ─────────────────────────────────────── */

// people.yml -> [{ role, slugs: [..] }] in file order.
function parseRoster(text) {
  const sections = [];
  let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, '');           // strip comments
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) { cur = { role: sec[1], slugs: [] }; sections.push(cur); return; }
    const item = line.match(/^\s*-\s*(.+?)\s*$/);
    if (item && cur) cur.slugs.push(item[1]);
  });
  return sections;
}

// <slug>.md -> { name, affiliation, title, photo, links{}, bio }
function parsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = { links: {} };
  let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s+/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1], val = kv[2].trim();
      if (key === 'links' && val === '') { inLinks = true; return; }
      if (inLinks && indented) { meta.links[key] = val; return; }
      inLinks = false;
      meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}

/* ── avatar (photo with initials fallback) ──────────────────────── */

function initials(name) {
  const clean = name.replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '');
  const parts = clean.split(/\s+/);
  return (parts[0][0] + (parts[parts.length - 1][0] || '')).toUpperCase();
}
function toneFor(name) {
  const tones = ['#0465ad', '#8c0527', '#008c8c']; // blue / crimson / teal
  const sum = name.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return tones[sum % tones.length];
}

function Avatar({ person, size }) {
  const tone = toneFor(person.name);
  const [failed, setFailed] = React.useState(false);
  const show = person.photoUrl && !failed;
  return (
    <span className="as-avatar"
      style={{ width: size, height: size, borderColor: tone, color: tone, fontSize: size * 0.34, overflow: 'hidden' }}>
      {show ? (
        <img src={person.photoUrl} alt={person.name} width={size} height={size}
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          onError={() => setFailed(true)} />
      ) : initials(person.name)}
    </span>
  );
}

function PersonCard({ person, wide }) {
  const linkEntries = Object.entries(person.links || {});
  return (
    <div className={wide ? 'as-person as-person-wide' : 'as-person'}>
      <Avatar person={person} size={wide ? 56 : 64} />
      <div className="as-person-meta">
        <p className="as-person-name">{person.name}</p>
        {person.affiliation && <p className="as-person-aff">{person.affiliation}</p>}
        {person.title && <span className="as-person-role">{person.title}</span>}
        {person.bio && <p className="as-person-bio">{person.bio}</p>}
        {linkEntries.length > 0 && (
          <p className="as-person-links">
            {linkEntries.map(([label, url]) => (
              <a key={label} className="as-inline-link" href={url} target="_blank" rel="noreferrer">{label} →</a>
            ))}
          </p>
        )}
      </div>
    </div>
  );
}

/* ── data loading ───────────────────────────────────────────────── */

async function loadPeople() {
  const rosterText = await fetch(`${PEOPLE_BASE}/people.yml`).then(r => {
    if (!r.ok) throw new Error('people.yml not found');
    return r.text();
  });
  const roster = parseRoster(rosterText);

  const sections = await Promise.all(roster.map(async ({ role, slugs }) => {
    const people = (await Promise.all(slugs.map(async slug => {
      try {
        const md = await fetch(`${PEOPLE_BASE}/${role}/${slug}.md`).then(r => {
          if (!r.ok) throw new Error(`${role}/${slug}.md missing`);
          return r.text();
        });
        const person = parsePerson(md);
        if (!person.name) person.name = slug;
        const photo = person.photo || `${slug}.jpg`;
        person.photoUrl = `${PEOPLE_BASE}/${role}/${photo}`;
        return person;
      } catch (e) { console.warn('[people]', e.message); return null; }
    }))).filter(Boolean);
    const meta = ROLE_META[role] || { label: role, wide: false };
    return { role, label: meta.label, wide: meta.wide, people };
  }));

  return sections.filter(s => s.people.length);
}

/* ── page ───────────────────────────────────────────────────────── */

function People({ onNav }) {
  const [sections, setSections] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    loadPeople().then(setSections).catch(e => setError(e.message));
  }, []);

  return (
    <div className="as-page">
      <div className="as-panel">
        <p className="as-eyebrow as-eyebrow-blue">People</p>
        <h1 className="as-h1">Our People</h1>
        <p className="as-lead">
          AstroStat Academy is run by working astronomers, statisticians, and machine-learning
          practitioners drawn from research institutes and universities across Europe and beyond.
        </p>
      </div>

      {error && <p className="as-note as-provisional">Couldn't load the roster ({error}).</p>}
      {!error && sections === null && <p className="as-note">Loading people…</p>}

      {sections && sections.map(section => (
        <section className="as-people-section" key={section.role}>
          <h2 className="as-h2">{section.label}</h2>
          <div className={`as-people-grid ${section.wide ? 'as-people-grid-2' : 'as-people-grid-3'}`}>
            {section.people.map(p => <PersonCard key={p.name} person={p} wide={section.wide} />)}
          </div>
        </section>
      ))}

      <section className="as-people-cta">
        <p className="as-note">
          Want to lecture at a future school, or collaborate?{' '}
          <a className="as-inline-link" href="mailto:info@astrostat.academy">Get in touch</a>.
        </p>
      </section>
    </div>
  );
}

Object.assign(window, { People });
