/* AstroStat Academy — UI kit: chrome (Nav, Footer, ThemeToggle) */

function ThemeToggle({ dark, onToggle }) {
  return (
    <button className="as-toggle" onClick={onToggle}
      aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}>
      <span className="as-toggle-knob" style={{ transform: dark ? 'translateX(20px)' : 'translateX(0)' }}>
        {dark ? '☾' : '☼'}
      </span>
    </button>
  );
}

function Nav({ route, onNav, dark, onToggleTheme }) {
  const links = [
    { id: 'schools', label: 'Schools' },
    { id: 'hackatons', label: 'Hackatons' },
    { id: 'consulting', label: 'Consulting' },
  ];
  const active = (id) => route === id || (id === 'schools' && route === 'school');
  return (
    <nav className="as-nav-wrap">
      <div className="as-nav">
        <a className="as-brand" href="#" onClick={(e) => { e.preventDefault(); onNav('home'); }}>
          <img className="as-brand-mark" src={dark ? 'assets/logo-bone.svg' : 'assets/logo.svg'} alt="" aria-hidden="true" />
          AstroStat Academy
        </a>
        <ul className="as-nav-links">
          {links.map(l => (
            <li key={l.id}>
              <a href="#" onClick={(e) => { e.preventDefault(); onNav(l.id); }}
                 className={active(l.id) ? 'as-link as-link-active' : 'as-link'}>
                {l.label}
              </a>
            </li>
          ))}
          <li aria-hidden="true" className="as-nav-sep" />
          <li><ThemeToggle dark={dark} onToggle={onToggleTheme} /></li>
          <li aria-hidden="true" className="as-nav-sep" />
          <li>
            <a href="#" onClick={(e) => { e.preventDefault(); onNav('people'); }}
               className={route === 'people' ? 'as-link as-link-active' : 'as-link'}>
              People
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
}

function Footer({ onNav }) {
  return (
    <footer className="as-footer">
      <div className="as-footer-inner">
        <p>© {new Date().getFullYear()} AstroStat Academy. All rights reserved.</p>
        <div className="as-footer-links">
          <a href="#" onClick={(e) => { e.preventDefault(); onNav('schools'); }}>Schools</a>
          <a href="#" onClick={(e) => { e.preventDefault(); onNav('consulting'); }}>Consulting</a>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { Nav, Footer, ThemeToggle });
