// Vercel serverless function — papers that credit AstroStat Academy.
//
// Discovery is by ACKNOWLEDGEMENT text, which only a full-text index can do.
// NASA ADS indexes acknowledgements (and covers arXiv preprints), so we query
// ADS and hand back arXiv links.
//
// Setup:  vercel env add ADS_TOKEN     (free token: https://ui.adsabs.harvard.edu/user/settings/token)
// Without a token the endpoint serves the committed snapshot in assets/papers.json.

const PHRASES = [
  'Summer School for Astrostatistics in Crete',
  'AstroStat Academy',
];

const ADS = 'https://api.adsabs.harvard.edu/v1/search/query';
const FIELDS = 'bibcode,title,author,year,pubdate,pub,doi,identifier,citation_count';

function arxivId(identifiers = []) {
  for (const id of identifiers) {
    const m = /^arxiv:(.+)$/i.exec(id);
    if (m) return m[1];
  }
  return null;
}

function normalise(doc) {
  const ax = arxivId(doc.identifier);
  return {
    bibcode: doc.bibcode,
    title: Array.isArray(doc.title) ? doc.title[0] : doc.title,
    authors: doc.author || [],
    year: doc.year ? Number(doc.year) : null,
    pubdate: doc.pubdate || null,
    journal: doc.pub || null,
    doi: doc.doi ? doc.doi[0] : null,
    arxiv: ax,
    url: ax
      ? `https://arxiv.org/abs/${ax}`
      : `https://ui.adsabs.harvard.edu/abs/${encodeURIComponent(doc.bibcode)}`,
    citations: typeof doc.citation_count === 'number' ? doc.citation_count : null,
  };
}

export default async function handler(req, res) {
  const token = process.env.ADS_TOKEN;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  // Cached at the edge for a day; stale copies keep serving while it revalidates.
  res.setHeader('Cache-Control', 's-maxage=86400, stale-while-revalidate=604800');

  if (!token) {
    return res.status(200).json({
      updated: null,
      source: 'none',
      note: 'ADS_TOKEN is not set — no automated discovery. Add the env var in Vercel.',
      papers: [],
    });
  }

  const q = PHRASES.map(p => `full:"${p}"`).join(' OR ');
  const url = `${ADS}?q=${encodeURIComponent(q)}&fl=${FIELDS}&rows=200&sort=${encodeURIComponent('date desc')}`;

  try {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) throw new Error(`ADS ${r.status}`);
    const data = await r.json();
    const papers = (data.response?.docs || []).map(normalise);
    return res.status(200).json({
      updated: new Date().toISOString(),
      source: 'ads',
      query: q,
      count: papers.length,
      papers,
    });
  } catch (err) {
    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json({
      updated: null,
      source: 'error',
      note: String(err.message || err),
      papers: [],
    });
  }
}
