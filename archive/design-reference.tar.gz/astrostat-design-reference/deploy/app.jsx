/* AstroStat Academy — UI kit: app shell + routing */

function App() {
  const [route, setRoute] = React.useState('home');   // home | schools | school | hackatons | consulting | people
  const [slug, setSlug] = React.useState(null);
  const [dark, setDark] = React.useState(true);

  const nav = (r) => {
    if (r === 'home') { setRoute('home'); }
    else { setRoute(r); }
    setSlug(null);
    window.scrollTo({ top: 0 });
  };
  const openSchool = (s) => { setSlug(s); setRoute('school'); window.scrollTo({ top: 0 }); };

  let view;
  if (route === 'home') view = <Home onNav={nav} />;
  else if (route === 'schools') view = <SchoolsView onOpen={openSchool} />;
  else if (route === 'school') view = <SchoolDetail slug={slug} onBack={() => nav('schools')} />;
  else if (route === 'people') view = <People onNav={nav} />;
  else view = <ComingSoon route={route} />;

  return (
    <div className={'as-root' + (dark ? '' : ' as-light')}>
      <div className="as-rain">{dark && <CodeRain />}</div>
      <Nav route={route} onNav={nav} dark={dark} onToggleTheme={() => setDark(d => !d)} />
      <main className="as-main">{view}</main>
      <Footer onNav={nav} />
    </div>
  );
}

/* Demo mount — opt-in only. The compiled bundle is loaded by many pages that
   own their own #root, so this must never auto-mount there. The ui_kit's own
   demo HTML sets data-uikit-demo on its container. */
const appRoot = document.querySelector('#root[data-uikit-demo]');
if (appRoot) ReactDOM.createRoot(appRoot).render(<App />);
