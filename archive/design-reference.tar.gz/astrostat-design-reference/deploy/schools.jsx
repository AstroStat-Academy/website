/* AstroStat Academy — UI kit: schools listing, detail, chart, form, placeholders */

const fmtRange = (d, e) => {
  const o = { month: 'short', day: 'numeric' };
  const a = new Date(d), b = e ? new Date(e) : null;
  if (b) return `${a.toLocaleDateString('en-US', o)} – ${b.toLocaleDateString('en-US', { ...o, year: 'numeric' })}`;
  return a.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
};
const isPast = (s) => new Date(s.endDate || s.date) < new Date();

function StatusBadge({ school }) {
  const past = isPast(school);
  return <span className={past ? 'as-badge as-badge-past' : 'as-badge as-badge-upcoming'}>{past ? 'Past' : 'Upcoming'}</span>;
}

function SchoolCard({ school, onOpen }) {
  return (
    <a href="#" className="as-school-card" onClick={(e) => { e.preventDefault(); onOpen(school.slug); }}>
      <div className="as-school-top">
        <StatusBadge school={school} />
        <span className="as-school-date">{new Date(school.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })}</span>
      </div>
      <h3 className="as-school-title">{school.title}</h3>
      <p className="as-school-loc">{school.location}</p>
      <p className="as-school-desc">{school.description}</p>
      <div className="as-chips">
        {school.topics.slice(0, 3).map(t => <span key={t} className="as-chip">{t}</span>)}
        {school.topics.length > 3 && <span className="as-chip-more">+{school.topics.length - 3} more</span>}
      </div>
      {school.attendees && <p className="as-school-att">{school.attendees} attendees</p>}
    </a>
  );
}

function SchoolsView({ onOpen }) {
  const all = window.SCHOOLS;
  const [year, setYear] = React.useState('all');
  const [topic, setTopic] = React.useState('all');
  const years = ['all', ...Array.from(new Set(all.map(s => new Date(s.date).getFullYear().toString()))).sort().reverse()];
  const topics = ['all', ...Array.from(new Set(all.flatMap(s => s.topics))).sort()];
  const filtered = all
    .filter(s => year === 'all' || new Date(s.date).getFullYear().toString() === year)
    .filter(s => topic === 'all' || s.topics.includes(topic))
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  return (
    <div className="as-page">
      <div className="as-panel">
        <p className="as-eyebrow as-eyebrow-blue">Training</p>
        <h1 className="as-h1">Schools &amp; Workshops</h1>
        <p className="as-lead">Intensive statistical training for the astronomical community.</p>
      </div>
      <div className="as-filters">
        <div className="as-field">
          <label>Year</label>
          <select value={year} onChange={e => setYear(e.target.value)}>
            {years.map(y => <option key={y} value={y}>{y === 'all' ? 'All years' : y}</option>)}
          </select>
        </div>
        <div className="as-field">
          <label>Topic</label>
          <select value={topic} onChange={e => setTopic(e.target.value)}>
            {topics.map(t => <option key={t} value={t}>{t === 'all' ? 'All topics' : t}</option>)}
          </select>
        </div>
      </div>
      <p className="as-count">{filtered.length} school{filtered.length !== 1 ? 's' : ''} found</p>
      {filtered.length === 0
        ? <p className="as-empty">No schools match your filters.</p>
        : <div className="as-school-grid">{filtered.map(s => <SchoolCard key={s.slug} school={s} onOpen={onOpen} />)}</div>}
    </div>
  );
}

/* Simple SVG bar chart (cosmetic stand-in for the Plotly attendance chart) */
function AttendanceChart({ highlight }) {
  const data = window.SCHOOLS.filter(s => s.attendees).sort((a, b) => new Date(a.date) - new Date(b.date));
  const max = Math.max(...data.map(s => s.attendees));
  const W = 760, H = 300, pad = 44, gap = 0.35;
  const bw = (W - pad * 2) / data.length;
  return (
    <div className="as-chart">
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" preserveAspectRatio="xMidYMid meet">
        {[0, 0.25, 0.5, 0.75, 1].map(t => {
          const y = pad + (H - pad * 1.4) * (1 - t);
          return <g key={t}>
            <line x1={pad} y1={y} x2={W - pad / 2} y2={y} stroke="rgba(255,255,255,0.10)" />
            <text x={pad - 8} y={y + 4} textAnchor="end" fontSize="11" fill="rgba(251,246,236,0.55)">{Math.round(max * t)}</text>
          </g>;
        })}
        {data.map((s, i) => {
          const bh = (s.attendees / max) * (H - pad * 1.4);
          const x = pad + i * bw + bw * gap / 2;
          const w = bw * (1 - gap);
          const hi = s.title === highlight;
          return <g key={s.slug}>
            <rect x={x} y={H - pad * 0.4 - bh} width={w} height={bh} rx="3"
              fill={hi ? '#8c0527' : '#0465ad'} opacity="0.9">
              <title>{s.title}: {s.attendees} attendees</title>
            </rect>
            <text x={x + w / 2} y={H - pad * 0.4 + 16} textAnchor="middle" fontSize="11" fill="rgba(251,246,236,0.55)">
              {new Date(s.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
            </text>
          </g>;
        })}
      </svg>
    </div>
  );
}

function ApplicationForm({ schoolTitle }) {
  const [sent, setSent] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const submit = (e) => {
    e.preventDefault(); setBusy(true);
    setTimeout(() => { setBusy(false); setSent(true); }, 800);
  };
  if (sent) return (
    <div className="as-form as-form-done">
      <p className="as-form-thanks">Thank you!</p>
      <p className="as-form-thanks-sub">We've noted your interest in <strong>{schoolTitle}</strong>. We'll be in touch.</p>
    </div>
  );
  return (
    <form className="as-form" onSubmit={submit} noValidate>
      <div className="as-form-row"><label>Full name *</label><input required placeholder="Jane Smith" /></div>
      <div className="as-form-row"><label>Email address *</label><input required type="email" placeholder="jane@university.edu" /></div>
      <div className="as-form-row"><label>Institution</label><input placeholder="University or research institute" /></div>
      <div className="as-form-row"><label>Career stage</label>
        <select defaultValue=""><option value="" disabled>Select…</option>
          <option>PhD student</option><option>Postdoctoral researcher</option>
          <option>Faculty / staff scientist</option><option>Industry</option><option>Other</option>
        </select>
      </div>
      <div className="as-form-row"><label>Message (optional)</label>
        <textarea rows="3" placeholder="Any questions or context you'd like to share…" />
      </div>
      <button className="as-btn as-btn-primary as-btn-block" disabled={busy}>{busy ? 'Sending…' : 'Submit Interest'}</button>
    </form>
  );
}

function SchoolDetail({ slug, onBack }) {
  const s = window.SCHOOLS.find(x => x.slug === slug);
  if (!s) return null;
  const past = isPast(s);
  const html = s.body
    .replace(/^## (.*)$/gm, '<h2 class="as-prose-h2">$1</h2>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/^> (.*)$/gm, '<blockquote class="as-prose-quote">$1</blockquote>')
    .split('\n\n').map(p => p.startsWith('<') ? p : `<p>${p}</p>`).join('');
  return (
    <div>
      <div className="as-detail-head">
        <div className="as-detail-head-inner">
          <a href="#" className="as-btn as-btn-outline" onClick={(e) => { e.preventDefault(); onBack(); }}>← All schools</a>
          <div style={{ margin: '20px 0 14px' }}><StatusBadge school={s} /></div>
          <h1 className="as-detail-title">{s.title}</h1>
          <div className="as-detail-meta">
            <span>{fmtRange(s.date, s.endDate)}</span><span>{s.location}</span>
            {s.attendees && <span>{s.attendees} attendees</span>}
          </div>
          {s.applicationUrl && !past &&
            <a href="#apply" className="as-btn as-btn-primary" style={{ marginTop: 24 }}
               onClick={(e) => { e.preventDefault(); document.getElementById('as-apply').scrollIntoView({ behavior: 'smooth' }); }}>Apply Now</a>}
        </div>
      </div>
      <div className="as-detail-body">
        <section className="as-prose" dangerouslySetInnerHTML={{ __html: html }} />
        {s.lecturers.length > 0 && (
          <section>
            <h2 className="as-h2">Lecturers</h2>
            <div className="as-lecturers">
              {s.lecturers.map(l => (
                <div key={l.name} className="as-lecturer">
                  <p className="as-lecturer-name">{l.name}</p>
                  {l.affiliation && <p className="as-lecturer-aff">{l.affiliation}</p>}
                </div>
              ))}
            </div>
          </section>
        )}
        <section>
          <h2 className="as-h2">Topics</h2>
          <div className="as-chips">{s.topics.map(t => <span key={t} className="as-chip as-chip-lg">{t}</span>)}</div>
        </section>
        <section>
          <h2 className="as-h2">Attendance History</h2>
          <AttendanceChart highlight={s.title} />
          <p className="as-note">Highlighted bar = this school. All attendee counts are approximate.</p>
        </section>
        <section id="as-apply">
          <h2 className="as-h2">Express Interest</h2>
          <p className="as-note" style={{ marginBottom: 20 }}>
            {past ? 'Interested in future editions? Leave your details and we\'ll notify you.'
                  : 'Not ready to apply? Leave your contact details and we\'ll keep you posted.'}
          </p>
          <ApplicationForm schoolTitle={s.title} />
        </section>
      </div>
    </div>
  );
}

function ComingSoon({ route }) {
  const map = {
    hackatons: { tone: 'teal', eyebrow: 'Hackatons', title: 'Hackatons',
      body: 'Our first hackaton is in the works. Stay tuned for details.', email: 'info@astrostat.academy', q: 'Want to get involved?' },
    consulting: { tone: 'red', eyebrow: 'Consulting', title: 'Enterprise Consulting',
      body: 'Tailored statistical consulting for research groups, institutes, and space agencies. We help teams design analyses, choose models, and interpret results — coming soon.', email: 'consulting@astrostat.academy', q: 'Interested in working with us?' },
    people: { tone: 'blue', eyebrow: 'People', title: 'Our People',
      body: 'Our team of astronomers and statisticians will be listed here soon.', email: 'info@astrostat.academy', q: 'In the meantime, reach us at' },
  };
  const c = map[route];
  return (
    <div className="as-page as-page-narrow">
      <div className={'as-feature as-feature-' + c.tone} style={{ textAlign: 'center' }}>
        <p className={'as-eyebrow as-eyebrow-' + c.tone}>{c.eyebrow}</p>
        <h1 className="as-h1" style={{ marginBottom: 16 }}>{c.title}</h1>
        <p className="as-lead" style={{ marginBottom: 20 }}>{c.body}</p>
        <p className="as-note">{c.q} <a className="as-inline-link" href={'mailto:' + c.email}>{route === 'people' ? c.email : 'Get in touch'}</a>.</p>
      </div>
    </div>
  );
}

Object.assign(window, { SchoolsView, SchoolDetail, ComingSoon });
