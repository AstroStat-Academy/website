/* AstroStat Academy — UI kit: generative effects
   CodeRain (full-bleed background), Typewriter (rotating taglines),
   HeroStat (the interactive Gaussian-histogram / time-series hero widget).
   Simplified, cosmetic recreations of the site's canvas effects.        */

const RAIN_CHARS = 'αβγδεζηθικλμνξπρστφχψωΛΦΨΩΣ∑∏∫∮∂∇∆√∛∝∞≈≅≠≡≤≥±∓×÷∀∃∈∉⊂⊃⊆∪∩∅∴∵⊕⊗⊙ℓℏℝℕ☉★✦0123456789';
const RED_RGB = '140, 5, 39';
const BLUE_RGB = '4, 101, 173';

/* ── Full-page falling code rain (crimson, translucent) ─────────────── */
function CodeRain() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const FONT = 16, FRAME = 110;
    let columns = 0, drops = [], raf = 0, last = 0;
    const init = () => {
      const w = canvas.parentElement.clientWidth;
      const h = canvas.parentElement.clientHeight;
      canvas.width = w; canvas.height = h;
      columns = Math.floor(w / FONT);
      drops = Array.from({ length: columns }, () => (Math.random() * h) / FONT);
    };
    const tick = (now) => {
      raf = requestAnimationFrame(tick);
      if (now - last < FRAME) return;
      last = now;
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = FONT + 'px ui-monospace, monospace';
      ctx.textBaseline = 'top';
      for (let i = 0; i < columns; i++) {
        ctx.fillStyle = `rgba(${RED_RGB}, 0.5)`;
        ctx.fillText(RAIN_CHARS[(Math.random() * RAIN_CHARS.length) | 0], i * FONT, drops[i] * FONT);
        if (drops[i] * FONT > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    };
    init();
    raf = requestAnimationFrame(tick);
    window.addEventListener('resize', init);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', init); };
  }, []);
  return <canvas ref={ref} aria-hidden="true"
    style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }} />;
}

/* ── Typewriter rotating taglines with blinking block cursor ─────────── */
function Typewriter({ phrases }) {
  const [text, setText] = React.useState('');
  const [del, setDel] = React.useState(false);
  const [idx, setIdx] = React.useState(0);
  const [cur, setCur] = React.useState(true);
  React.useEffect(() => {
    const id = setInterval(() => setCur(c => !c), 530);
    return () => clearInterval(id);
  }, []);
  React.useEffect(() => {
    const phrase = phrases[idx % phrases.length];
    let t;
    if (!del) {
      if (text.length < phrase.length)
        t = setTimeout(() => setText(phrase.slice(0, text.length + 1)), 72 * (0.6 + Math.random() * 0.8));
      else t = setTimeout(() => setDel(true), 2200);
    } else {
      if (text.length > 0) t = setTimeout(() => setText(text.slice(0, -1)), 28);
      else t = setTimeout(() => { setDel(false); setIdx(i => i + 1); }, 380);
    }
    return () => clearTimeout(t);
  }, [text, del, idx, phrases]);
  return (
    <span>{text}<span aria-hidden="true" style={{ opacity: cur ? 1 : 0 }}>█</span></span>
  );
}

/* ── Interactive hero histogram — drag the blue dot (mean) / grips (σ) ── */
function HeroStat() {
  const ref = React.useRef(null);
  const state = React.useRef({ mean: 0.5, sigma: 0.18, drag: 'none' });
  React.useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const W = 400, H = 150, BASE = 120;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = W * dpr; canvas.height = H * dpr;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.scale(dpr, dpr);
    let raf = 0, last = 0;
    const draw = (now) => {
      raf = requestAnimationFrame(draw);
      if (now - last < 90) return; last = now;
      ctx.clearRect(0, 0, W, H);
      const { mean, sigma } = state.current;
      const cols = 26, bw = W / cols, amp = BASE * 0.92;
      const wig = now / 900;
      for (let k = 0; k < cols; k++) {
        const xf = (k + 0.5) / cols;
        const g = Math.exp(-0.5 * ((xf - mean) / Math.max(sigma, 0.01)) ** 2);
        const bh = Math.max(0, g * amp + Math.sin(wig + k * 0.73) * 4 * g);
        ctx.fillStyle = `rgba(${BLUE_RGB}, 0.30)`;
        ctx.fillRect(k * bw + 1.5, BASE - bh + 2, bw - 1, bh);
        ctx.fillStyle = `rgba(${RED_RGB}, ${0.55 + g * 0.35})`;
        ctx.fillRect(k * bw + 0.5, BASE - bh, bw - 1, bh);
      }
      // widget: pill + mean dot + grips
      const mx = mean * W, half = sigma * W;
      const lx = Math.max(8, mx - half), rx = Math.min(W - 8, mx + half);
      const py = BASE + 16, pulse = 0.5 + 0.5 * Math.sin(now / 2000 * Math.PI * 2);
      ctx.strokeStyle = `rgba(${BLUE_RGB}, 0.45)`; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.roundRect(lx, py - 3, rx - lx, 6, 3); ctx.stroke();
      const grip = (x) => {
        ctx.save(); ctx.shadowColor = `rgba(${BLUE_RGB},0.5)`; ctx.shadowBlur = 3 + pulse * 4;
        ctx.fillStyle = `rgba(${BLUE_RGB}, ${0.65 + pulse * 0.1})`;
        ctx.beginPath(); ctx.roundRect(x - 3, py - 8, 6, 16, 3); ctx.fill(); ctx.restore();
      };
      grip(lx); grip(rx);
      ctx.save(); ctx.shadowColor = `rgba(${BLUE_RGB},0.5)`; ctx.shadowBlur = 3 + pulse * 4;
      ctx.fillStyle = `rgba(${BLUE_RGB}, ${0.65 + pulse * 0.1})`;
      ctx.beginPath(); ctx.arc(mx, py, 6, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    };
    raf = requestAnimationFrame(draw);

    const pos = (e) => {
      const r = canvas.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    };
    const down = (e) => {
      const { x } = pos(e); const { mean, sigma } = state.current;
      const mx = mean * W, lx = mx - sigma * W, rx = mx + sigma * W;
      if (Math.abs(x - mx) < 12) state.current.drag = 'move';
      else if (Math.abs(x - lx) < 10 || Math.abs(x - rx) < 10) state.current.drag = 'sigma';
      canvas.setPointerCapture(e.pointerId);
    };
    const move = (e) => {
      const { x } = pos(e); const d = state.current.drag;
      if (d === 'move') state.current.mean = Math.max(0.05, Math.min(0.95, x / W));
      else if (d === 'sigma') state.current.sigma = Math.max(0.05, Math.min(0.4, Math.abs(x - state.current.mean * W) / W));
      canvas.style.cursor = d !== 'none' ? 'grabbing' : 'grab';
    };
    const up = () => { state.current.drag = 'none'; canvas.style.cursor = 'grab'; };
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} style={{ cursor: 'grab', touchAction: 'none' }} title="Drag the mean & σ" />;
}

Object.assign(window, { CodeRain, Typewriter, HeroStat });
