/* AstroStat Academy — UI kit: home view (hero, hex honeycomb, mission cards) */

function SectionHead({ eyebrow, title, children }) {
  return (
    <div className="as-section-head">
      <p className="as-eyebrow as-eyebrow-blue">{eyebrow}</p>
      <h2 className="as-section-title">{title}</h2>
      {children && <p className="as-section-sub">{children}</p>}
    </div>
  );
}

function HexNav({ onNav }) {
  const items = [
    { id: 'schools', n: '01', label: 'Schools', soon: false, x: 0, y: 0, primary: true },
    { id: 'hackatons', n: '02', label: 'Hackatons', soon: true, x: 173, y: 0 },
    { id: 'consulting', n: '03', label: 'Consulting', soon: true, x: 87, y: 150 },
  ];
  return (
    <section className="as-hex-section">
      <div className="as-hex-grid">
        {items.map(it => (
          <a key={it.id} href="#" className="as-hex"
             style={{ left: it.x, top: it.y }}
             onClick={(e) => { e.preventDefault(); onNav(it.id); }}>
            <div className={'as-hex-face ' + (it.primary ? 'as-hex-primary' : 'as-hex-dim')} />
            <div className="as-hex-inner">
              <span className="as-hex-num">{it.n}</span>
              <span className={it.primary ? 'as-hex-label' : 'as-hex-label as-hex-label-dim'}>{it.label}</span>
              {it.soon && <span className="as-hex-soon">Soon</span>}
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}

function FeatureCard({ tone, eyebrow, title, children }) {
  return (
    <div className={'as-feature as-feature-' + tone}>
      <p className={'as-eyebrow as-eyebrow-' + tone}>{eyebrow}</p>
      <h2 className="as-h2">{title}</h2>
      <p className="as-feature-body">{children}</p>
    </div>
  );
}

function Home({ onNav }) {
  const taglines = [
    'Advanced statistics. Taught and applied.',
    'High-level statistical training and expert consulting.',
    'The statistics support you need. Taught and delivered.',
  ];
  return (
    <div>
      <section className="as-hero">
        <div className="as-hero-inner">
          <p className="as-hero-tagline">
            <Typewriter phrases={taglines} />
          </p>
          <div className="as-hero-title-wrap">
            <h1 className="as-hero-title">AstroStat<br />Academy</h1>
            <div className="as-hero-stat"><HeroStat /></div>
          </div>
          <p className="as-hero-sub">Take control of your statistics.</p>
        </div>
      </section>

      <section className="as-what">
        <SectionHead eyebrow="What we do" title="Three ways we work">
          Hands-on schools today, with hackatons and enterprise consulting on the way.
        </SectionHead>
        <HexNav onNav={onNav} />
      </section>

      <section className="as-who">
        <div className="as-who-inner">
          <p className="as-eyebrow as-eyebrow-red">Who we are</p>
          <h2 className="as-section-title">A collective of astronomers &amp; statisticians</h2>
          <p className="as-who-body">
            AstroStat Academy is run by working astronomers, statisticians, and machine-learning
            practitioners drawn from research institutes and universities across Europe and beyond.
            Between us we have taught seven schools and supervised hundreds of early-career
            researchers, spanning Bayesian inference, Gaussian processes, MCMC, deep learning, and
            large-survey data analysis. We teach the tools we use in our own research.
          </p>
          <a href="#" className="as-btn as-btn-ghost"
             onClick={(e) => { e.preventDefault(); onNav('people'); }}>
            Meet our people →
          </a>
        </div>
      </section>

      <section className="as-mission">
        <SectionHead eyebrow="Why we exist" title="Mission &amp; Goals" />
        <div className="as-mission-grid">
        <FeatureCard tone="blue" eyebrow="01 · Mission" title="Our Mission">
          Astronomy generates petabytes of data. Making sense of it requires rigorous statistical
          thinking. AstroStat Academy bridges the gap between modern statistics and observational
          astronomy through hands-on, expert-led schools for PhD students and early-career researchers.
        </FeatureCard>
        <FeatureCard tone="red" eyebrow="02 · Goals" title="Our Goals">
          We aim to raise statistical literacy across the astronomical community — equipping
          researchers with the modern probabilistic and machine-learning tools they need to
          extract knowledge from today's large surveys and tomorrow's petabyte telescopes.
        </FeatureCard>
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { HexNav, FeatureCard, Home });
