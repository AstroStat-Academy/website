# AstroStat Academy — archived design reference

Archived on 2026-09-15 after migration to Vite + React.

This package preserves the category 2 files from the cleanup report, including
`deploy/api/papers.js`, plus snapshots of the shared styles, active assets and
PageHeader needed to view the original site overview. Live dependencies were
copied into this package and remain in the website project.

Extract this package into a separate folder, serve the extracted
`astrostat-design-reference` folder with a static server, and open
`site/Site%20Overview.html`. The prototype still requires network access for
CDN React/Babel and fonts. Historical instructions and links describe the old
project; links to deleted scratch images, thumbnails, exports and older UI kits
are intentionally not preserved. The two category 3 assets are also excluded
from the shared asset snapshot. The overview uses the retained bone logo and
JPG profile photo.

These are historical reference files, not the live application or current
instructions. Do not deploy this package as the website. The live site is
built from src/ using npm run build.

MANIFEST.json records SHA-256 hashes of every original file in this archive.
