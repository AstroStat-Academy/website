/* PageHeader — THE default page header for every AstroStat Academy page.
   Panel frame + channel bar + mono kicker + display title + lede.
   Formatting is locked here: do not restyle headers per page. */
const PH = {
  panel: { position: 'relative', border: '1px solid rgba(var(--bone-rgb),.18)', background: 'rgba(0,0,0,.55)' },
  body: { padding: '40px 32px 0' },
  kicker: { fontFamily: 'var(--font-mono)', fontSize: 13, letterSpacing: '.2em', textTransform: 'uppercase', color: 'rgba(var(--bone-rgb),.4)' },
  kickerB: { color: 'var(--accent)', fontWeight: 600 },
  title: { fontSize: 46, fontWeight: 700, letterSpacing: '-.03em', lineHeight: .94, margin: '14px 0 0', whiteSpace: 'pre-line', color: 'var(--fg1)' },
  lede: { fontSize: 17, fontWeight: 600, letterSpacing: '-.01em', color: 'var(--fg1)', margin: '16px 0 0' },
  corner: { position: 'absolute', width: 9, height: 9, borderColor: 'rgba(var(--bone-rgb),.55)', borderStyle: 'solid', borderWidth: 0 },
};
const PH_CORNERS = [
  { top: -1, left: -1, borderTopWidth: 1, borderLeftWidth: 1 },
  { top: -1, right: -1, borderTopWidth: 1, borderRightWidth: 1 },
  { bottom: -1, left: -1, borderBottomWidth: 1, borderLeftWidth: 1 },
  { bottom: -1, right: -1, borderBottomWidth: 1, borderRightWidth: 1 },
];

export function PageHeader({ section, kicker, title, lede, accent = 'blue', variant, channel, status, background, aside, children }) {
  // Compatibility layouts preserve the approved prototype during the site migration.
  // The default remains the shared 46px page header used by the design system.
  if (variant === 'home') return (
    <div className="as-hero-l">
      <div className="as-tagline">{kicker}<span className="as-cur"></span></div>
      <h1 className="as-title">{title.split('\n').map((line, i) => <span key={i}>{i > 0 && <br />}{line}</span>)}</h1>
      <div className="as-lede">{lede}</div>
      {children}
    </div>
  );
  if (variant === 'console') return <>
    <div className="ph-con-head">
      <span className="as-tagline">{channel} · {section}</span>
      <span className="ph-con-coord">{status}</span>
    </div>
    <div className="ph-split">
      <div className="ph-split-l">
        {background}
        <div className="ph-split-in">
          <div className="ph-con-num">// {section} <b>— {kicker}</b></div>
          <h1 className="ph-con-title">{title}</h1>
          <p className="ph-con-lede">{lede}</p>
        </div>
      </div>
      <div className="ph-split-r">{aside}</div>
    </div>
  </>;
  if (variant === 'credit') return <>
    <span className="as-eyebrow">{section}</span>
    <h1 className="as-h1pg" style={{ marginTop: 10 }}>{title.split('\n').map((line, i) => <span key={i}>{i > 0 && <br />}{line}</span>)}</h1>
    <p className="as-p">{lede}</p>
    {children}
  </>;
  const accentVar = accent === 'red' ? 'var(--red)' : accent === 'teal' ? 'var(--teal)' : 'var(--blue)';
  return (
    <div style={{ ...PH.panel, '--accent': accentVar }}>
      {PH_CORNERS.map((c, i) => <span key={i} style={{ ...PH.corner, ...c }}></span>)}
      <div style={PH.body}>
        {kicker && <div style={PH.kicker}>// {section} <b style={PH.kickerB}>— {kicker}</b></div>}
        <h1 style={PH.title}>{title}</h1>
        {lede && <p style={PH.lede}>{lede}</p>}
        {children}
      </div>
    </div>
  );
}
