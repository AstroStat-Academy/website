import type * as React from 'react';

/** THE default page header. Every page uses this — panel frame, channel bar,
 *  mono kicker, 46px display title, 17px lede. Never hand-roll a page header. */
export interface PageHeaderProps {
  /** page name, e.g. "People" — shown in the channel bar and the kicker */
  section: string;
  /** kicker suffix after "// <section> — ", e.g. "who we are" */
  kicker?: string;
  /** display title; \n renders as a line break */
  title: string;
  /** one-line subtitle */
  lede?: React.ReactNode;
  /** accent family. Default "blue" */
  accent?: 'blue' | 'red' | 'teal';
  /** Migration layouts retain the approved home, service, and credit designs. */
  variant?: 'home' | 'console' | 'credit';
  channel?: React.ReactNode;
  status?: React.ReactNode;
  background?: React.ReactNode;
  aside?: React.ReactNode;
  children?: React.ReactNode;
}

export declare function PageHeader(props: PageHeaderProps): JSX.Element;
