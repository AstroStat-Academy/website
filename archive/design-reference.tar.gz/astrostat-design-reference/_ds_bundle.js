/* @ds-bundle: {"format":4,"namespace":"AstroStatAcademyDesignSystem_b004a7","components":[{"name":"PageHeader","sourcePath":"components/PageHeader/PageHeader.jsx"}],"sourceHashes":{"components/PageHeader/PageHeader.jsx":"cb392f3392d5","deploy/api/papers.js":"d34573e33830","deploy/app.jsx":"b5a50c37103e","deploy/chrome.jsx":"ff5d258bfa6a","deploy/data.jsx":"6a96426e1a93","deploy/effects.jsx":"5f296f569e8f","deploy/home.jsx":"4bb6a03f4ef4","deploy/people.jsx":"f3e12f6caf7d","deploy/schools.jsx":"dffbbca407ec","explorations/design-canvas.jsx":"bd8746af6e58","explorations/page-hero-options.jsx":"b663ad54aa81","explorations/page-people-terminal-standalone.jsx":"d1ae73ad0572","explorations/page-people-terminal.jsx":"a1495fe95479","explorations/school-options.jsx":"5321eaa61735","explorations/site-effects.jsx":"919f261c141b","explorations/stat-viz.jsx":"676c707bb3b8","explorations/world-land.js":"479357ae4eda","site/page-detail.jsx":"36b9694df358","site/page-home.jsx":"f315792a6b74","site/page-people.jsx":"45f7677f5778","site/page-schools.jsx":"08091f9fdea9","site/site-kit.jsx":"47112da089c5","ui_kits/website/app.jsx":"b5a50c37103e","ui_kits/website/chrome.jsx":"c1b7ab702ec6","ui_kits/website/data.jsx":"6a96426e1a93","ui_kits/website/effects.jsx":"5f296f569e8f","ui_kits/website/home.jsx":"4bb6a03f4ef4","ui_kits/website/people.jsx":"0c54efc75ef2","ui_kits/website/schools.jsx":"dffbbca407ec"},"inlinedExternals":[],"unexposedExports":[{"name":"handler","sourcePath":"deploy/api/papers.js"}]} */

(() => {

const __ds_ns = (window.AstroStatAcademyDesignSystem_b004a7 = window.AstroStatAcademyDesignSystem_b004a7 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/PageHeader/PageHeader.jsx
try { (() => {
/* PageHeader — THE default page header for every AstroStat Academy page.
   Panel frame + channel bar + mono kicker + display title + lede.
   Formatting is locked here: do not restyle headers per page. */
const PH = {
  panel: {
    position: 'relative',
    border: '1px solid rgba(var(--bone-rgb),.18)',
    background: 'rgba(0,0,0,.55)'
  },
  body: {
    padding: '40px 32px 0'
  },
  kicker: {
    fontFamily: 'var(--font-mono)',
    fontSize: 13,
    letterSpacing: '.2em',
    textTransform: 'uppercase',
    color: 'rgba(var(--bone-rgb),.4)'
  },
  kickerB: {
    color: 'var(--accent)',
    fontWeight: 600
  },
  title: {
    fontSize: 46,
    fontWeight: 700,
    letterSpacing: '-.03em',
    lineHeight: .94,
    margin: '14px 0 0',
    whiteSpace: 'pre-line',
    color: 'var(--fg1)'
  },
  lede: {
    fontSize: 17,
    fontWeight: 600,
    letterSpacing: '-.01em',
    color: 'var(--fg1)',
    margin: '16px 0 0'
  },
  corner: {
    position: 'absolute',
    width: 9,
    height: 9,
    borderColor: 'rgba(var(--bone-rgb),.55)',
    borderStyle: 'solid',
    borderWidth: 0
  }
};
const PH_CORNERS = [{
  top: -1,
  left: -1,
  borderTopWidth: 1,
  borderLeftWidth: 1
}, {
  top: -1,
  right: -1,
  borderTopWidth: 1,
  borderRightWidth: 1
}, {
  bottom: -1,
  left: -1,
  borderBottomWidth: 1,
  borderLeftWidth: 1
}, {
  bottom: -1,
  right: -1,
  borderBottomWidth: 1,
  borderRightWidth: 1
}];
function PageHeader({
  section,
  kicker,
  title,
  lede,
  accent = 'blue',
  children
}) {
  const accentVar = accent === 'red' ? 'var(--red)' : accent === 'teal' ? 'var(--teal)' : 'var(--blue)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...PH.panel,
      '--accent': accentVar
    }
  }, PH_CORNERS.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      ...PH.corner,
      ...c
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: PH.body
  }, kicker && /*#__PURE__*/React.createElement("div", {
    style: PH.kicker
  }, "// ", section, " ", /*#__PURE__*/React.createElement("b", {
    style: PH.kickerB
  }, "\u2014 ", kicker)), /*#__PURE__*/React.createElement("h1", {
    style: PH.title
  }, title), lede && /*#__PURE__*/React.createElement("p", {
    style: PH.lede
  }, lede), children));
}
Object.assign(__ds_scope, { PageHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/PageHeader/PageHeader.jsx", error: String((e && e.message) || e) }); }

// deploy/api/papers.js
try { (() => {
// Vercel serverless function — papers that credit AstroStat Academy.
//
// Discovery is by ACKNOWLEDGEMENT text, which only a full-text index can do.
// NASA ADS indexes acknowledgements (and covers arXiv preprints), so we query
// ADS and hand back arXiv links.
//
// Setup:  vercel env add ADS_TOKEN     (free token: https://ui.adsabs.harvard.edu/user/settings/token)
// Without a token the endpoint serves the committed snapshot in assets/papers.json.

const PHRASES = ['Summer School for Astrostatistics in Crete', 'AstroStat Academy'];
const ADS = 'https://api.adsabs.harvard.edu/v1/search/query';
const FIELDS = 'bibcode,title,author,year,pubdate,pub,doi,identifier,citation_count';
function arxivId(identifiers = []) {
  for (const id of identifiers) {
    const m = /^arxiv:(.+)$/i.exec(id);
    if (m) return m[1];
  }
  return null;
}
function normalise(doc) {
  const ax = arxivId(doc.identifier);
  return {
    bibcode: doc.bibcode,
    title: Array.isArray(doc.title) ? doc.title[0] : doc.title,
    authors: doc.author || [],
    year: doc.year ? Number(doc.year) : null,
    pubdate: doc.pubdate || null,
    journal: doc.pub || null,
    doi: doc.doi ? doc.doi[0] : null,
    arxiv: ax,
    url: ax ? `https://arxiv.org/abs/${ax}` : `https://ui.adsabs.harvard.edu/abs/${encodeURIComponent(doc.bibcode)}`,
    citations: typeof doc.citation_count === 'number' ? doc.citation_count : null
  };
}
async function handler(req, res) {
  const token = process.env.ADS_TOKEN;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  // Cached at the edge for a day; stale copies keep serving while it revalidates.
  res.setHeader('Cache-Control', 's-maxage=86400, stale-while-revalidate=604800');
  if (!token) {
    return res.status(200).json({
      updated: null,
      source: 'none',
      note: 'ADS_TOKEN is not set — no automated discovery. Add the env var in Vercel.',
      papers: []
    });
  }
  const q = PHRASES.map(p => `full:"${p}"`).join(' OR ');
  const url = `${ADS}?q=${encodeURIComponent(q)}&fl=${FIELDS}&rows=200&sort=${encodeURIComponent('date desc')}`;
  try {
    const r = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    if (!r.ok) throw new Error(`ADS ${r.status}`);
    const data = await r.json();
    const papers = (data.response?.docs || []).map(normalise);
    return res.status(200).json({
      updated: new Date().toISOString(),
      source: 'ads',
      query: q,
      count: papers.length,
      papers
    });
  } catch (err) {
    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json({
      updated: null,
      source: 'error',
      note: String(err.message || err),
      papers: []
    });
  }
}
Object.assign(__ds_scope, { handler, __ds_default_deploy_api_papers_1d0mqdx: handler });
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/api/papers.js", error: String((e && e.message) || e) }); }

// deploy/app.jsx
try { (() => {
/* AstroStat Academy — UI kit: app shell + routing */

function App() {
  const [route, setRoute] = React.useState('home'); // home | schools | school | hackatons | consulting | people
  const [slug, setSlug] = React.useState(null);
  const [dark, setDark] = React.useState(true);
  const nav = r => {
    if (r === 'home') {
      setRoute('home');
    } else {
      setRoute(r);
    }
    setSlug(null);
    window.scrollTo({
      top: 0
    });
  };
  const openSchool = s => {
    setSlug(s);
    setRoute('school');
    window.scrollTo({
      top: 0
    });
  };
  let view;
  if (route === 'home') view = /*#__PURE__*/React.createElement(Home, {
    onNav: nav
  });else if (route === 'schools') view = /*#__PURE__*/React.createElement(SchoolsView, {
    onOpen: openSchool
  });else if (route === 'school') view = /*#__PURE__*/React.createElement(SchoolDetail, {
    slug: slug,
    onBack: () => nav('schools')
  });else if (route === 'people') view = /*#__PURE__*/React.createElement(People, {
    onNav: nav
  });else view = /*#__PURE__*/React.createElement(ComingSoon, {
    route: route
  });
  return /*#__PURE__*/React.createElement("div", {
    className: 'as-root' + (dark ? '' : ' as-light')
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-rain"
  }, dark && /*#__PURE__*/React.createElement(CodeRain, null)), /*#__PURE__*/React.createElement(Nav, {
    route: route,
    onNav: nav,
    dark: dark,
    onToggleTheme: () => setDark(d => !d)
  }), /*#__PURE__*/React.createElement("main", {
    className: "as-main"
  }, view), /*#__PURE__*/React.createElement(Footer, {
    onNav: nav
  }));
}

/* Demo mount — opt-in only. The compiled bundle is loaded by many pages that
   own their own #root, so this must never auto-mount there. The ui_kit's own
   demo HTML sets data-uikit-demo on its container. */
const appRoot = document.querySelector('#root[data-uikit-demo]');
if (appRoot) ReactDOM.createRoot(appRoot).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/app.jsx", error: String((e && e.message) || e) }); }

// deploy/chrome.jsx
try { (() => {
/* AstroStat Academy — UI kit: chrome (Nav, Footer, ThemeToggle) */

function ThemeToggle({
  dark,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "as-toggle",
    onClick: onToggle,
    "aria-label": dark ? 'Switch to light mode' : 'Switch to dark mode'
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-toggle-knob",
    style: {
      transform: dark ? 'translateX(20px)' : 'translateX(0)'
    }
  }, dark ? '☾' : '☼'));
}
function Nav({
  route,
  onNav,
  dark,
  onToggleTheme
}) {
  const links = [{
    id: 'schools',
    label: 'Schools'
  }, {
    id: 'hackatons',
    label: 'Hackatons'
  }, {
    id: 'consulting',
    label: 'Consulting'
  }];
  const active = id => route === id || id === 'schools' && route === 'school';
  return /*#__PURE__*/React.createElement("nav", {
    className: "as-nav-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-nav"
  }, /*#__PURE__*/React.createElement("a", {
    className: "as-brand",
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('home');
    }
  }, /*#__PURE__*/React.createElement("img", {
    className: "as-brand-mark",
    src: dark ? 'assets/logo-bone.svg' : 'assets/logo.svg',
    alt: "",
    "aria-hidden": "true"
  }), "AstroStat Academy"), /*#__PURE__*/React.createElement("ul", {
    className: "as-nav-links"
  }, links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l.id
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav(l.id);
    },
    className: active(l.id) ? 'as-link as-link-active' : 'as-link'
  }, l.label))), /*#__PURE__*/React.createElement("li", {
    "aria-hidden": "true",
    className: "as-nav-sep"
  }), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(ThemeToggle, {
    dark: dark,
    onToggle: onToggleTheme
  })), /*#__PURE__*/React.createElement("li", {
    "aria-hidden": "true",
    className: "as-nav-sep"
  }), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('people');
    },
    className: route === 'people' ? 'as-link as-link-active' : 'as-link'
  }, "People")))));
}
function Footer({
  onNav
}) {
  return /*#__PURE__*/React.createElement("footer", {
    className: "as-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-footer-inner"
  }, /*#__PURE__*/React.createElement("p", null, "\xA9 ", new Date().getFullYear(), " AstroStat Academy. All rights reserved."), /*#__PURE__*/React.createElement("div", {
    className: "as-footer-links"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('schools');
    }
  }, "Schools"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('consulting');
    }
  }, "Consulting"))));
}
Object.assign(window, {
  Nav,
  Footer,
  ThemeToggle
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/chrome.jsx", error: String((e && e.message) || e) }); }

// deploy/data.jsx
try { (() => {
/* AstroStat Academy — UI kit: school content data
   Derived from academy-website-short/src/content/schools/*.md.
   Attendee counts are approximate (used by the attendance chart). */

window.SCHOOLS = [{
  slug: 'school-2019-heraklion',
  title: 'AstroStat School I — Heraklion 2019',
  date: '2019-07-08',
  endDate: '2019-07-19',
  location: 'Heraklion, Crete, Greece',
  description: 'The inaugural AstroStat School: two weeks of foundational statistical training for astronomers, hosted in Heraklion.',
  lecturers: [],
  topics: ['Statistical methods', 'Bayesian inference', 'Hypothesis testing'],
  attendees: 28,
  body: 'The first edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2022-heraklion',
  title: 'AstroStat School II — Heraklion 2022',
  date: '2022-07-04',
  endDate: '2022-07-15',
  location: 'Heraklion, Crete, Greece',
  description: 'The second edition of the AstroStat School, returning to Heraklion with an expanded machine-learning track.',
  lecturers: [],
  topics: ['Bayesian inference', 'Machine learning for astronomy', 'MCMC methods'],
  attendees: 41,
  body: 'The second edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2023-heraklion',
  title: 'AstroStat School III — Heraklion 2023',
  date: '2023-07-10',
  endDate: '2023-07-21',
  location: 'Heraklion, Crete, Greece',
  description: 'The third edition of the AstroStat School, with deep-learning and Gaussian-process tutorials added to the programme.',
  lecturers: [],
  topics: ['Deep Learning', 'Gaussian Processes', 'Bayesian inference', 'Time Series Analysis'],
  attendees: 47,
  body: 'The third edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2024-heraklion',
  title: 'AstroStat School IV — Heraklion 2024',
  date: '2024-07-01',
  location: 'Heraklion, Crete, Greece',
  description: 'The fourth edition of the AstroStat School, hosted in Heraklion.',
  lecturers: [],
  topics: ['Statistical methods', 'Bayesian inference', 'Machine learning for astronomy'],
  attendees: 52,
  body: 'The fourth edition of the AstroStat School, hosted in Heraklion.\n\n> Exact dates and full programme details to be filled in.'
}, {
  slug: 'school-2025-heraklion',
  title: 'AstroStat School V — Heraklion 2025',
  date: '2025-07-07',
  endDate: '2025-07-18',
  location: 'Heraklion, Crete, Greece',
  description: 'The fifth edition of the AstroStat School, with a new GPU-parallelization and deep-learning intensive.',
  lecturers: [],
  topics: ['Deep Learning', 'GPU Parallelization', 'Markov Chain Monte Carlo', 'Gaussian Processes'],
  attendees: 58,
  body: 'The fifth edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2025-sharjah',
  title: 'AstroStat School VI — Sharjah 2025',
  date: '2025-11-17',
  endDate: '2025-11-21',
  location: 'Sharjah, United Arab Emirates',
  description: 'The sixth AstroStat School, the first hosted outside Europe, in partnership with the Sharjah Academy for Astronomy, Space Sciences & Technology.',
  lecturers: [],
  topics: ['Classical & Bayesian Statistics', 'Machine Learning Practices', 'Time Series Analysis'],
  attendees: 44,
  body: 'The sixth AstroStat School — and the first edition hosted outside Europe — held in Sharjah, UAE.'
}, {
  slug: 'school-2026-rome',
  title: 'AstroStat School VII — Rome 2026',
  date: '2026-07-27',
  endDate: '2026-07-31',
  location: 'DotCampus, Rome, Italy',
  description: 'The seventh AstroStat School, hosted at DotCampus in Rome. A week of intensive lectures and hands-on tutorials covering classical and Bayesian statistics, deep learning, Gaussian processes, MCMC, and more.',
  lecturers: [{
    name: 'Dr. Paolo Bonfini',
    affiliation: 'UniversiData srl'
  }, {
    name: 'Dr. Konstantinos Kovlakas',
    affiliation: 'Institute of Space Sciences'
  }, {
    name: 'Dr. Grigoris Maravelias',
    affiliation: 'PeriAstron'
  }, {
    name: 'Andreas Tersenov',
    affiliation: 'FORTH & CEA Paris-Saclay'
  }, {
    name: 'Nikolas Vasilas',
    affiliation: 'Max Planck Institute for Extraterrestrial Physics'
  }, {
    name: 'Prof. Giorgos Vernardos',
    affiliation: 'Lehman College, CUNY'
  }],
  topics: ['Classical & Bayesian Statistics', 'AI Agents', 'Deep Learning', 'Gaussian Processes', 'Markov Chain Monte Carlo', 'Machine Learning Practices', 'Time Series Analysis', 'GPU Parallelization'],
  applicationUrl: '#apply',
  body: 'The seventh AstroStat School will be held from **27–31 July 2026** at **DotCampus, Rome**. The programme covers classical and Bayesian statistics, AI agents, deep learning, Gaussian processes, MCMC, machine-learning practices, time-series analysis, and GPU parallelization.\n\n## Detailed Schedule\n\nTo be announced.'
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/data.jsx", error: String((e && e.message) || e) }); }

// deploy/effects.jsx
try { (() => {
/* AstroStat Academy — UI kit: generative effects
   CodeRain (full-bleed background), Typewriter (rotating taglines),
   HeroStat (the interactive Gaussian-histogram / time-series hero widget).
   Simplified, cosmetic recreations of the site's canvas effects.        */

const RAIN_CHARS = 'αβγδεζηθικλμνξπρστφχψωΛΦΨΩΣ∑∏∫∮∂∇∆√∛∝∞≈≅≠≡≤≥±∓×÷∀∃∈∉⊂⊃⊆∪∩∅∴∵⊕⊗⊙ℓℏℝℕ☉★✦0123456789';
const RED_RGB = '140, 5, 39';
const BLUE_RGB = '4, 101, 173';

/* ── Full-page falling code rain (crimson, translucent) ─────────────── */
function CodeRain() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const FONT = 16,
      FRAME = 110;
    let columns = 0,
      drops = [],
      raf = 0,
      last = 0;
    const init = () => {
      const w = canvas.parentElement.clientWidth;
      const h = canvas.parentElement.clientHeight;
      canvas.width = w;
      canvas.height = h;
      columns = Math.floor(w / FONT);
      drops = Array.from({
        length: columns
      }, () => Math.random() * h / FONT);
    };
    const tick = now => {
      raf = requestAnimationFrame(tick);
      if (now - last < FRAME) return;
      last = now;
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = FONT + 'px ui-monospace, monospace';
      ctx.textBaseline = 'top';
      for (let i = 0; i < columns; i++) {
        ctx.fillStyle = `rgba(${RED_RGB}, 0.5)`;
        ctx.fillText(RAIN_CHARS[Math.random() * RAIN_CHARS.length | 0], i * FONT, drops[i] * FONT);
        if (drops[i] * FONT > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    };
    init();
    raf = requestAnimationFrame(tick);
    window.addEventListener('resize', init);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', init);
    };
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none'
    }
  });
}

/* ── Typewriter rotating taglines with blinking block cursor ─────────── */
function Typewriter({
  phrases
}) {
  const [text, setText] = React.useState('');
  const [del, setDel] = React.useState(false);
  const [idx, setIdx] = React.useState(0);
  const [cur, setCur] = React.useState(true);
  React.useEffect(() => {
    const id = setInterval(() => setCur(c => !c), 530);
    return () => clearInterval(id);
  }, []);
  React.useEffect(() => {
    const phrase = phrases[idx % phrases.length];
    let t;
    if (!del) {
      if (text.length < phrase.length) t = setTimeout(() => setText(phrase.slice(0, text.length + 1)), 72 * (0.6 + Math.random() * 0.8));else t = setTimeout(() => setDel(true), 2200);
    } else {
      if (text.length > 0) t = setTimeout(() => setText(text.slice(0, -1)), 28);else t = setTimeout(() => {
        setDel(false);
        setIdx(i => i + 1);
      }, 380);
    }
    return () => clearTimeout(t);
  }, [text, del, idx, phrases]);
  return /*#__PURE__*/React.createElement("span", null, text, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      opacity: cur ? 1 : 0
    }
  }, "\u2588"));
}

/* ── Interactive hero histogram — drag the blue dot (mean) / grips (σ) ── */
function HeroStat() {
  const ref = React.useRef(null);
  const state = React.useRef({
    mean: 0.5,
    sigma: 0.18,
    drag: 'none'
  });
  React.useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const W = 400,
      H = 150,
      BASE = 120;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.scale(dpr, dpr);
    let raf = 0,
      last = 0;
    const draw = now => {
      raf = requestAnimationFrame(draw);
      if (now - last < 90) return;
      last = now;
      ctx.clearRect(0, 0, W, H);
      const {
        mean,
        sigma
      } = state.current;
      const cols = 26,
        bw = W / cols,
        amp = BASE * 0.92;
      const wig = now / 900;
      for (let k = 0; k < cols; k++) {
        const xf = (k + 0.5) / cols;
        const g = Math.exp(-0.5 * ((xf - mean) / Math.max(sigma, 0.01)) ** 2);
        const bh = Math.max(0, g * amp + Math.sin(wig + k * 0.73) * 4 * g);
        ctx.fillStyle = `rgba(${BLUE_RGB}, 0.30)`;
        ctx.fillRect(k * bw + 1.5, BASE - bh + 2, bw - 1, bh);
        ctx.fillStyle = `rgba(${RED_RGB}, ${0.55 + g * 0.35})`;
        ctx.fillRect(k * bw + 0.5, BASE - bh, bw - 1, bh);
      }
      // widget: pill + mean dot + grips
      const mx = mean * W,
        half = sigma * W;
      const lx = Math.max(8, mx - half),
        rx = Math.min(W - 8, mx + half);
      const py = BASE + 16,
        pulse = 0.5 + 0.5 * Math.sin(now / 2000 * Math.PI * 2);
      ctx.strokeStyle = `rgba(${BLUE_RGB}, 0.45)`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(lx, py - 3, rx - lx, 6, 3);
      ctx.stroke();
      const grip = x => {
        ctx.save();
        ctx.shadowColor = `rgba(${BLUE_RGB},0.5)`;
        ctx.shadowBlur = 3 + pulse * 4;
        ctx.fillStyle = `rgba(${BLUE_RGB}, ${0.65 + pulse * 0.1})`;
        ctx.beginPath();
        ctx.roundRect(x - 3, py - 8, 6, 16, 3);
        ctx.fill();
        ctx.restore();
      };
      grip(lx);
      grip(rx);
      ctx.save();
      ctx.shadowColor = `rgba(${BLUE_RGB},0.5)`;
      ctx.shadowBlur = 3 + pulse * 4;
      ctx.fillStyle = `rgba(${BLUE_RGB}, ${0.65 + pulse * 0.1})`;
      ctx.beginPath();
      ctx.arc(mx, py, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };
    raf = requestAnimationFrame(draw);
    const pos = e => {
      const r = canvas.getBoundingClientRect();
      return {
        x: e.clientX - r.left,
        y: e.clientY - r.top
      };
    };
    const down = e => {
      const {
        x
      } = pos(e);
      const {
        mean,
        sigma
      } = state.current;
      const mx = mean * W,
        lx = mx - sigma * W,
        rx = mx + sigma * W;
      if (Math.abs(x - mx) < 12) state.current.drag = 'move';else if (Math.abs(x - lx) < 10 || Math.abs(x - rx) < 10) state.current.drag = 'sigma';
      canvas.setPointerCapture(e.pointerId);
    };
    const move = e => {
      const {
        x
      } = pos(e);
      const d = state.current.drag;
      if (d === 'move') state.current.mean = Math.max(0.05, Math.min(0.95, x / W));else if (d === 'sigma') state.current.sigma = Math.max(0.05, Math.min(0.4, Math.abs(x - state.current.mean * W) / W));
      canvas.style.cursor = d !== 'none' ? 'grabbing' : 'grab';
    };
    const up = () => {
      state.current.drag = 'none';
      canvas.style.cursor = 'grab';
    };
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    return () => cancelAnimationFrame(raf);
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    style: {
      cursor: 'grab',
      touchAction: 'none'
    },
    title: "Drag the mean & \u03C3"
  });
}
Object.assign(window, {
  CodeRain,
  Typewriter,
  HeroStat
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/effects.jsx", error: String((e && e.message) || e) }); }

// deploy/home.jsx
try { (() => {
/* AstroStat Academy — UI kit: home view (hero, hex honeycomb, mission cards) */

function SectionHead({
  eyebrow,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-section-head"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-blue"
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "as-section-title"
  }, title), children && /*#__PURE__*/React.createElement("p", {
    className: "as-section-sub"
  }, children));
}
function HexNav({
  onNav
}) {
  const items = [{
    id: 'schools',
    n: '01',
    label: 'Schools',
    soon: false,
    x: 0,
    y: 0,
    primary: true
  }, {
    id: 'hackatons',
    n: '02',
    label: 'Hackatons',
    soon: true,
    x: 173,
    y: 0
  }, {
    id: 'consulting',
    n: '03',
    label: 'Consulting',
    soon: true,
    x: 87,
    y: 150
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "as-hex-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-hex-grid"
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.id,
    href: "#",
    className: "as-hex",
    style: {
      left: it.x,
      top: it.y
    },
    onClick: e => {
      e.preventDefault();
      onNav(it.id);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'as-hex-face ' + (it.primary ? 'as-hex-primary' : 'as-hex-dim')
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-hex-inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-hex-num"
  }, it.n), /*#__PURE__*/React.createElement("span", {
    className: it.primary ? 'as-hex-label' : 'as-hex-label as-hex-label-dim'
  }, it.label), it.soon && /*#__PURE__*/React.createElement("span", {
    className: "as-hex-soon"
  }, "Soon"))))));
}
function FeatureCard({
  tone,
  eyebrow,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'as-feature as-feature-' + tone
  }, /*#__PURE__*/React.createElement("p", {
    className: 'as-eyebrow as-eyebrow-' + tone
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "as-feature-body"
  }, children));
}
function Home({
  onNav
}) {
  const taglines = ['Advanced statistics. Taught and applied.', 'High-level statistical training and expert consulting.', 'The statistics support you need. Taught and delivered.'];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    className: "as-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-hero-inner"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-hero-tagline"
  }, /*#__PURE__*/React.createElement(Typewriter, {
    phrases: taglines
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-hero-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "as-hero-title"
  }, "AstroStat", /*#__PURE__*/React.createElement("br", null), "Academy"), /*#__PURE__*/React.createElement("div", {
    className: "as-hero-stat"
  }, /*#__PURE__*/React.createElement(HeroStat, null))), /*#__PURE__*/React.createElement("p", {
    className: "as-hero-sub"
  }, "Take control of your statistics."))), /*#__PURE__*/React.createElement("section", {
    className: "as-what"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "What we do",
    title: "Three ways we work"
  }, "Hands-on schools today, with hackatons and enterprise consulting on the way."), /*#__PURE__*/React.createElement(HexNav, {
    onNav: onNav
  })), /*#__PURE__*/React.createElement("section", {
    className: "as-who"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-who-inner"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-red"
  }, "Who we are"), /*#__PURE__*/React.createElement("h2", {
    className: "as-section-title"
  }, "A collective of astronomers & statisticians"), /*#__PURE__*/React.createElement("p", {
    className: "as-who-body"
  }, "AstroStat Academy is run by working astronomers, statisticians, and machine-learning practitioners drawn from research institutes and universities across Europe and beyond. Between us we have taught seven schools and supervised hundreds of early-career researchers, spanning Bayesian inference, Gaussian processes, MCMC, deep learning, and large-survey data analysis. We teach the tools we use in our own research."), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "as-btn as-btn-ghost",
    onClick: e => {
      e.preventDefault();
      onNav('people');
    }
  }, "Meet our people \u2192"))), /*#__PURE__*/React.createElement("section", {
    className: "as-mission"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "Why we exist",
    title: "Mission & Goals"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-mission-grid"
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    tone: "blue",
    eyebrow: "01 \xB7 Mission",
    title: "Our Mission"
  }, "Astronomy generates petabytes of data. Making sense of it requires rigorous statistical thinking. AstroStat Academy bridges the gap between modern statistics and observational astronomy through hands-on, expert-led schools for PhD students and early-career researchers."), /*#__PURE__*/React.createElement(FeatureCard, {
    tone: "red",
    eyebrow: "02 \xB7 Goals",
    title: "Our Goals"
  }, "We aim to raise statistical literacy across the astronomical community \u2014 equipping researchers with the modern probabilistic and machine-learning tools they need to extract knowledge from today's large surveys and tomorrow's petabyte telescopes."))));
}
Object.assign(window, {
  HexNav,
  FeatureCard,
  Home
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/home.jsx", error: String((e && e.message) || e) }); }

// deploy/people.jsx
try { (() => {
/* AstroStat Academy — UI kit: People page
   Renders LIVE from the roster + per-person files under assets/people/:

       assets/people/people.yml          section -> ordered list of slugs
       assets/people/<role>/<slug>.md    front-matter (name, affiliation,
                                         title, photo, links) + bio body
       assets/people/<role>/<slug>.jpg   headshot (optional)

   To change the page, edit those files — NOT this component.
   Remove a slug from people.yml and the person drops off the page while
   their .md / .jpg stay on disk. */

const PEOPLE_BASE = 'assets/people';

// Section labels + layout, keyed by the role folder name.
const ROLE_META = {
  councellors: {
    label: 'Councellors',
    wide: true
  },
  lecturers: {
    label: 'Lecturers',
    wide: false
  },
  TAs: {
    label: 'Teaching assistants',
    wide: false
  },
  advisors: {
    label: 'Advisors',
    wide: false
  }
};

/* ── tiny parsers (no deps) ─────────────────────────────────────── */

// people.yml -> [{ role, slugs: [..] }] in file order.
function parseRoster(text) {
  const sections = [];
  let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, ''); // strip comments
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) {
      cur = {
        role: sec[1],
        slugs: []
      };
      sections.push(cur);
      return;
    }
    const item = line.match(/^\s*-\s*(.+?)\s*$/);
    if (item && cur) cur.slugs.push(item[1]);
  });
  return sections;
}

// <slug>.md -> { name, affiliation, title, photo, links{}, bio }
function parsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = {
    links: {}
  };
  let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s+/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1],
        val = kv[2].trim();
      if (key === 'links' && val === '') {
        inLinks = true;
        return;
      }
      if (inLinks && indented) {
        meta.links[key] = val;
        return;
      }
      inLinks = false;
      meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}

/* ── avatar (photo with initials fallback) ──────────────────────── */

function initials(name) {
  const clean = name.replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '');
  const parts = clean.split(/\s+/);
  return (parts[0][0] + (parts[parts.length - 1][0] || '')).toUpperCase();
}
function toneFor(name) {
  const tones = ['#0465ad', '#8c0527', '#008c8c']; // blue / crimson / teal
  const sum = name.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return tones[sum % tones.length];
}
function Avatar({
  person,
  size
}) {
  const tone = toneFor(person.name);
  const [failed, setFailed] = React.useState(false);
  const show = person.photoUrl && !failed;
  return /*#__PURE__*/React.createElement("span", {
    className: "as-avatar",
    style: {
      width: size,
      height: size,
      borderColor: tone,
      color: tone,
      fontSize: size * 0.34,
      overflow: 'hidden'
    }
  }, show ? /*#__PURE__*/React.createElement("img", {
    src: person.photoUrl,
    alt: person.name,
    width: size,
    height: size,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    },
    onError: () => setFailed(true)
  }) : initials(person.name));
}
function PersonCard({
  person,
  wide
}) {
  const linkEntries = Object.entries(person.links || {});
  return /*#__PURE__*/React.createElement("div", {
    className: wide ? 'as-person as-person-wide' : 'as-person'
  }, /*#__PURE__*/React.createElement(Avatar, {
    person: person,
    size: wide ? 56 : 64
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-person-meta"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-person-name"
  }, person.name), person.affiliation && /*#__PURE__*/React.createElement("p", {
    className: "as-person-aff"
  }, person.affiliation), person.title && /*#__PURE__*/React.createElement("span", {
    className: "as-person-role"
  }, person.title), person.bio && /*#__PURE__*/React.createElement("p", {
    className: "as-person-bio"
  }, person.bio), linkEntries.length > 0 && /*#__PURE__*/React.createElement("p", {
    className: "as-person-links"
  }, linkEntries.map(([label, url]) => /*#__PURE__*/React.createElement("a", {
    key: label,
    className: "as-inline-link",
    href: url,
    target: "_blank",
    rel: "noreferrer"
  }, label, " \u2192")))));
}

/* ── data loading ───────────────────────────────────────────────── */

async function loadPeople() {
  const rosterText = await fetch(`${PEOPLE_BASE}/people.yml`).then(r => {
    if (!r.ok) throw new Error('people.yml not found');
    return r.text();
  });
  const roster = parseRoster(rosterText);
  const sections = await Promise.all(roster.map(async ({
    role,
    slugs
  }) => {
    const people = (await Promise.all(slugs.map(async slug => {
      try {
        const md = await fetch(`${PEOPLE_BASE}/${role}/${slug}.md`).then(r => {
          if (!r.ok) throw new Error(`${role}/${slug}.md missing`);
          return r.text();
        });
        const person = parsePerson(md);
        if (!person.name) person.name = slug;
        const photo = person.photo || `${slug}.jpg`;
        person.photoUrl = `${PEOPLE_BASE}/${role}/${photo}`;
        return person;
      } catch (e) {
        console.warn('[people]', e.message);
        return null;
      }
    }))).filter(Boolean);
    const meta = ROLE_META[role] || {
      label: role,
      wide: false
    };
    return {
      role,
      label: meta.label,
      wide: meta.wide,
      people
    };
  }));
  return sections.filter(s => s.people.length);
}

/* ── page ───────────────────────────────────────────────────────── */

function People({
  onNav
}) {
  const [sections, setSections] = React.useState(null);
  const [error, setError] = React.useState(null);
  React.useEffect(() => {
    loadPeople().then(setSections).catch(e => setError(e.message));
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-blue"
  }, "People"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1"
  }, "Our People"), /*#__PURE__*/React.createElement("p", {
    className: "as-lead"
  }, "AstroStat Academy is run by working astronomers, statisticians, and machine-learning practitioners drawn from research institutes and universities across Europe and beyond.")), error && /*#__PURE__*/React.createElement("p", {
    className: "as-note as-provisional"
  }, "Couldn't load the roster (", error, ")."), !error && sections === null && /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, "Loading people\u2026"), sections && sections.map(section => /*#__PURE__*/React.createElement("section", {
    className: "as-people-section",
    key: section.role
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, section.label), /*#__PURE__*/React.createElement("div", {
    className: `as-people-grid ${section.wide ? 'as-people-grid-2' : 'as-people-grid-3'}`
  }, section.people.map(p => /*#__PURE__*/React.createElement(PersonCard, {
    key: p.name,
    person: p,
    wide: section.wide
  }))))), /*#__PURE__*/React.createElement("section", {
    className: "as-people-cta"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, "Want to lecture at a future school, or collaborate?", ' ', /*#__PURE__*/React.createElement("a", {
    className: "as-inline-link",
    href: "mailto:info@astrostat.academy"
  }, "Get in touch"), ".")));
}
Object.assign(window, {
  People
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/people.jsx", error: String((e && e.message) || e) }); }

// deploy/schools.jsx
try { (() => {
/* AstroStat Academy — UI kit: schools listing, detail, chart, form, placeholders */

const fmtRange = (d, e) => {
  const o = {
    month: 'short',
    day: 'numeric'
  };
  const a = new Date(d),
    b = e ? new Date(e) : null;
  if (b) return `${a.toLocaleDateString('en-US', o)} – ${b.toLocaleDateString('en-US', {
    ...o,
    year: 'numeric'
  })}`;
  return a.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};
const isPast = s => new Date(s.endDate || s.date) < new Date();
function StatusBadge({
  school
}) {
  const past = isPast(school);
  return /*#__PURE__*/React.createElement("span", {
    className: past ? 'as-badge as-badge-past' : 'as-badge as-badge-upcoming'
  }, past ? 'Past' : 'Upcoming');
}
function SchoolCard({
  school,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "as-school-card",
    onClick: e => {
      e.preventDefault();
      onOpen(school.slug);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-school-top"
  }, /*#__PURE__*/React.createElement(StatusBadge, {
    school: school
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-school-date"
  }, new Date(school.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short'
  }))), /*#__PURE__*/React.createElement("h3", {
    className: "as-school-title"
  }, school.title), /*#__PURE__*/React.createElement("p", {
    className: "as-school-loc"
  }, school.location), /*#__PURE__*/React.createElement("p", {
    className: "as-school-desc"
  }, school.description), /*#__PURE__*/React.createElement("div", {
    className: "as-chips"
  }, school.topics.slice(0, 3).map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip"
  }, t)), school.topics.length > 3 && /*#__PURE__*/React.createElement("span", {
    className: "as-chip-more"
  }, "+", school.topics.length - 3, " more")), school.attendees && /*#__PURE__*/React.createElement("p", {
    className: "as-school-att"
  }, school.attendees, " attendees"));
}
function SchoolsView({
  onOpen
}) {
  const all = window.SCHOOLS;
  const [year, setYear] = React.useState('all');
  const [topic, setTopic] = React.useState('all');
  const years = ['all', ...Array.from(new Set(all.map(s => new Date(s.date).getFullYear().toString()))).sort().reverse()];
  const topics = ['all', ...Array.from(new Set(all.flatMap(s => s.topics))).sort()];
  const filtered = all.filter(s => year === 'all' || new Date(s.date).getFullYear().toString() === year).filter(s => topic === 'all' || s.topics.includes(topic)).sort((a, b) => new Date(b.date) - new Date(a.date));
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-blue"
  }, "Training"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1"
  }, "Schools & Workshops"), /*#__PURE__*/React.createElement("p", {
    className: "as-lead"
  }, "Intensive statistical training for the astronomical community.")), /*#__PURE__*/React.createElement("div", {
    className: "as-filters"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, /*#__PURE__*/React.createElement("label", null, "Year"), /*#__PURE__*/React.createElement("select", {
    value: year,
    onChange: e => setYear(e.target.value)
  }, years.map(y => /*#__PURE__*/React.createElement("option", {
    key: y,
    value: y
  }, y === 'all' ? 'All years' : y)))), /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, /*#__PURE__*/React.createElement("label", null, "Topic"), /*#__PURE__*/React.createElement("select", {
    value: topic,
    onChange: e => setTopic(e.target.value)
  }, topics.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t === 'all' ? 'All topics' : t))))), /*#__PURE__*/React.createElement("p", {
    className: "as-count"
  }, filtered.length, " school", filtered.length !== 1 ? 's' : '', " found"), filtered.length === 0 ? /*#__PURE__*/React.createElement("p", {
    className: "as-empty"
  }, "No schools match your filters.") : /*#__PURE__*/React.createElement("div", {
    className: "as-school-grid"
  }, filtered.map(s => /*#__PURE__*/React.createElement(SchoolCard, {
    key: s.slug,
    school: s,
    onOpen: onOpen
  }))));
}

/* Simple SVG bar chart (cosmetic stand-in for the Plotly attendance chart) */
function AttendanceChart({
  highlight
}) {
  const data = window.SCHOOLS.filter(s => s.attendees).sort((a, b) => new Date(a.date) - new Date(b.date));
  const max = Math.max(...data.map(s => s.attendees));
  const W = 760,
    H = 300,
    pad = 44,
    gap = 0.35;
  const bw = (W - pad * 2) / data.length;
  return /*#__PURE__*/React.createElement("div", {
    className: "as-chart"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`,
    width: "100%",
    preserveAspectRatio: "xMidYMid meet"
  }, [0, 0.25, 0.5, 0.75, 1].map(t => {
    const y = pad + (H - pad * 1.4) * (1 - t);
    return /*#__PURE__*/React.createElement("g", {
      key: t
    }, /*#__PURE__*/React.createElement("line", {
      x1: pad,
      y1: y,
      x2: W - pad / 2,
      y2: y,
      stroke: "rgba(255,255,255,0.10)"
    }), /*#__PURE__*/React.createElement("text", {
      x: pad - 8,
      y: y + 4,
      textAnchor: "end",
      fontSize: "11",
      fill: "rgba(251,246,236,0.55)"
    }, Math.round(max * t)));
  }), data.map((s, i) => {
    const bh = s.attendees / max * (H - pad * 1.4);
    const x = pad + i * bw + bw * gap / 2;
    const w = bw * (1 - gap);
    const hi = s.title === highlight;
    return /*#__PURE__*/React.createElement("g", {
      key: s.slug
    }, /*#__PURE__*/React.createElement("rect", {
      x: x,
      y: H - pad * 0.4 - bh,
      width: w,
      height: bh,
      rx: "3",
      fill: hi ? '#8c0527' : '#0465ad',
      opacity: "0.9"
    }, /*#__PURE__*/React.createElement("title", null, s.title, ": ", s.attendees, " attendees")), /*#__PURE__*/React.createElement("text", {
      x: x + w / 2,
      y: H - pad * 0.4 + 16,
      textAnchor: "middle",
      fontSize: "11",
      fill: "rgba(251,246,236,0.55)"
    }, new Date(s.date).toLocaleDateString('en-US', {
      month: 'short',
      year: 'numeric'
    })));
  })));
}
function ApplicationForm({
  schoolTitle
}) {
  const [sent, setSent] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const submit = e => {
    e.preventDefault();
    setBusy(true);
    setTimeout(() => {
      setBusy(false);
      setSent(true);
    }, 800);
  };
  if (sent) return /*#__PURE__*/React.createElement("div", {
    className: "as-form as-form-done"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-form-thanks"
  }, "Thank you!"), /*#__PURE__*/React.createElement("p", {
    className: "as-form-thanks-sub"
  }, "We've noted your interest in ", /*#__PURE__*/React.createElement("strong", null, schoolTitle), ". We'll be in touch."));
  return /*#__PURE__*/React.createElement("form", {
    className: "as-form",
    onSubmit: submit,
    noValidate: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Full name *"), /*#__PURE__*/React.createElement("input", {
    required: true,
    placeholder: "Jane Smith"
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Email address *"), /*#__PURE__*/React.createElement("input", {
    required: true,
    type: "email",
    placeholder: "jane@university.edu"
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Institution"), /*#__PURE__*/React.createElement("input", {
    placeholder: "University or research institute"
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Career stage"), /*#__PURE__*/React.createElement("select", {
    defaultValue: ""
  }, /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, "Select\u2026"), /*#__PURE__*/React.createElement("option", null, "PhD student"), /*#__PURE__*/React.createElement("option", null, "Postdoctoral researcher"), /*#__PURE__*/React.createElement("option", null, "Faculty / staff scientist"), /*#__PURE__*/React.createElement("option", null, "Industry"), /*#__PURE__*/React.createElement("option", null, "Other"))), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Message (optional)"), /*#__PURE__*/React.createElement("textarea", {
    rows: "3",
    placeholder: "Any questions or context you'd like to share\u2026"
  })), /*#__PURE__*/React.createElement("button", {
    className: "as-btn as-btn-primary as-btn-block",
    disabled: busy
  }, busy ? 'Sending…' : 'Submit Interest'));
}
function SchoolDetail({
  slug,
  onBack
}) {
  const s = window.SCHOOLS.find(x => x.slug === slug);
  if (!s) return null;
  const past = isPast(s);
  const html = s.body.replace(/^## (.*)$/gm, '<h2 class="as-prose-h2">$1</h2>').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/^> (.*)$/gm, '<blockquote class="as-prose-quote">$1</blockquote>').split('\n\n').map(p => p.startsWith('<') ? p : `<p>${p}</p>`).join('');
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "as-detail-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-detail-head-inner"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "as-btn as-btn-outline",
    onClick: e => {
      e.preventDefault();
      onBack();
    }
  }, "\u2190 All schools"), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '20px 0 14px'
    }
  }, /*#__PURE__*/React.createElement(StatusBadge, {
    school: s
  })), /*#__PURE__*/React.createElement("h1", {
    className: "as-detail-title"
  }, s.title), /*#__PURE__*/React.createElement("div", {
    className: "as-detail-meta"
  }, /*#__PURE__*/React.createElement("span", null, fmtRange(s.date, s.endDate)), /*#__PURE__*/React.createElement("span", null, s.location), s.attendees && /*#__PURE__*/React.createElement("span", null, s.attendees, " attendees")), s.applicationUrl && !past && /*#__PURE__*/React.createElement("a", {
    href: "#apply",
    className: "as-btn as-btn-primary",
    style: {
      marginTop: 24
    },
    onClick: e => {
      e.preventDefault();
      document.getElementById('as-apply').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Apply Now"))), /*#__PURE__*/React.createElement("div", {
    className: "as-detail-body"
  }, /*#__PURE__*/React.createElement("section", {
    className: "as-prose",
    dangerouslySetInnerHTML: {
      __html: html
    }
  }), s.lecturers.length > 0 && /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Lecturers"), /*#__PURE__*/React.createElement("div", {
    className: "as-lecturers"
  }, s.lecturers.map(l => /*#__PURE__*/React.createElement("div", {
    key: l.name,
    className: "as-lecturer"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-lecturer-name"
  }, l.name), l.affiliation && /*#__PURE__*/React.createElement("p", {
    className: "as-lecturer-aff"
  }, l.affiliation))))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Topics"), /*#__PURE__*/React.createElement("div", {
    className: "as-chips"
  }, s.topics.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip as-chip-lg"
  }, t)))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Attendance History"), /*#__PURE__*/React.createElement(AttendanceChart, {
    highlight: s.title
  }), /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, "Highlighted bar = this school. All attendee counts are approximate.")), /*#__PURE__*/React.createElement("section", {
    id: "as-apply"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Express Interest"), /*#__PURE__*/React.createElement("p", {
    className: "as-note",
    style: {
      marginBottom: 20
    }
  }, past ? 'Interested in future editions? Leave your details and we\'ll notify you.' : 'Not ready to apply? Leave your contact details and we\'ll keep you posted.'), /*#__PURE__*/React.createElement(ApplicationForm, {
    schoolTitle: s.title
  }))));
}
function ComingSoon({
  route
}) {
  const map = {
    hackatons: {
      tone: 'teal',
      eyebrow: 'Hackatons',
      title: 'Hackatons',
      body: 'Our first hackaton is in the works. Stay tuned for details.',
      email: 'info@astrostat.academy',
      q: 'Want to get involved?'
    },
    consulting: {
      tone: 'red',
      eyebrow: 'Consulting',
      title: 'Enterprise Consulting',
      body: 'Tailored statistical consulting for research groups, institutes, and space agencies. We help teams design analyses, choose models, and interpret results — coming soon.',
      email: 'consulting@astrostat.academy',
      q: 'Interested in working with us?'
    },
    people: {
      tone: 'blue',
      eyebrow: 'People',
      title: 'Our People',
      body: 'Our team of astronomers and statisticians will be listed here soon.',
      email: 'info@astrostat.academy',
      q: 'In the meantime, reach us at'
    }
  };
  const c = map[route];
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page as-page-narrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'as-feature as-feature-' + c.tone,
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: 'as-eyebrow as-eyebrow-' + c.tone
  }, c.eyebrow), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1",
    style: {
      marginBottom: 16
    }
  }, c.title), /*#__PURE__*/React.createElement("p", {
    className: "as-lead",
    style: {
      marginBottom: 20
    }
  }, c.body), /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, c.q, " ", /*#__PURE__*/React.createElement("a", {
    className: "as-inline-link",
    href: 'mailto:' + c.email
  }, route === 'people' ? c.email : 'Get in touch'), ".")));
}
Object.assign(window, {
  SchoolsView,
  SchoolDetail,
  ComingSoon
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "deploy/schools.jsx", error: String((e && e.message) || e) }); }

// explorations/design-canvas.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// DesignCanvas.jsx — Figma-ish design canvas wrapper
// Warm gray grid bg + Sections + Artboards + PostIt notes.
// Exports (to window): DesignCanvas, DCSection, DCArtboard, DCPostIt.
// Artboards are reorderable (grip-drag), deletable, labels/titles are
// inline-editable, and any artboard can be opened in a fullscreen focus
// overlay (←/→/Esc). State persists to a .design-canvas.state.json sidecar
// via the host bridge. No assets, no deps.
//
// Usage:
//   <DesignCanvas>
//     <DCSection id="onboarding" title="Onboarding" subtitle="First-run variants">
//       <DCArtboard id="a" label="A · Dusk" width={260} height={480}>…</DCArtboard>
//       <DCArtboard id="b" label="B · Minimal" width={260} height={480}>…</DCArtboard>
//     </DCSection>
//   </DesignCanvas>
//
// Artboards are static design frames, not scroll regions — never use
// height: 100% + overflow: auto/scroll on inner elements; size each artboard
// to fit its content (explicit pixel height, or let it grow).
/* END USAGE */

const DC = {
  bg: '#f0eee9',
  grid: 'rgba(0,0,0,0.06)',
  label: 'rgba(60,50,40,0.7)',
  title: 'rgba(40,30,20,0.85)',
  subtitle: 'rgba(60,50,40,0.6)',
  postitBg: '#fef4a8',
  postitText: '#5a4a2a',
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif'
};

// One-time CSS injection (classes are dc-prefixed so they don't collide with
// the hosted design's own styles).
if (typeof document !== 'undefined' && !document.getElementById('dc-styles')) {
  const s = document.createElement('style');
  s.id = 'dc-styles';
  s.textContent = ['.dc-editable{cursor:text;outline:none;white-space:nowrap;border-radius:3px;padding:0 2px;margin:0 -2px}', '.dc-editable:focus{background:#fff;box-shadow:0 0 0 1.5px #c96442}', '[data-dc-slot]{transition:transform .18s cubic-bezier(.2,.7,.3,1)}', '[data-dc-slot].dc-dragging{transition:none;z-index:10;pointer-events:none}', '[data-dc-slot].dc-dragging .dc-card{box-shadow:0 12px 40px rgba(0,0,0,.25),0 0 0 2px #c96442;transform:scale(1.02)}',
  // isolation:isolate contains artboard content's z-indexes so a
  // z-indexed child (sticky navbar etc.) can't paint over .dc-header or
  // the .dc-menu popover that drops into the top of the card.
  '.dc-card{isolation:isolate;transition:box-shadow .15s,transform .15s}', '.dc-card *{scrollbar-width:none}', '.dc-card *::-webkit-scrollbar{display:none}',
  // Per-artboard header: grip + label on the left, delete/expand on the
  // right. Single flex row; when the artboard's on-screen width is too
  // narrow for both the label yields (ellipsis, then hidden entirely below
  // ~4ch via the container query) and the buttons stay on the row.
  '.dc-header{position:absolute;bottom:100%;left:-4px;margin-bottom:calc(4px * var(--dc-inv-zoom,1));z-index:2;', '  display:flex;align-items:center;container-type:inline-size}', '.dc-labelrow{display:flex;align-items:center;gap:4px;height:24px;flex:1 1 auto;min-width:0}', '.dc-grip{flex:0 0 auto;cursor:grab;display:flex;align-items:center;padding:5px 4px;border-radius:4px;transition:background .12s,opacity .12s}', '.dc-grip:hover{background:rgba(0,0,0,.08)}', '.dc-grip:active{cursor:grabbing}', '.dc-labeltext{flex:1 1 auto;min-width:0;cursor:pointer;border-radius:4px;padding:3px 6px;', '  display:flex;align-items:center;transition:background .12s;overflow:hidden}',
  // Below ~4ch of label room: hide the label entirely, and drop the grip to
  // hover-only (same reveal rule as .dc-btns) so a narrow header is clean
  // until the card is moused.
  '@container (max-width: 110px){', '  .dc-labeltext{display:none}', '  .dc-grip{opacity:0}', '  [data-dc-slot]:hover .dc-grip{opacity:1}', '}', '.dc-labeltext:hover{background:rgba(0,0,0,.05)}', '.dc-labeltext .dc-editable{overflow:hidden;text-overflow:ellipsis;max-width:100%}', '.dc-labeltext .dc-editable:focus{overflow:visible;text-overflow:clip}', '.dc-btns{flex:0 0 auto;margin-left:auto;display:flex;gap:2px;opacity:0;transition:opacity .12s}', '[data-dc-slot]:hover .dc-btns,.dc-btns:has(.dc-menu){opacity:1}', '.dc-expand,.dc-kebab{width:22px;height:22px;border-radius:5px;border:none;cursor:pointer;padding:0;', '  background:transparent;color:rgba(60,50,40,.7);display:flex;align-items:center;justify-content:center;', '  font:inherit;transition:background .12s,color .12s}', '.dc-expand:hover,.dc-kebab:hover{background:rgba(0,0,0,.06);color:#2a251f}',
  // Slot hosting an open menu floats above later siblings (which otherwise
  // paint on top — same z-index:auto, later DOM order) so the popup isn't
  // clipped by the next card.
  '[data-dc-slot]:has(.dc-menu){z-index:10}', '.dc-menu{position:absolute;top:100%;right:0;margin-top:4px;background:#fff;border-radius:8px;', '  box-shadow:0 8px 28px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.05);padding:4px;min-width:160px;z-index:10}', '.dc-menu button{display:block;width:100%;padding:7px 10px;border:0;background:transparent;', '  border-radius:5px;font-family:inherit;font-size:13px;font-weight:500;line-height:1.2;', '  color:#29261b;cursor:pointer;text-align:left;transition:background .12s;white-space:nowrap}', '.dc-menu button:hover{background:rgba(0,0,0,.05)}', '.dc-menu hr{border:0;border-top:1px solid rgba(0,0,0,.08);margin:4px 2px}', '.dc-menu .dc-danger{color:#c96442}', '.dc-menu .dc-danger:hover{background:rgba(201,100,66,.1)}',
  // Chrome (titles / labels / buttons) counter-scales against the viewport
  // zoom so it stays a constant on-screen size. --dc-inv-zoom is set by
  // DCViewport on every transform update and inherits to all descendants —
  // any overlay inside the world (e.g. a TweaksPanel on an artboard) can use
  // it the same way.
  //
  // The header uses transform:scale (out-of-flow, so layout impact doesn't
  // matter) with its world-space width set to card-width / inv-zoom so that
  // after counter-scaling its on-screen width exactly matches the card's —
  // that's what lets the container query + text-overflow behave against the
  // card's visible edge at every zoom level.
  //
  // The section head uses CSS zoom instead of transform so its layout box
  // grows with the counter-scale, pushing the card row down — otherwise the
  // constant-screen-size title would overflow into the (shrinking) world-
  // space gap and overlap the artboard headers at low zoom.
  '.dc-header{width:calc((100% + 4px) / var(--dc-inv-zoom,1));', '  transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom left}', '.dc-sectionhead{zoom:var(--dc-inv-zoom,1)}'].join('\n');
  document.head.appendChild(s);
}
const DCCtx = React.createContext(null);

// Recursively unwrap React.Fragment so <>…</> grouping doesn't hide
// DCSection/DCArtboard children from the type-based walks below.
function dcFlatten(children) {
  const out = [];
  React.Children.forEach(children, c => {
    if (c && c.type === React.Fragment) out.push(...dcFlatten(c.props.children));else out.push(c);
  });
  return out;
}

// ─────────────────────────────────────────────────────────────
// DesignCanvas — stateful wrapper around the pan/zoom viewport.
// Owns runtime state (per-section order, renamed titles/labels, hidden
// artboards, focused artboard). Order/titles/labels/hidden persist to a
// .design-canvas.state.json
// sidecar next to the HTML. Reads go via plain fetch() so the saved
// arrangement is visible anywhere the HTML + sidecar are served together
// (omelette preview, direct link, downloaded zip). Writes go through the
// host's window.omelette bridge — editing requires the omelette runtime.
// Focus is ephemeral.
// ─────────────────────────────────────────────────────────────
const DC_STATE_FILE = '.design-canvas.state.json';
function DesignCanvas({
  children,
  minScale,
  maxScale,
  style
}) {
  const [state, setState] = React.useState({
    sections: {},
    focus: null
  });
  // Hold rendering until the sidecar read settles so the saved order/titles
  // appear on first paint (no source-order flash). didRead gates writes until
  // the read settles so the empty initial state can't clobber a slow read;
  // skipNextWrite suppresses the one echo-write that would otherwise follow
  // hydration.
  const [ready, setReady] = React.useState(false);
  const didRead = React.useRef(false);
  const skipNextWrite = React.useRef(false);
  React.useEffect(() => {
    let off = false;
    fetch('./' + DC_STATE_FILE).then(r => r.ok ? r.json() : null).then(saved => {
      if (off || !saved || !saved.sections) return;
      skipNextWrite.current = true;
      setState(s => ({
        ...s,
        sections: saved.sections
      }));
    }).catch(() => {}).finally(() => {
      didRead.current = true;
      if (!off) setReady(true);
    });
    const t = setTimeout(() => {
      if (!off) setReady(true);
    }, 150);
    return () => {
      off = true;
      clearTimeout(t);
    };
  }, []);
  React.useEffect(() => {
    if (!didRead.current) return;
    if (skipNextWrite.current) {
      skipNextWrite.current = false;
      return;
    }
    const t = setTimeout(() => {
      window.omelette?.writeFile(DC_STATE_FILE, JSON.stringify({
        sections: state.sections
      })).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [state.sections]);

  // Build registries synchronously from children so FocusOverlay can read
  // them in the same render. Fragments are flattened; wrapping in other
  // elements still opts out of focus/reorder.
  const registry = {}; // slotId -> { sectionId, artboard }
  const sectionMeta = {}; // sectionId -> { title, subtitle, slotIds[] }
  const sectionOrder = [];
  dcFlatten(children).forEach(sec => {
    if (!sec || sec.type !== DCSection) return;
    const sid = sec.props.id ?? sec.props.title;
    if (!sid) return;
    sectionOrder.push(sid);
    const persisted = state.sections[sid] || {};
    const abs = [];
    dcFlatten(sec.props.children).forEach(ab => {
      if (!ab || ab.type !== DCArtboard) return;
      const aid = ab.props.id ?? ab.props.label;
      if (aid) abs.push([aid, ab]);
    });
    // hidden is scoped to one source revision — when the agent regenerates
    // (artboard-ID set changes), prior deletes don't apply to new content.
    const srcKey = abs.map(([k]) => k).join('\x1f');
    const hidden = persisted.srcKey === srcKey ? persisted.hidden || [] : [];
    const srcIds = [];
    abs.forEach(([aid, ab]) => {
      if (hidden.includes(aid)) return;
      registry[`${sid}/${aid}`] = {
        sectionId: sid,
        artboard: ab
      };
      srcIds.push(aid);
    });
    const kept = (persisted.order || []).filter(k => srcIds.includes(k));
    sectionMeta[sid] = {
      title: persisted.title ?? sec.props.title,
      subtitle: sec.props.subtitle,
      slotIds: [...kept, ...srcIds.filter(k => !kept.includes(k))]
    };
  });
  const api = React.useMemo(() => ({
    state,
    section: id => state.sections[id] || {},
    patchSection: (id, p) => setState(s => ({
      ...s,
      sections: {
        ...s.sections,
        [id]: {
          ...s.sections[id],
          ...(typeof p === 'function' ? p(s.sections[id] || {}) : p)
        }
      }
    })),
    setFocus: slotId => setState(s => ({
      ...s,
      focus: slotId
    }))
  }), [state]);

  // Esc exits focus; any outside pointerdown commits an in-progress rename.
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') api.setFocus(null);
    };
    const onPd = e => {
      const ae = document.activeElement;
      if (ae && ae.isContentEditable && !ae.contains(e.target)) ae.blur();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('pointerdown', onPd, true);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('pointerdown', onPd, true);
    };
  }, [api]);
  return /*#__PURE__*/React.createElement(DCCtx.Provider, {
    value: api
  }, /*#__PURE__*/React.createElement(DCViewport, {
    minScale: minScale,
    maxScale: maxScale,
    style: style
  }, ready && children), state.focus && registry[state.focus] && /*#__PURE__*/React.createElement(DCFocusOverlay, {
    entry: registry[state.focus],
    sectionMeta: sectionMeta,
    sectionOrder: sectionOrder
  }));
}

// ─────────────────────────────────────────────────────────────
// DCViewport — transform-based pan/zoom (internal)
//
// Input mapping (Figma-style):
//   • trackpad pinch  → zoom   (ctrlKey wheel; Safari gesture* events)
//   • trackpad scroll → pan    (two-finger)
//   • mouse wheel     → zoom   (notched; distinguished from trackpad scroll)
//   • middle-drag / primary-drag-on-bg → pan
//
// Transform state lives in a ref and is written straight to the DOM
// (translate3d + will-change) so wheel ticks don't go through React —
// keeps pans at 60fps on dense canvases.
// ─────────────────────────────────────────────────────────────
function DCViewport({
  children,
  minScale = 0.1,
  maxScale = 8,
  style = {}
}) {
  const vpRef = React.useRef(null);
  const worldRef = React.useRef(null);
  const tf = React.useRef({
    x: 0,
    y: 0,
    scale: 1
  });
  // Persist viewport across reloads so the user lands back where they were
  // after an agent edit or browser refresh. The sandbox origin is already
  // per-project; pathname keeps multiple canvas files in one project apart.
  const tfKey = 'dc-viewport:' + location.pathname;
  const saveT = React.useRef(0);
  const lastPostedScale = React.useRef();
  const apply = React.useCallback(() => {
    const {
      x,
      y,
      scale
    } = tf.current;
    const el = worldRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale})`;
    // Exposed for zoom-invariant chrome (labels, buttons, TweaksPanel).
    el.style.setProperty('--dc-inv-zoom', String(1 / scale));
    // Keep the host toolbar's % readout in sync with the canvas scale. Pan
    // ticks leave scale unchanged — skip the cross-frame post for those.
    if (lastPostedScale.current !== scale) {
      lastPostedScale.current = scale;
      window.parent.postMessage({
        type: '__dc_zoom',
        scale
      }, '*');
    }
    clearTimeout(saveT.current);
    saveT.current = setTimeout(() => {
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    }, 200);
  }, [tfKey]);
  React.useLayoutEffect(() => {
    const flush = () => {
      clearTimeout(saveT.current);
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    };
    try {
      const s = JSON.parse(localStorage.getItem(tfKey) || 'null');
      if (s && Number.isFinite(s.x) && Number.isFinite(s.y) && Number.isFinite(s.scale)) {
        tf.current = {
          x: s.x,
          y: s.y,
          scale: Math.min(maxScale, Math.max(minScale, s.scale))
        };
        apply();
      }
    } catch {}
    // Flush on pagehide and unmount so a reload within the 200ms debounce
    // window doesn't drop the last pan/zoom.
    window.addEventListener('pagehide', flush);
    return () => {
      window.removeEventListener('pagehide', flush);
      flush();
    };
  }, []);
  React.useEffect(() => {
    const vp = vpRef.current;
    if (!vp) return;
    const zoomAt = (cx, cy, factor) => {
      const r = vp.getBoundingClientRect();
      const px = cx - r.left,
        py = cy - r.top;
      const t = tf.current;
      const next = Math.min(maxScale, Math.max(minScale, t.scale * factor));
      const k = next / t.scale;
      // --dc-inv-zoom consumers (.dc-sectionhead's CSS zoom, each section's
      // marginBottom) reflow on every scale change, vertically shifting the
      // world layout — so a world point mathematically pinned under the cursor
      // drifts as you zoom (content creeps up on zoom-in, down on zoom-out).
      // Anchor the DOM element under the cursor instead: record its screen Y,
      // apply the transform + --dc-inv-zoom, then cancel whatever vertical
      // drift the reflow introduced so it stays put on screen.
      let marker = null,
        markerY0 = 0;
      if (k !== 1) {
        const hit = document.elementFromPoint(cx, cy);
        marker = hit && hit.closest ? hit.closest('[data-dc-slot],[data-dc-section]') : null;
        if (marker) markerY0 = marker.getBoundingClientRect().top;
      }
      // keep the world point under the cursor fixed
      t.x = px - (px - t.x) * k;
      t.y = py - (py - t.y) * k;
      t.scale = next;
      apply();
      if (marker) {
        // A pure zoom around (cx, cy) maps screen Y → cy + (Y - cy) * k. Any
        // departure after the --dc-inv-zoom reflow is the layout drift.
        const drift = marker.getBoundingClientRect().top - (cy + (markerY0 - cy) * k);
        if (Math.abs(drift) > 0.1) {
          t.y -= drift;
          apply();
        }
      }
    };

    // Mouse-wheel vs trackpad-scroll heuristic. A physical wheel sends
    // line-mode deltas (Firefox) or large integer pixel deltas with no X
    // component (Chrome/Safari, typically multiples of 100/120). Trackpad
    // two-finger scroll sends small/fractional pixel deltas, often with
    // non-zero deltaX. ctrlKey is set by the browser for trackpad pinch.
    const isMouseWheel = e => e.deltaMode !== 0 || e.deltaX === 0 && Number.isInteger(e.deltaY) && Math.abs(e.deltaY) >= 40;
    const onWheel = e => {
      e.preventDefault();
      if (isGesturing) return; // Safari: gesture* owns the pinch — discard concurrent wheels
      if ((e.ctrlKey || e.metaKey) && !isMouseWheel(e)) {
        // trackpad pinch, or ctrl/cmd + smooth-scroll mouse. Notched
        // wheels fall through to the fixed-step branch below.
        zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.01));
      } else if (isMouseWheel(e)) {
        // notched mouse wheel — fixed-ratio step per click
        zoomAt(e.clientX, e.clientY, Math.exp(-Math.sign(e.deltaY) * 0.18));
      } else {
        // trackpad two-finger scroll — pan
        tf.current.x -= e.deltaX;
        tf.current.y -= e.deltaY;
        apply();
      }
    };

    // Safari sends native gesture* events for trackpad pinch with a smooth
    // e.scale; preferring these over the ctrl+wheel fallback gives a much
    // better feel there. No-ops on other browsers. Safari also fires
    // ctrlKey wheel events during the same pinch — isGesturing makes
    // onWheel drop those entirely so they neither zoom nor pan.
    let gsBase = 1;
    let isGesturing = false;
    const onGestureStart = e => {
      e.preventDefault();
      isGesturing = true;
      gsBase = tf.current.scale;
    };
    const onGestureChange = e => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, gsBase * e.scale / tf.current.scale);
    };
    const onGestureEnd = e => {
      e.preventDefault();
      isGesturing = false;
    };

    // Drag-pan: middle button anywhere, or primary button on canvas
    // background (anything that isn't an artboard or an inline editor).
    let drag = null;
    const onPointerDown = e => {
      const onBg = !e.target.closest('[data-dc-slot], .dc-editable');
      if (!(e.button === 1 || e.button === 0 && onBg)) return;
      e.preventDefault();
      vp.setPointerCapture(e.pointerId);
      drag = {
        id: e.pointerId,
        lx: e.clientX,
        ly: e.clientY
      };
      vp.style.cursor = 'grabbing';
    };
    const onPointerMove = e => {
      if (!drag || e.pointerId !== drag.id) return;
      tf.current.x += e.clientX - drag.lx;
      tf.current.y += e.clientY - drag.ly;
      drag.lx = e.clientX;
      drag.ly = e.clientY;
      apply();
    };
    const onPointerUp = e => {
      if (!drag || e.pointerId !== drag.id) return;
      vp.releasePointerCapture(e.pointerId);
      drag = null;
      vp.style.cursor = '';
    };

    // Host-driven zoom (toolbar % menu). Zooms around viewport centre so the
    // visible midpoint stays fixed — matching the host's iframe-zoom feel.
    const onHostMsg = e => {
      const d = e.data;
      if (d && d.type === '__dc_set_zoom' && typeof d.scale === 'number') {
        const r = vp.getBoundingClientRect();
        zoomAt(r.left + r.width / 2, r.top + r.height / 2, d.scale / tf.current.scale);
      } else if (d && d.type === '__dc_probe') {
        // Host's [readyGen] reset asks whether a canvas is present; it
        // fires on the iframe's native 'load', which for canvases with
        // images/fonts is after our mount-time announce, so re-announce.
        // Clear the pan-tick guard so apply() re-posts the current scale
        // even if it's unchanged — the host just reset dcScale to 1.
        window.parent.postMessage({
          type: '__dc_present'
        }, '*');
        lastPostedScale.current = undefined;
        apply();
      }
    };
    window.addEventListener('message', onHostMsg);
    // Announce canvas mode so the host toolbar proxies its % control here
    // instead of scaling the iframe element (which would just shrink the
    // viewport window of an infinite canvas). The apply() that follows emits
    // the initial __dc_zoom so the toolbar % is correct before first pinch.
    // lastPostedScale reset mirrors the __dc_probe handler: the layout
    // effect's restore-path apply() may already have posted the restored
    // scale (before __dc_present), so clear the guard to re-post it in order.
    window.parent.postMessage({
      type: '__dc_present'
    }, '*');
    lastPostedScale.current = undefined;
    apply();
    vp.addEventListener('wheel', onWheel, {
      passive: false
    });
    vp.addEventListener('gesturestart', onGestureStart, {
      passive: false
    });
    vp.addEventListener('gesturechange', onGestureChange, {
      passive: false
    });
    vp.addEventListener('gestureend', onGestureEnd, {
      passive: false
    });
    vp.addEventListener('pointerdown', onPointerDown);
    vp.addEventListener('pointermove', onPointerMove);
    vp.addEventListener('pointerup', onPointerUp);
    vp.addEventListener('pointercancel', onPointerUp);
    return () => {
      window.removeEventListener('message', onHostMsg);
      vp.removeEventListener('wheel', onWheel);
      vp.removeEventListener('gesturestart', onGestureStart);
      vp.removeEventListener('gesturechange', onGestureChange);
      vp.removeEventListener('gestureend', onGestureEnd);
      vp.removeEventListener('pointerdown', onPointerDown);
      vp.removeEventListener('pointermove', onPointerMove);
      vp.removeEventListener('pointerup', onPointerUp);
      vp.removeEventListener('pointercancel', onPointerUp);
    };
  }, [apply, minScale, maxScale]);
  const gridSvg = `url("data:image/svg+xml,%3Csvg width='120' height='120' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M120 0H0v120' fill='none' stroke='${encodeURIComponent(DC.grid)}' stroke-width='1'/%3E%3C/svg%3E")`;
  return /*#__PURE__*/React.createElement("div", {
    ref: vpRef,
    className: "design-canvas",
    style: {
      height: '100vh',
      width: '100vw',
      background: DC.bg,
      overflow: 'hidden',
      overscrollBehavior: 'none',
      touchAction: 'none',
      position: 'relative',
      fontFamily: DC.font,
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: worldRef,
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      transformOrigin: '0 0',
      willChange: 'transform',
      width: 'max-content',
      minWidth: '100%',
      minHeight: '100%',
      padding: '60px 0 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: -6000,
      backgroundImage: gridSvg,
      backgroundSize: '120px 120px',
      pointerEvents: 'none',
      zIndex: -1
    }
  }), children));
}

// ─────────────────────────────────────────────────────────────
// DCSection — editable title + h-row of artboards in persisted order
// ─────────────────────────────────────────────────────────────
function DCSection({
  id,
  title,
  subtitle,
  children,
  gap = 48
}) {
  const ctx = React.useContext(DCCtx);
  const sid = id ?? title;
  const all = React.Children.toArray(dcFlatten(children));
  const artboards = all.filter(c => c && c.type === DCArtboard);
  const rest = all.filter(c => !(c && c.type === DCArtboard));
  const sec = ctx && sid && ctx.section(sid) || {};
  // Must match DesignCanvas's srcKey computation exactly (it filters falsy
  // IDs), or onDelete persists a srcKey that DesignCanvas never recognizes.
  const allIds = artboards.map(a => a.props.id ?? a.props.label).filter(Boolean);
  const srcKey = allIds.join('\x1f');
  const hidden = sec.srcKey === srcKey ? sec.hidden || [] : [];
  const srcOrder = allIds.filter(k => !hidden.includes(k));
  const order = React.useMemo(() => {
    const kept = (sec.order || []).filter(k => srcOrder.includes(k));
    return [...kept, ...srcOrder.filter(k => !kept.includes(k))];
  }, [sec.order, srcOrder.join('|')]);
  const byId = Object.fromEntries(artboards.map(a => [a.props.id ?? a.props.label, a]));

  // marginBottom counter-scales so the on-screen gap between sections stays
  // constant — otherwise at low zoom the (world-space) gap collapses while
  // the screen-constant sectionhead below it doesn't, and the title reads as
  // belonging to the section above. paddingBottom below is just enough for
  // the 24px artboard-header (abs-positioned above each card) plus ~8px, so
  // the title sits tight against its own row at every zoom.
  return /*#__PURE__*/React.createElement("div", {
    "data-dc-section": sid,
    style: {
      marginBottom: 'calc(80px * var(--dc-inv-zoom, 1))',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-sectionhead",
    style: {
      paddingBottom: 36
    }
  }, /*#__PURE__*/React.createElement(DCEditable, {
    tag: "div",
    value: sec.title ?? title,
    onChange: v => ctx && sid && ctx.patchSection(sid, {
      title: v
    }),
    style: {
      fontSize: 28,
      fontWeight: 600,
      color: DC.title,
      letterSpacing: -0.4,
      marginBottom: 6,
      display: 'inline-block'
    }
  }), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      color: DC.subtitle
    }
  }, subtitle))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap,
      padding: '0 60px',
      alignItems: 'flex-start',
      width: 'max-content'
    }
  }, order.map(k => /*#__PURE__*/React.createElement(DCArtboardFrame, {
    key: k,
    sectionId: sid,
    artboard: byId[k],
    order: order,
    label: (sec.labels || {})[k] ?? byId[k].props.label,
    onRename: v => ctx && ctx.patchSection(sid, x => ({
      labels: {
        ...x.labels,
        [k]: v
      }
    })),
    onReorder: next => ctx && ctx.patchSection(sid, {
      order: next
    }),
    onDelete: () => ctx && ctx.patchSection(sid, x => ({
      hidden: [...(x.srcKey === srcKey ? x.hidden || [] : []), k],
      srcKey
    })),
    onFocus: () => ctx && ctx.setFocus(`${sid}/${k}`)
  }))), rest);
}

// DCArtboard — marker; rendered by DCArtboardFrame via DCSection.
function DCArtboard() {
  return null;
}

// Per-artboard export (kind: 'png' | 'html'). Both paths share the same
// self-contained clone: computed styles baked in, @font-face / <img> /
// inline-style background-image urls inlined as data URIs. PNG wraps the
// clone in foreignObject→canvas at 3× the artboard's natural width×height
// (same pipeline the host uses for page captures); HTML wraps it in a
// minimal standalone document. Both are independent of viewport zoom.
async function dcExport(node, w, h, name, kind) {
  try {
    await document.fonts.ready;
  } catch {}
  const toDataURL = url => fetch(url).then(r => r.blob()).then(b => new Promise(res => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result);
    fr.onerror = () => res(url);
    fr.readAsDataURL(b);
  })).catch(() => url);

  // Collect @font-face rules. ss.cssRules throws SecurityError on
  // cross-origin sheets (e.g. fonts.googleapis.com) — in that case fetch
  // the CSS text directly (those endpoints send ACAO:*) and regex-extract
  // the blocks. @import and @media/@supports are walked so nested
  // @font-face rules aren't missed.
  const fontRules = [],
    pending = [],
    seen = new Set();
  const scrapeCss = href => {
    if (seen.has(href)) return;
    seen.add(href);
    pending.push(fetch(href).then(r => r.text()).then(css => {
      for (const m of css.match(/@font-face\s*{[^}]*}/g) || []) fontRules.push({
        css: m,
        base: href
      });
      for (const m of css.matchAll(/@import\s+(?:url\()?['"]?([^'")\s;]+)/g)) scrapeCss(new URL(m[1], href).href);
    }).catch(() => {}));
  };
  const walk = (rules, base) => {
    for (const r of rules) {
      if (r.type === CSSRule.FONT_FACE_RULE) fontRules.push({
        css: r.cssText,
        base
      });else if (r.type === CSSRule.IMPORT_RULE && r.styleSheet) {
        const ibase = r.styleSheet.href || base;
        try {
          walk(r.styleSheet.cssRules, ibase);
        } catch {
          scrapeCss(ibase);
        }
      } else if (r.cssRules) walk(r.cssRules, base);
    }
  };
  for (const ss of document.styleSheets) {
    const base = ss.href || location.href;
    try {
      walk(ss.cssRules, base);
    } catch {
      if (ss.href) scrapeCss(ss.href);
    }
  }
  while (pending.length) await pending.shift();
  const fontCss = (await Promise.all(fontRules.map(async rule => {
    let out = rule.css,
      m;
    const re = /url\((['"]?)([^'")]+)\1\)/g;
    while (m = re.exec(rule.css)) {
      if (m[2].indexOf('data:') === 0) continue;
      let abs;
      try {
        abs = new URL(m[2], rule.base).href;
      } catch {
        continue;
      }
      out = out.split(m[0]).join('url("' + (await toDataURL(abs)) + '")');
    }
    return out;
  }))).join('\n');
  const cloneStyled = src => {
    if (src.nodeType === 8 || src.nodeType === 1 && src.tagName === 'SCRIPT') return document.createTextNode('');
    const dst = src.cloneNode(false);
    if (src.nodeType === 1) {
      const cs = getComputedStyle(src);
      let txt = '';
      for (let i = 0; i < cs.length; i++) txt += cs[i] + ':' + cs.getPropertyValue(cs[i]) + ';';
      dst.setAttribute('style', txt + 'animation:none;transition:none;');
      if (src.tagName === 'CANVAS') try {
        const im = document.createElement('img');
        im.src = src.toDataURL();
        im.setAttribute('style', txt);
        return im;
      } catch {}
    }
    for (let c = src.firstChild; c; c = c.nextSibling) dst.appendChild(cloneStyled(c));
    return dst;
  };
  const clone = cloneStyled(node);
  clone.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
  // Drop the card's own shadow/radius so the export is a flush w×h rect;
  // the artboard's own background (if any) is already in the computed style.
  clone.style.boxShadow = 'none';
  clone.style.borderRadius = '0';
  const jobs = [];
  clone.querySelectorAll('img').forEach(el => {
    const s = el.getAttribute('src');
    if (s && s.indexOf('data:') !== 0) jobs.push(toDataURL(el.src).then(d => el.setAttribute('src', d)));
  });
  [clone, ...clone.querySelectorAll('*')].forEach(el => {
    const bg = el.style.backgroundImage;
    if (!bg) return;
    let m;
    const re = /url\(["']?([^"')]+)["']?\)/g;
    while (m = re.exec(bg)) {
      const tok = m[0],
        url = m[1];
      if (url.indexOf('data:') === 0) continue;
      jobs.push(toDataURL(url).then(d => {
        el.style.backgroundImage = el.style.backgroundImage.split(tok).join('url("' + d + '")');
      }));
    }
  });
  await Promise.all(jobs);
  const xml = new XMLSerializer().serializeToString(clone);
  const save = (blob, ext) => {
    if (!blob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name + '.' + ext;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  if (kind === 'html') {
    const html = '<!doctype html><html><head><meta charset="utf-8"><title>' + name + '</title>' + (fontCss ? '<style>' + fontCss + '</style>' : '') + '</head><body style="margin:0">' + xml + '</body></html>';
    return save(new Blob([html], {
      type: 'text/html'
    }), 'html');
  }

  // PNG: the SVG's own width/height must be the output resolution — an
  // <img>-loaded SVG rasterizes at its intrinsic size, so sizing it at 1×
  // and ctx.scale()-ing up would just upscale a 1× bitmap. viewBox maps the
  // w×h foreignObject onto the px·w × px·h SVG canvas so the browser renders
  // the HTML at full resolution.
  const px = 3;
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w * px + '" height="' + h * px + '" viewBox="0 0 ' + w + ' ' + h + '"><foreignObject width="' + w + '" height="' + h + '">' + (fontCss ? '<style><![CDATA[' + fontCss + ']]></style>' : '') + xml + '</foreignObject></svg>';
  const img = new Image();
  await new Promise((res, rej) => {
    img.onload = res;
    img.onerror = () => rej(new Error('svg load failed'));
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
  const cv = document.createElement('canvas');
  cv.width = w * px;
  cv.height = h * px;
  cv.getContext('2d').drawImage(img, 0, 0);
  cv.toBlob(blob => save(blob, 'png'), 'image/png');
}
function DCArtboardFrame({
  sectionId,
  artboard,
  label,
  order,
  onRename,
  onReorder,
  onFocus,
  onDelete
}) {
  const {
    id: rawId,
    label: rawLabel,
    width = 260,
    height = 480,
    children,
    style = {}
  } = artboard.props;
  const id = rawId ?? rawLabel;
  const ref = React.useRef(null);
  const cardRef = React.useRef(null);
  const menuRef = React.useRef(null);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [confirming, setConfirming] = React.useState(false);

  // ⋯ menu: close on any outside pointerdown. Two-click delete lives inside
  // the menu — first click arms the row, second commits; closing disarms.
  React.useEffect(() => {
    if (!menuOpen) {
      setConfirming(false);
      return;
    }
    const off = e => {
      if (!menuRef.current || !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('pointerdown', off, true);
    return () => document.removeEventListener('pointerdown', off, true);
  }, [menuOpen]);
  const doExport = kind => {
    setMenuOpen(false);
    if (!cardRef.current) return;
    const name = String(label || id || 'artboard').replace(/[^\w\s.-]+/g, '_');
    dcExport(cardRef.current, width, height, name, kind).catch(e => console.error('[design-canvas] export failed:', e));
  };

  // Live drag-reorder: dragged card sticks to cursor; siblings slide into
  // their would-be slots in real time via transforms. DOM order only
  // changes on drop.
  const onGripDown = e => {
    e.preventDefault();
    e.stopPropagation();
    const me = ref.current;
    // translateX is applied in local (pre-scale) space but pointer deltas and
    // getBoundingClientRect().left are screen-space — divide by the viewport's
    // current scale so the dragged card tracks the cursor at any zoom level.
    const scale = me.getBoundingClientRect().width / me.offsetWidth || 1;
    const peers = Array.from(document.querySelectorAll(`[data-dc-section="${sectionId}"] [data-dc-slot]`));
    const homes = peers.map(el => ({
      el,
      id: el.dataset.dcSlot,
      x: el.getBoundingClientRect().left
    }));
    const slotXs = homes.map(h => h.x);
    const startIdx = order.indexOf(id);
    const startX = e.clientX;
    let liveOrder = order.slice();
    me.classList.add('dc-dragging');
    const layout = () => {
      for (const h of homes) {
        if (h.id === id) continue;
        const slot = liveOrder.indexOf(h.id);
        h.el.style.transform = `translateX(${(slotXs[slot] - h.x) / scale}px)`;
      }
    };
    const move = ev => {
      const dx = ev.clientX - startX;
      me.style.transform = `translateX(${dx / scale}px)`;
      const cur = homes[startIdx].x + dx;
      let nearest = 0,
        best = Infinity;
      for (let i = 0; i < slotXs.length; i++) {
        const d = Math.abs(slotXs[i] - cur);
        if (d < best) {
          best = d;
          nearest = i;
        }
      }
      if (liveOrder.indexOf(id) !== nearest) {
        liveOrder = order.filter(k => k !== id);
        liveOrder.splice(nearest, 0, id);
        layout();
      }
    };
    const up = () => {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      const finalSlot = liveOrder.indexOf(id);
      me.classList.remove('dc-dragging');
      me.style.transform = `translateX(${(slotXs[finalSlot] - homes[startIdx].x) / scale}px)`;
      // After the settle transition, kill transitions + clear transforms +
      // commit the reorder in the same frame so there's no visual snap-back.
      setTimeout(() => {
        for (const h of homes) {
          h.el.style.transition = 'none';
          h.el.style.transform = '';
        }
        if (liveOrder.join('|') !== order.join('|')) onReorder(liveOrder);
        requestAnimationFrame(() => requestAnimationFrame(() => {
          for (const h of homes) h.el.style.transition = '';
        }));
      }, 180);
    };
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    "data-dc-slot": id,
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-header",
    "data-omelette-chrome": "",
    style: {
      color: DC.label
    },
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-labelrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-grip",
    onPointerDown: onGripDown,
    title: "Drag to reorder"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "9",
    height: "13",
    viewBox: "0 0 9 13",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "11",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "11",
    r: "1.1"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-labeltext",
    onClick: onFocus,
    title: "Click to focus"
  }, /*#__PURE__*/React.createElement(DCEditable, {
    value: label,
    onChange: onRename,
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: DC.label,
      lineHeight: 1
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-btns"
  }, /*#__PURE__*/React.createElement("div", {
    ref: menuRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "dc-kebab",
    title: "More",
    onClick: () => setMenuOpen(o => !o)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2.5",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "6",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9.5",
    cy: "6",
    r: "1.1"
  }))), menuOpen && /*#__PURE__*/React.createElement("div", {
    className: "dc-menu",
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('png')
  }, "Download PNG"), /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('html')
  }, "Download HTML"), /*#__PURE__*/React.createElement("hr", null), /*#__PURE__*/React.createElement("button", {
    className: "dc-danger",
    onClick: () => {
      if (confirming) {
        setMenuOpen(false);
        onDelete();
      } else setConfirming(true);
    }
  }, confirming ? 'Click again to delete' : 'Delete'))), /*#__PURE__*/React.createElement("button", {
    className: "dc-expand",
    onClick: onFocus,
    title: "Focus"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 1h4v4M5 11H1V7M11 1L7.5 4.5M1 11l3.5-3.5"
  }))))), /*#__PURE__*/React.createElement("div", {
    ref: cardRef,
    className: "dc-card",
    style: {
      borderRadius: 2,
      boxShadow: '0 1px 3px rgba(0,0,0,.08),0 4px 16px rgba(0,0,0,.06)',
      overflow: 'hidden',
      width,
      height,
      background: '#fff',
      ...style
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb',
      fontSize: 13,
      fontFamily: DC.font
    }
  }, id)));
}

// Inline rename — commits on blur or Enter.
function DCEditable({
  value,
  onChange,
  style,
  tag = 'span',
  onClick
}) {
  const T = tag;
  return /*#__PURE__*/React.createElement(T, {
    className: "dc-editable",
    contentEditable: true,
    suppressContentEditableWarning: true,
    onClick: onClick,
    onPointerDown: e => e.stopPropagation(),
    onBlur: e => onChange && onChange(e.currentTarget.textContent),
    onKeyDown: e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.currentTarget.blur();
      }
    },
    style: style
  }, value);
}

// ─────────────────────────────────────────────────────────────
// Focus mode — overlay one artboard; ←/→ within section, ↑/↓ across
// sections, Esc or backdrop click to exit.
// ─────────────────────────────────────────────────────────────
function DCFocusOverlay({
  entry,
  sectionMeta,
  sectionOrder
}) {
  const ctx = React.useContext(DCCtx);
  const {
    sectionId,
    artboard
  } = entry;
  const sec = ctx.section(sectionId);
  const meta = sectionMeta[sectionId];
  const peers = meta.slotIds;
  const aid = artboard.props.id ?? artboard.props.label;
  const idx = peers.indexOf(aid);
  const secIdx = sectionOrder.indexOf(sectionId);
  const go = d => {
    const n = peers[(idx + d + peers.length) % peers.length];
    if (n) ctx.setFocus(`${sectionId}/${n}`);
  };
  const goSection = d => {
    // Sections whose artboards are all deleted have slotIds:[] — step past
    // them to the next non-empty section so ↑/↓ doesn't dead-end.
    const n = sectionOrder.length;
    for (let i = 1; i < n; i++) {
      const ns = sectionOrder[((secIdx + d * i) % n + n) % n];
      const first = sectionMeta[ns] && sectionMeta[ns].slotIds[0];
      if (first) {
        ctx.setFocus(`${ns}/${first}`);
        return;
      }
    }
  };
  React.useEffect(() => {
    const k = e => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        goSection(-1);
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        goSection(1);
      }
    };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  });
  const {
    width = 260,
    height = 480,
    children
  } = artboard.props;
  const [vp, setVp] = React.useState({
    w: window.innerWidth,
    h: window.innerHeight
  });
  React.useEffect(() => {
    const r = () => setVp({
      w: window.innerWidth,
      h: window.innerHeight
    });
    window.addEventListener('resize', r);
    return () => window.removeEventListener('resize', r);
  }, []);
  const scale = Math.max(0.1, Math.min((vp.w - 200) / width, (vp.h - 260) / height, 2));
  const [ddOpen, setDd] = React.useState(false);
  const Arrow = ({
    dir,
    onClick
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onClick();
    },
    style: {
      position: 'absolute',
      top: '50%',
      [dir]: 28,
      transform: 'translateY(-50%)',
      border: 'none',
      background: 'rgba(255,255,255,.08)',
      color: 'rgba(255,255,255,.9)',
      width: 44,
      height: 44,
      borderRadius: 22,
      fontSize: 18,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background .15s'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.18)',
    onMouseLeave: e => e.currentTarget.style.background = 'rgba(255,255,255,.08)'
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 18 18",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: dir === 'left' ? 'M11 3L5 9l6 6' : 'M7 3l6 6-6 6'
  })));

  // Portal to body so position:fixed is the real viewport regardless of any
  // transform on DesignCanvas's ancestors (including the canvas zoom itself).
  return ReactDOM.createPortal(/*#__PURE__*/React.createElement("div", {
    onClick: () => ctx.setFocus(null),
    onWheel: e => e.preventDefault(),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 100,
      background: 'rgba(24,20,16,.6)',
      backdropFilter: 'blur(14px)',
      fontFamily: DC.font,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 72,
      display: 'flex',
      alignItems: 'flex-start',
      padding: '16px 20px 0',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setDd(o => !o),
    style: {
      border: 'none',
      background: 'transparent',
      color: '#fff',
      cursor: 'pointer',
      padding: '6px 8px',
      borderRadius: 6,
      textAlign: 'left',
      fontFamily: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: -0.3
    }
  }, meta.title), /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 11 11",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    style: {
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 4l3.5 3.5L9 4"
  }))), meta.subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 13,
      opacity: .6,
      fontWeight: 400,
      marginTop: 2
    }
  }, meta.subtitle)), ddOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      marginTop: 4,
      background: '#2a251f',
      borderRadius: 8,
      boxShadow: '0 8px 32px rgba(0,0,0,.4)',
      padding: 4,
      minWidth: 200,
      zIndex: 10
    }
  }, sectionOrder.filter(sid => sectionMeta[sid].slotIds.length).map(sid => /*#__PURE__*/React.createElement("button", {
    key: sid,
    onClick: () => {
      setDd(false);
      const f = sectionMeta[sid].slotIds[0];
      if (f) ctx.setFocus(`${sid}/${f}`);
    },
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'left',
      border: 'none',
      cursor: 'pointer',
      background: sid === sectionId ? 'rgba(255,255,255,.1)' : 'transparent',
      color: '#fff',
      padding: '8px 12px',
      borderRadius: 5,
      fontSize: 14,
      fontWeight: sid === sectionId ? 600 : 400,
      fontFamily: 'inherit'
    }
  }, sectionMeta[sid].title)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => ctx.setFocus(null),
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.12)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent',
    style: {
      border: 'none',
      background: 'transparent',
      color: 'rgba(255,255,255,.7)',
      width: 32,
      height: 32,
      borderRadius: 16,
      fontSize: 20,
      cursor: 'pointer',
      lineHeight: 1,
      transition: 'background .12s'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 64,
      bottom: 56,
      left: 100,
      right: 100,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: width * scale,
      height: height * scale,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      transform: `scale(${scale})`,
      transformOrigin: 'top left',
      background: '#fff',
      borderRadius: 2,
      overflow: 'hidden',
      boxShadow: '0 20px 80px rgba(0,0,0,.4)'
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb'
    }
  }, aid))), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 14,
      fontWeight: 500,
      opacity: .85,
      textAlign: 'center'
    }
  }, (sec.labels || {})[aid] ?? artboard.props.label, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .5,
      marginLeft: 10,
      fontVariantNumeric: 'tabular-nums'
    }
  }, idx + 1, " / ", peers.length))), /*#__PURE__*/React.createElement(Arrow, {
    dir: "left",
    onClick: () => go(-1)
  }), /*#__PURE__*/React.createElement(Arrow, {
    dir: "right",
    onClick: () => go(1)
  }), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      bottom: 20,
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      gap: 8
    }
  }, peers.map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: p,
    onClick: () => ctx.setFocus(`${sectionId}/${p}`),
    style: {
      border: 'none',
      padding: 0,
      cursor: 'pointer',
      width: 6,
      height: 6,
      borderRadius: 3,
      background: i === idx ? '#fff' : 'rgba(255,255,255,.3)'
    }
  })))), document.body);
}

// ─────────────────────────────────────────────────────────────
// Post-it — absolute-positioned sticky note
// ─────────────────────────────────────────────────────────────
function DCPostIt({
  children,
  top,
  left,
  right,
  bottom,
  rotate = -2,
  width = 180
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top,
      left,
      right,
      bottom,
      width,
      background: DC.postitBg,
      padding: '14px 16px',
      fontFamily: '"Comic Sans MS", "Marker Felt", "Segoe Print", cursive',
      fontSize: 14,
      lineHeight: 1.4,
      color: DC.postitText,
      boxShadow: '0 2px 8px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.08)',
      transform: `rotate(${rotate}deg)`,
      zIndex: 5
    }
  }, children);
}
Object.assign(window, {
  DesignCanvas,
  DCSection,
  DCArtboard,
  DCPostIt
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/design-canvas.jsx", error: String((e && e.message) || e) }); }

// explorations/page-hero-options.jsx
try { (() => {
/* Page hero + contact block for Schools / Consulting / Hackatons.
   Left: a short intro to what the offering is.
   Right: an "open channel" transmission card inviting people to get in touch
   about co-organising an event. Accent + copy adapt per page.
   Loads after site-effects.jsx + site-kit.jsx. */

/* Click-to-copy CTA button — copies the email and flashes a confirmation. */
function ContactCTA({
  email,
  label
}) {
  const [copied, setCopied] = React.useState(false);
  const t = React.useRef(null);
  const onCopy = () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(email);
      } else {
        throw new Error('fallback');
      }
    } catch (e) {
      try {
        const ta = document.createElement('textarea');
        ta.value = email;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      } catch (e2) {/* ignore */}
    }
    setCopied(true);
    clearTimeout(t.current);
    t.current = setTimeout(() => setCopied(false), 2000);
  };
  React.useEffect(() => () => clearTimeout(t.current), []);
  return /*#__PURE__*/React.createElement("span", {
    className: "ph-cta-wrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'ph-toast' + (copied ? ' show' : '')
  }, "Email address copied to clipboard"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "as-btn solid ph-cta",
    onClick: onCopy
  }, label, " \u2709"));
}

/* Per-page contexts — same block, accent + copy adapt. */
const PH_CTX = {
  schools: {
    active: 'schools',
    accent: '#0465ad',
    tint: '#3b9be0',
    rain: '#0465ad',
    eyebrow: 'Schools',
    title: 'Hands-on schools in\nstatistics and AI',
    lede: /*#__PURE__*/React.createElement(React.Fragment, null, "Intensive schools where working researchers and data scientists learn the ", /*#__PURE__*/React.createElement("span", {
      className: "b"
    }, "statistical methods"), " behind modern surveys."),
    cTitle: 'Bring a school to your institute',
    cBody: 'We partner with departments, observatories and research groups to run editions tuned to your science. Tell us what you have in mind.',
    cta: 'Propose an edition'
  },
  consulting: {
    active: 'consulting',
    accent: '#0465ad',
    tint: '#3b9be0',
    rain: '#0465ad',
    eyebrow: 'Consulting',
    title: 'Statistical and AI consulting\nfor corporate',
    lede: /*#__PURE__*/React.createElement(React.Fragment, null, "Embedded statistical support for ", /*#__PURE__*/React.createElement("span", {
      className: "b"
    }, "R&D projects"), " \u2014 from study design to inference."),
    cTitle: 'Have a problem that needs an expert?',
    cBody: 'Tell us about your program — survey design, model choice or a pipeline that needs a second pair of eyes — and we\'ll scope how we can help.',
    cta: 'Start a conversation'
  },
  hackatons: {
    active: 'hackatons',
    accent: '#8c0527',
    tint: '#c8607a',
    rain: '#8c0527',
    eyebrow: 'Hackatons',
    title: 'Collaborative\ndata hackatons',
    lede: /*#__PURE__*/React.createElement(React.Fragment, null, "Focused sprints where ", /*#__PURE__*/React.createElement("span", {
      className: "b"
    }, "data scientists"), " tackle a shared dataset side by side \u2014 ideal for team building."),
    cTitle: 'Want to run a hackaton with your team?',
    cBody: 'Bring a dataset and a question. We help design the sprint, recruit assistants, and facilitate the event end to end.',
    cta: 'Propose a hackaton'
  }
};

/* The hero panel itself (no page wrapper / nav) — reusable so it can be
   dropped at the top of an existing page too. */
function HeroPanel({
  ctx
}) {
  const c = ctx;
  return /*#__PURE__*/React.createElement("div", {
    className: "as-panel",
    style: {
      '--ph-accent': c.accent,
      '--ph-tint': c.tint
    }
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement("div", {
    className: "ph-con-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-tagline"
  }, c.tagline, " \xB7 ", c.eyebrow), /*#__PURE__*/React.createElement("span", {
    className: "ph-con-coord"
  }, "channel ", /*#__PURE__*/React.createElement("b", null, "open"), " \xB7 accepting proposals")), /*#__PURE__*/React.createElement("div", {
    className: "ph-split"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph-split-l"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-rain"
  }, /*#__PURE__*/React.createElement(CodeRainBG, {
    color: c.rain,
    alpha: 0.2
  })), /*#__PURE__*/React.createElement("div", {
    className: "ph-split-in"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph-con-num"
  }, "// ", c.eyebrow, " ", /*#__PURE__*/React.createElement("b", null, "\u2014 what we run")), /*#__PURE__*/React.createElement("h1", {
    className: "ph-con-title"
  }, c.title), /*#__PURE__*/React.createElement("p", {
    className: "ph-con-lede"
  }, c.lede))), /*#__PURE__*/React.createElement("div", {
    className: "ph-split-r"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph-tx"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph-tx-top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ph-tx-led"
  }, /*#__PURE__*/React.createElement("i", null), "open channel"), /*#__PURE__*/React.createElement("span", null, "enc \xB7 tls")), /*#__PURE__*/React.createElement("div", {
    className: "ph-tx-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ph-tx-title"
  }, c.cTitle), /*#__PURE__*/React.createElement("div", {
    className: "ph-tx-sub"
  }, c.cBody), /*#__PURE__*/React.createElement("div", {
    className: "ph-tx-input"
  }, "Tell us about your group and what you'd like to do", /*#__PURE__*/React.createElement("span", {
    className: "as-cur"
  })), /*#__PURE__*/React.createElement("div", {
    className: "ph-tx-foot"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ph-tx-mail"
  }, "astrostatacademy@gmail.com"), /*#__PURE__*/React.createElement(ContactCTA, {
    email: "astrostatacademy@gmail.com",
    label: c.cta
  })))))));
}

/* Page hero — left intro, right "open channel" transmission card. */
function HeroConsole({
  ctx
}) {
  const c = ctx;
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page",
    style: {
      '--ph-accent': c.accent,
      '--ph-tint': c.tint
    }
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: c.active
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement(HeroPanel, {
    ctx: c
  })));
}
Object.assign(window, {
  PH_CTX,
  HeroPanel,
  HeroConsole
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/page-hero-options.jsx", error: String((e && e.message) || e) }); }

// explorations/page-people-terminal-standalone.jsx
try { (() => {
/* People page — "personnel terminal" interaction study.
   A retro CRT television (Alien / Nostromo MU-TH-UR style) renders a person's
   dossier — visual ID + field of interest — when their name is clicked.

   Three placement options on the canvas, exploring WHERE the screen lives:
     1. DOCKED      — terminal permanently on the right; click loads the file.
     2. POWER-ON    — roster full width; click powers a CRT panel on over it.
     3. MU-TH-UR    — click takes over the whole frame as a fullscreen readout.

   Data loads LIVE from assets/people/ (same source as the other previews).
   Depends on styles.css (kit CSS layers) + site-kit.jsx (SiteNav, SiteFooter, Corners) +
   design-canvas.jsx. Self-contained data layer (tp* helpers). */

/* ── data ─────────────────────────────────────────────────────────────── */
const TP_BASE = '../assets/people';
const TP_ROLE = {
  councellors: 'Councellor',
  advisors: 'Advisory board',
  lecturers: 'Lecturer',
  TAs: 'Teaching assistant'
};
const TP_ORDER = ['councellors', 'advisors', 'lecturers', 'TAs'];

/* ── INLINED DATA (standalone build) ──────────────────────────────────────
   Mirror of assets/people/people.yml + each <role>/<slug>.md, embedded so the
   page works offline with no fetch(). Photos resolve via window.__resources
   (see the ext-resource-dependency meta tags in the HTML head). */
const TP_PHOTO_RES = {
  'councellors/paolo-bonfini': 'ph_paolo',
  'councellors/konstantinos-kovlakas': 'ph_kostas',
  'councellors/grigoris-maravelias': 'ph_grigoris',
  'councellors/andreas-tersenov': 'ph_andreas',
  'councellors/giorgos-vernardos': 'ph_giorgos',
  'advisors/nikolas-vasilas': 'ph_nikolas'
};
const TP_ROSTER = {
  councellors: ['paolo-bonfini', 'konstantinos-kovlakas', 'grigoris-maravelias', 'andreas-tersenov', 'giorgos-vernardos'],
  lecturers: [],
  TAs: [],
  advisors: ['nikolas-vasilas']
};
const TP_MD = {
  'councellors/paolo-bonfini': `---
name: Dr. Paolo Bonfini
affiliation: UniversiData srl
title: Treasurer & Website Maintainer
photo: paolo-bonfini.jpg
links:
  linkedin: www.linkedin.com/in/paolo-bonfini-phd-085a6a179
---
Data Scientist and Research Engineer specializing in Artificial Intelligence in the corporate sector, with expertise in model selection and optimization.

Prior experience in Bioinformatics and over 10 years in Astrophysics, including a PhD completed in 2013, with specialization in galaxy morphology and evolution.`,
  'councellors/konstantinos-kovlakas': `---
name: Dr. Konstantinos Kovlakas
affiliation: Institute of Space Sciences (ICE-CSIC)
title: Data Analyst
photo: konstantinos-kovlakas.jpg
---
Binary populations and Bayesian inference. Shapes the statistical curriculum across editions.`,
  'councellors/grigoris-maravelias': `---
name: Dr. Grigoris Maravelias
affiliation: PeriAstron / IA-FORTH
title: Chair
photo: grigoris-maravelias.png
---
Massive stars and classification; leads community outreach and partner relations.`,
  'councellors/andreas-tersenov': `---
name: Andreas Tersenov
affiliation: FORTH & CEA Paris-Saclay
title: AI Workflow Architect
photo: andreas-tersenov.png
---
Weak gravitational lensing and machine-learning pipelines for cosmological inference.`,
  'councellors/giorgos-vernardos': `---
name: Prof. Giorgos Vernardos
affiliation: Lehman College, CUNY
title: Secretary
photo: giorgos-vernardos.png
---
Strong gravitational lensing and Bayesian modelling of lensed quasars and galaxies.`,
  'advisors/nikolas-vasilas': `---
name: Nikolas Vasilas
affiliation: Max Planck Institute for Extraterrestrial Physics
title: Community & Alumni Manager
photo: nikolas-vasilas.jpg
---
Machine learning for large astronomical surveys and automated source classification.`
};
function tpParseRoster(text) {
  const out = [];
  let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, '');
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) {
      cur = {
        role: sec[1],
        slugs: []
      };
      out.push(cur);
      return;
    }
    const it = line.match(/^\s*-\s*(.+?)\s*$/);
    if (it && cur) cur.slugs.push(it[1]);
  });
  return out;
}
function tpParsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = {
    links: {}
  };
  let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1],
        val = kv[2].trim();
      if (key === 'links' && val === '') {
        inLinks = true;
        return;
      }
      if (inLinks && indented) {
        if (val) meta.links[key] = val;
        return;
      }
      inLinks = false;
      if (val !== '') meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}
async function tpLoad() {
  const flat = [];
  TP_ORDER.forEach(role => {
    (TP_ROSTER[role] || []).forEach((slug, i) => {
      const id = `${role}/${slug}`;
      const md = TP_MD[id];
      if (!md) {
        console.warn('[term] missing', id);
        return;
      }
      const p = tpParsePerson(md);
      const res = TP_PHOTO_RES[id];
      flat.push({
        id,
        roleKey: role,
        role: TP_ROLE[role] || role,
        name: p.name || slug,
        inst: p.affiliation || '',
        title: p.title || '',
        bio: p.bio || '',
        links: p.links || {},
        photoUrl: res && window.__resources && window.__resources[res] || '',
        order: TP_ORDER.indexOf(role) * 100 + i
      });
    });
  });
  flat.sort((a, b) => a.order - b.order);
  return flat;
}
function tpInitials(name) {
  const c = String(name).replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return (c[0][0] + (c[c.length - 1][0] || '')).toUpperCase();
}
function tpSurname(name) {
  const c = String(name).replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return c[c.length - 1].toUpperCase();
}
function tpHex(id) {
  let h = 0;
  for (const ch of id) h = h * 31 + ch.charCodeAt(0) >>> 0;
  return ('0000' + (h & 0xffff).toString(16).toUpperCase()).slice(-4);
}

/* ── styles ───────────────────────────────────────────────────────────── */
const TERM_CSS = `
  :root { --ph:#9fd4f5; --ph-dim:rgba(159,212,245,.62); --ph-faint:rgba(159,212,245,.26); --ph-glow:rgba(59,155,224,.45); --rec:#c8607a; }

  /* roster (left / underneath) */
  .tp-roster { display:flex; flex-direction:column; gap:2px; }
  .tp-rgroup { display:grid; gap:2px 18px; }
  .tp-rgrp { font-family:ui-monospace,monospace; font-size:9.5px; letter-spacing:.2em; text-transform:uppercase; color:rgba(251,246,236,.34); margin:18px 0 7px; display:flex; align-items:center; gap:10px; }
  .tp-rgrp::after { content:""; flex:1; height:1px; background:rgba(251,246,236,.13); }
  .tp-item { display:flex; align-items:center; gap:12px; width:100%; text-align:left; background:transparent; border:1px solid transparent; border-bottom:1px solid rgba(251,246,236,.09); color:inherit; padding:9px 10px; cursor:pointer; transition:background .14s, border-color .14s; }
  .tp-item:hover { background:rgba(59,155,224,.07); }
  .tp-item.on { background:rgba(59,155,224,.12); border-color:rgba(59,155,224,.4); }
  .tp-idx { font-family:ui-monospace,monospace; font-size:10px; color:rgba(251,246,236,.32); width:26px; flex:none; }
  .tp-item.on .tp-idx { color:var(--ph); }
  .tp-nm { font-weight:600; font-size:14px; line-height:1.2; }
  .tp-af { font-family:ui-monospace,monospace; font-size:10.5px; color:rgba(251,246,236,.45); margin-top:3px; }
  .tp-go { margin-left:auto; font-family:ui-monospace,monospace; font-size:10px; letter-spacing:.12em; color:rgba(251,246,236,.28); flex:none; }
  .tp-item:hover .tp-go, .tp-item.on .tp-go { color:var(--ph); }

  /* CRT screen — flush instrument-panel readout (no plastic bezel) */
  .crt { position:relative; border:1px solid rgba(251,246,236,.22); background:rgba(255,255,255,.03); height:100%; display:flex; padding:1px; }
  .crt .as-c { z-index:9; }
  .crt-screen { position:relative; flex:1; min-height:0; overflow:hidden; background:radial-gradient(130% 130% at 50% 22%, #08161f 0%, #050d14 55%, #03080d 100%); }
  .crt-inner { position:absolute; inset:0; padding:22px 24px; color:var(--ph); font-family:ui-monospace,monospace; text-shadow:0 0 6px var(--ph-glow); overflow:hidden; }
  /* scanlines + sweep + flicker overlays (vignette removed for a flatter, integrated look) */
  .crt-scan { position:absolute; inset:0; pointer-events:none; background:repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 2px, rgba(0,0,0,.16) 2px 3.5px); z-index:4; }
  .crt-sweep { position:absolute; left:0; right:0; height:60px; pointer-events:none; z-index:5; background:linear-gradient(to bottom, rgba(159,212,245,0), rgba(159,212,245,.05) 55%, rgba(159,212,245,0)); animation:crtSweep 5.5s linear infinite; }
  .crt-vig { display:none; }
  .crt-flick { position:absolute; inset:0; pointer-events:none; z-index:7; background:rgba(159,212,245,.5); opacity:0; animation:crtFlick 7s steps(1) infinite; }
  @keyframes crtSweep { from{ transform:translateY(-70px);} to{ transform:translateY(560px);} }
  @keyframes crtFlick { 0%,97%,100%{opacity:0;} 97.5%{opacity:.05;} 98.5%{opacity:.02;} }
  @keyframes crtOn { 0%{ transform:scaleY(.004); filter:brightness(3); opacity:.2;} 45%{ transform:scaleY(.02); filter:brightness(2.4);} 70%{ transform:scaleY(1); filter:brightness(1.5);} 100%{ transform:scaleY(1); filter:brightness(1);} }
  .crt.power .crt-screen { animation:crtOn .42s ease-out both; }

  /* dossier */
  .dsr { position:absolute; inset:0; display:flex; flex-direction:column; padding:20px 24px; }
  .dsr-top { display:flex; justify-content:space-between; align-items:center; font-size:10.5px; letter-spacing:.18em; color:var(--ph-dim); border-bottom:1px solid var(--ph-faint); padding-bottom:9px; }
  .dsr-rec { display:flex; align-items:center; gap:7px; color:var(--rec); text-shadow:0 0 7px rgba(200,96,122,.5); }
  .dsr-rec i { width:7px; height:7px; border-radius:50%; background:var(--rec); display:inline-block; animation:blink 1.1s steps(1) infinite; }
  @keyframes blink { 50%{opacity:.15;} }
  .dsr-body { display:grid; grid-template-columns:150px 1fr; gap:20px; margin-top:18px; flex:1; min-height:0; }

  .tphoto { position:relative; aspect-ratio:1; border:1px solid var(--ph-faint); overflow:hidden; background:#050d14; }
  .tphoto img { width:100%; height:100%; object-fit:cover; filter:grayscale(1) sepia(1) hue-rotate(165deg) saturate(2.2) brightness(1.05) contrast(.95); opacity:.92; mix-blend-mode:screen; }
  .tphoto-lost { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; }
  .tphoto-lost .tpi { font-size:46px; font-weight:700; color:var(--ph-dim); letter-spacing:.04em; }
  .tphoto-lost .tpl { font-size:8.5px; letter-spacing:.18em; color:var(--ph-faint); }
  .tphoto-hold { position:absolute; left:0; right:0; height:14px; background:linear-gradient(rgba(159,212,245,.14),rgba(159,212,245,0)); animation:hold 3.2s linear infinite; }
  @keyframes hold { from{ transform:translateY(-16px);} to{ transform:translateY(170px);} }
  .tphoto-cap { position:absolute; bottom:0; left:0; right:0; font-size:8px; letter-spacing:.16em; color:var(--ph-dim); background:rgba(5,13,20,.72); padding:4px 6px; text-align:center; }

  .dsr-id { font-size:10px; letter-spacing:.16em; color:var(--ph-faint); }
  .dsr-name { font-size:30px; font-weight:700; line-height:1; letter-spacing:.01em; margin:7px 0 0; color:#eaf6ff; text-shadow:0 0 12px var(--ph-glow); }
  .dsr-role { font-size:11.5px; letter-spacing:.12em; text-transform:uppercase; color:var(--ph-dim); margin-top:9px; }
  .dsr-aff { font-size:12px; color:var(--ph-dim); margin-top:3px; }
  .dsr-field { margin-top:18px; }
  .dsr-field .lbl { font-size:9.5px; letter-spacing:.22em; color:var(--ph-faint); display:block; margin-bottom:7px; }
  .dsr-field p { font-size:14px; line-height:1.55; color:#cfe8fa; margin:0; max-width:42ch; white-space:pre-line; }
  .dsr-field .none { color:var(--ph-faint); font-size:12.5px; }
  .dsr-linkrow { display:flex; flex-wrap:wrap; gap:8px 18px; }
  .dsr-link { font-family:ui-monospace,monospace; font-size:11px; letter-spacing:.1em; color:var(--ph); text-decoration:none; border-bottom:1px solid var(--ph-faint); padding-bottom:2px; transition:color .14s, border-color .14s; }
  .dsr-link:hover { color:#eaf6ff; border-color:var(--ph); }
  .dsr-foot { margin-top:auto; padding-top:12px; border-top:1px solid var(--ph-faint); display:flex; justify-content:space-between; align-items:center; gap:14px; font-size:10px; letter-spacing:.1em; color:var(--ph-faint); }
  .dsr-hint { color:var(--ph-dim); animation:blink 2.4s steps(1) infinite; }
  .dsr-cur::after { content:"\u2588"; color:var(--ph); animation:blink 1s steps(1) infinite; margin-left:2px; }

  /* boot */
  .boot { position:absolute; inset:0; padding:22px 24px; color:var(--ph); font-family:ui-monospace,monospace; font-size:13px; line-height:1.9; background:#050d14; z-index:3; }
  .boot .bl { opacity:0; animation:bootIn .12s ease-out forwards; }
  .boot .ok { color:var(--rec); }
  @keyframes bootIn { from{ opacity:0; clip-path:inset(0 100% 0 0);} to{ opacity:1; clip-path:inset(0 0 0 0);} }
  .dsr-wrap { position:absolute; inset:0; }
  .dsr-wrap.show { animation:fadeUp .4s ease-out .04s both; }
  @keyframes fadeUp { from{opacity:0; transform:translateY(6px);} to{opacity:1; transform:translateY(0);} }

  /* standby */
  .stby { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px; color:var(--ph-dim); font-family:ui-monospace,monospace; text-align:center; }
  .stby .big { font-size:13px; letter-spacing:.26em; }
  .stby .hint { font-size:11px; letter-spacing:.14em; color:var(--ph-faint); }
  .stby .ring { width:54px; height:54px; border:1px solid var(--ph-faint); border-top-color:var(--ph); border-radius:50%; animation:spin 1.5s linear infinite; }
  @keyframes spin { to{ transform:rotate(360deg);} }

  /* option 2 overlay panel */
  .tp-stage { position:relative; }
  .tp-panel { position:absolute; top:0; right:0; bottom:0; width:54%; z-index:20; filter:drop-shadow(-20px 0 50px rgba(0,0,0,.6)); }
  .tp-panel .crt { border-radius:12px 0 0 12px; }
  .tp-x { position:absolute; top:24px; right:26px; z-index:30; width:30px; height:30px; border:1px solid var(--ph-faint); background:rgba(2,18,12,.6); color:var(--ph); font-family:ui-monospace,monospace; cursor:pointer; border-radius:4px; }
  .tp-x:hover { background:rgba(59,155,224,.16); }

  /* option 3 fullscreen */
  .tp-full { position:absolute; inset:0; z-index:40; }
  .tp-full .crt { border-radius:0; border:0; }
  .tp-return { position:absolute; top:22px; left:24px; z-index:50; font-family:ui-monospace,monospace; font-size:11px; letter-spacing:.14em; color:var(--ph); background:rgba(2,18,12,.55); border:1px solid var(--ph-faint); padding:8px 14px; cursor:pointer; }
  .tp-return:hover { background:rgba(59,155,224,.14); }
  .dsr.big .dsr-body { grid-template-columns:220px 1fr; gap:34px; }
  .dsr.big .dsr-name { font-size:44px; }
  .dsr.big .dsr-field p { font-size:17px; max-width:48ch; }

  .tp-hint { font-family:ui-monospace,monospace; font-size:10.5px; letter-spacing:.12em; color:var(--ph-dim); border:1px solid var(--ph-faint); padding:6px 12px; display:inline-flex; align-items:center; gap:9px; }
  .tp-hint i { width:6px; height:6px; border-radius:50%; background:var(--ph); display:inline-block; box-shadow:0 0 8px var(--ph); }
`;
function TermCSS() {
  return /*#__PURE__*/React.createElement("style", null, TERM_CSS);
}

/* ── visual id ────────────────────────────────────────────────────────── */
function TPhoto({
  p
}) {
  const [bad, setBad] = React.useState(false);
  const show = p.photoUrl && !bad;
  return /*#__PURE__*/React.createElement("div", {
    className: "tphoto"
  }, show ? /*#__PURE__*/React.createElement("img", {
    src: p.photoUrl,
    alt: p.name,
    onError: () => setBad(true)
  }) : /*#__PURE__*/React.createElement("div", {
    className: "tphoto-lost"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tpi"
  }, tpInitials(p.name)), /*#__PURE__*/React.createElement("span", {
    className: "tpl"
  }, "NO VISUAL \xB7 ARCHIVE")), /*#__PURE__*/React.createElement("div", {
    className: "tphoto-hold"
  }), /*#__PURE__*/React.createElement("div", {
    className: "tphoto-cap"
  }, "VISUAL ID // ", tpHex(p.id)));
}

/* ── dossier (boot → file) ────────────────────────────────────────────── */
function Dossier({
  p,
  big,
  power,
  closable
}) {
  const [phase, setPhase] = React.useState('boot');
  React.useEffect(() => {
    setPhase('boot');
    const t = setTimeout(() => setPhase('show'), 620);
    return () => clearTimeout(t);
  }, [p.id]);
  const bootLines = [`> QUERY PERSONNEL :: ${tpSurname(p.name)}`, '> UPLINK ASTROSTAT-NET ........ OK', '> DECRYPT DOSSIER 0x' + tpHex(p.id) + ' .... OK', '> RENDER VISUAL ID'];
  return /*#__PURE__*/React.createElement("div", {
    className: 'crt' + (power ? ' power' : '')
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-br"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-screen"
  }, /*#__PURE__*/React.createElement("div", {
    className: "crt-inner"
  }, phase === 'boot' && /*#__PURE__*/React.createElement("div", {
    className: "boot"
  }, bootLines.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "bl",
    style: {
      animationDelay: `${i * 0.12}s`
    }
  }, l.replace(/OK$/, ''), /OK$/.test(l) && /*#__PURE__*/React.createElement("span", {
    className: "ok"
  }, "OK")))), /*#__PURE__*/React.createElement("div", {
    className: 'dsr-wrap' + (phase === 'show' ? ' show' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: 'dsr' + (big ? ' big' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsr-top"
  }, /*#__PURE__*/React.createElement("span", null, big ? 'MU-TH-UR 6000 // PERSONNEL FILE' : 'PERSONNEL FILE // ASTROSTAT-NET'), /*#__PURE__*/React.createElement("span", {
    className: "dsr-rec"
  }, /*#__PURE__*/React.createElement("i", null), " REC")), /*#__PURE__*/React.createElement("div", {
    className: "dsr-body"
  }, /*#__PURE__*/React.createElement(TPhoto, {
    p: p
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "dsr-id"
  }, "FILE 0x", tpHex(p.id), " \u2014 CLEARANCE 3"), /*#__PURE__*/React.createElement("h3", {
    className: "dsr-name"
  }, p.name), /*#__PURE__*/React.createElement("div", {
    className: "dsr-role"
  }, p.role, p.title ? ` · ${p.title}` : ''), /*#__PURE__*/React.createElement("div", {
    className: "dsr-aff"
  }, p.inst), /*#__PURE__*/React.createElement("div", {
    className: "dsr-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "FIELD OF INTEREST"), p.bio ? /*#__PURE__*/React.createElement("p", null, p.bio) : /*#__PURE__*/React.createElement("p", {
    className: "none"
  }, "// no record on file")), p.links && Object.keys(p.links).length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "dsr-field dsr-links"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "UPLINK"), /*#__PURE__*/React.createElement("div", {
    className: "dsr-linkrow"
  }, Object.entries(p.links).map(([k, v]) => {
    const href = /^https?:\/\//.test(v) ? v : `https://${v}`;
    return /*#__PURE__*/React.createElement("a", {
      key: k,
      className: "dsr-link",
      href: href,
      target: "_blank",
      rel: "noreferrer",
      onClick: e => e.stopPropagation()
    }, "\u25B8 ", k.toUpperCase());
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "dsr-foot"
  }, /*#__PURE__*/React.createElement("span", null, "STATUS: ACTIVE \xB7 NODE ASX-", tpHex(p.id).slice(0, 2)), closable && /*#__PURE__*/React.createElement("span", {
    className: "dsr-hint"
  }, "\u25C4 CLICK SCREEN TO CLOSE"), /*#__PURE__*/React.createElement("span", {
    className: "dsr-cur"
  }, "READY"))))), /*#__PURE__*/React.createElement("div", {
    className: "crt-sweep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-scan"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-vig"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-flick"
  })));
}
function Standby() {
  return /*#__PURE__*/React.createElement("div", {
    className: "crt"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-br"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-screen"
  }, /*#__PURE__*/React.createElement("div", {
    className: "crt-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stby"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ring"
  }), /*#__PURE__*/React.createElement("div", {
    className: "big"
  }, "ASTROSTAT-NET // STANDBY"), /*#__PURE__*/React.createElement("div", {
    className: "hint"
  }, "\u25C4 SELECT PERSONNEL TO OPEN FILE"))), /*#__PURE__*/React.createElement("div", {
    className: "crt-sweep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-scan"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-vig"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-flick"
  })));
}

/* ── shared roster ────────────────────────────────────────────────────── */
function Roster({
  people,
  selId,
  onSelect,
  cols = 1
}) {
  const groups = [];
  people.forEach((p, i) => {
    let g = groups.find(x => x.role === p.roleKey);
    if (!g) {
      g = {
        role: p.roleKey,
        label: p.role,
        items: []
      };
      groups.push(g);
    }
    g.items.push({
      ...p,
      n: i + 1
    });
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "tp-roster"
  }, groups.map(g => /*#__PURE__*/React.createElement(React.Fragment, {
    key: g.role
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-rgrp"
  }, g.label), /*#__PURE__*/React.createElement("div", {
    className: "tp-rgroup",
    style: {
      gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))`
    }
  }, g.items.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.id,
    className: 'tp-item' + (p.id === selId ? ' on' : ''),
    onClick: e => {
      e.stopPropagation();
      onSelect(p.id);
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "tp-idx"
  }, String(p.n).padStart(2, '0')), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-nm"
  }, p.name), /*#__PURE__*/React.createElement("div", {
    className: "tp-af"
  }, p.title || p.role)), /*#__PURE__*/React.createElement("span", {
    className: "tp-go"
  }, "OPEN \u25B8")))))));
}
function useRoster() {
  const [people, setPeople] = React.useState(null);
  React.useEffect(() => {
    tpLoad().then(setPeople).catch(e => {
      console.warn(e);
      setPeople([]);
    });
  }, []);
  return people;
}
function TermShell({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(TermCSS, null), /*#__PURE__*/React.createElement(SiteNav, {
    active: "people"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), children)), /*#__PURE__*/React.createElement(SiteFooter, null));
}
function TermHead({
  tag
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "as-eyebrow"
  }, "The collective"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1pg",
    style: {
      marginTop: 10
    }
  }, "Personnel", /*#__PURE__*/React.createElement("br", null), "terminal")), tag && /*#__PURE__*/React.createElement("span", {
    className: "tp-hint"
  }, /*#__PURE__*/React.createElement("i", null), tag));
}

/* ════════════════ OPTION 1 — DOCKED (always on the right) ════════════════ */
function OptDocked() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  React.useEffect(() => {
    if (people && people.length && sel == null) setSel(people[0].id);
  }, [people]);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, null, /*#__PURE__*/React.createElement(TermHead, {
    tag: "DOCKED \xB7 ALWAYS ON"
  }), /*#__PURE__*/React.createElement("p", {
    className: "as-p",
    style: {
      marginTop: 14,
      maxWidth: 520
    }
  }, "The screen lives on the right at all times. Selecting a name re-tunes it to that file."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.08fr',
      gap: 26,
      marginTop: 22,
      alignItems: 'stretch',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      maxHeight: 520,
      overflow: 'auto',
      paddingRight: 6
    }
  }, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 520
    }
  }, p ? /*#__PURE__*/React.createElement(Dossier, {
    p: p
  }) : /*#__PURE__*/React.createElement(Standby, null))));
}

/* ════════════════ OPTION 2 — POWER-ON (boots in on click) ════════════════ */
function OptPowerOn() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, null, /*#__PURE__*/React.createElement(TermHead, {
    tag: "POWER-ON \xB7 ENTERS ON CLICK"
  }), /*#__PURE__*/React.createElement("p", {
    className: "as-p",
    style: {
      marginTop: 14,
      maxWidth: 520
    }
  }, "The roster runs full width. Clicking a name powers a CRT panel on over it; dismiss to power down."), /*#__PURE__*/React.createElement("div", {
    className: "tp-stage",
    style: {
      marginTop: 22,
      minHeight: 540
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560
    }
  }, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel
  })), p && /*#__PURE__*/React.createElement("div", {
    className: "tp-panel",
    style: {
      height: 540
    }
  }, /*#__PURE__*/React.createElement(Dossier, {
    p: p,
    power: true,
    key: p.id
  }), /*#__PURE__*/React.createElement("button", {
    className: "tp-x",
    onClick: () => setSel(null),
    title: "Power off"
  }, "\u2715")), !p && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      right: 0,
      height: 540,
      width: '54%',
      display: 'grid',
      placeItems: 'center',
      border: '1px dashed rgba(59,155,224,.22)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "tp-hint"
  }, /*#__PURE__*/React.createElement("i", null), "SCREEN OFF \u2014 SELECT A NAME"))));
}

/* ════════════════ OPTION 3 — MU-TH-UR (fullscreen takeover) ═══════════════ */
function OptFullscreen() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, null, /*#__PURE__*/React.createElement(TermHead, {
    tag: "MU-TH-UR \xB7 FULLSCREEN"
  }), /*#__PURE__*/React.createElement("p", {
    className: "as-p",
    style: {
      marginTop: 14,
      maxWidth: 520
    }
  }, "Clicking a name hands the whole frame to the terminal \u2014 a full readout. Return to the roster to browse on."), /*#__PURE__*/React.createElement("div", {
    className: "tp-stage",
    style: {
      marginTop: 22,
      minHeight: 560
    }
  }, /*#__PURE__*/React.createElement("div", null, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel,
    cols: 2
  })), p && /*#__PURE__*/React.createElement("div", {
    className: "tp-full"
  }, /*#__PURE__*/React.createElement(Dossier, {
    p: p,
    big: true,
    power: true,
    key: p.id
  }), /*#__PURE__*/React.createElement("button", {
    className: "tp-return",
    onClick: () => setSel(null)
  }, "\u25C4 RETURN TO ROSTER"))));
}

/* ════════ OPTION — ALWAYS-ON CONSOLE (docked right + 2-col roster) ════════
   The terminal is permanently docked on the right in STANDBY; the roster keeps
   the full left width as two columns. Selecting a name opens that file on the
   ever-present screen. Best-of-both: the "computer" feel without the cramp. */
function OptConsole() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, null, /*#__PURE__*/React.createElement("div", {
    onClick: () => p && setSel(null)
  }, /*#__PURE__*/React.createElement(TermHead, null), /*#__PURE__*/React.createElement("p", {
    className: "as-p",
    style: {
      marginTop: 14,
      maxWidth: 560
    }
  }, "The terminal stays docked on the right in standby. The roster runs two columns; selecting a name opens that file on the ever-present screen."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '0.92fr 1.12fr',
      gap: 26,
      marginTop: 22,
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel,
    cols: 2
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 600,
      position: 'sticky',
      top: 16
    },
    onClick: e => e.stopPropagation()
  }, p ? /*#__PURE__*/React.createElement(Dossier, {
    p: p,
    key: p.id
  }) : /*#__PURE__*/React.createElement(Standby, null)))));
}
Object.assign(window, {
  OptConsole,
  OptDocked,
  OptPowerOn,
  OptFullscreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/page-people-terminal-standalone.jsx", error: String((e && e.message) || e) }); }

// explorations/page-people-terminal.jsx
try { (() => {
/* People page — "personnel terminal" interaction study.
   A retro CRT television (Alien / Nostromo MU-TH-UR style) renders a person's
   dossier — visual ID + field of interest — when their name is clicked.

   Three placement options on the canvas, exploring WHERE the screen lives:
     1. DOCKED      — terminal permanently on the right; click loads the file.
     2. POWER-ON    — roster full width; click powers a CRT panel on over it.
     3. MU-TH-UR    — click takes over the whole frame as a fullscreen readout.

   Data loads LIVE from assets/people/ (same source as the other previews).
   Depends on styles.css (kit CSS layers) + site-kit.jsx (SiteNav, SiteFooter, Corners) +
   design-canvas.jsx. Self-contained data layer (tp* helpers). */

/* ── data ─────────────────────────────────────────────────────────────── */
const TP_BASE = '../assets/people';
const TP_ROLE = {
  councellors: 'Council',
  advisors: 'Advisory board',
  lecturers: 'Lecturer',
  TAs: 'Teaching assistant'
};
const TP_ORDER = ['councellors', 'advisors', 'lecturers', 'TAs'];
function tpParseRoster(text) {
  const out = [];
  let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, '');
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) {
      cur = {
        role: sec[1],
        slugs: []
      };
      out.push(cur);
      return;
    }
    const it = line.match(/^\s*-\s*(.+?)\s*$/);
    if (it && cur) cur.slugs.push(it[1]);
  });
  return out;
}
function tpParsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = {
    links: {}
  };
  let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1],
        val = kv[2].trim();
      if (key === 'links' && val === '') {
        inLinks = true;
        return;
      }
      if (inLinks && indented) {
        if (val) meta.links[key] = val;
        return;
      }
      inLinks = false;
      if (val !== '') meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}
async function tpLoad() {
  const roster = tpParseRoster(await fetch(`${TP_BASE}/people.yml`).then(r => {
    if (!r.ok) throw new Error('people.yml');
    return r.text();
  }));
  const flat = [];
  await Promise.all(roster.map(async ({
    role,
    slugs
  }) => {
    await Promise.all(slugs.map(async (slug, i) => {
      try {
        const md = await fetch(`${TP_BASE}/${role}/${slug}.md`).then(r => {
          if (!r.ok) throw new Error(`${role}/${slug}.md`);
          return r.text();
        });
        const p = tpParsePerson(md);
        flat.push({
          id: `${role}/${slug}`,
          roleKey: role,
          role: TP_ROLE[role] || role,
          name: p.name || slug,
          inst: p.affiliation || '',
          title: p.title || '',
          bio: p.bio || '',
          links: p.links || {},
          photoUrl: `${TP_BASE}/${role}/${p.photo || slug + '.jpg'}`,
          order: TP_ORDER.indexOf(role) * 100 + i
        });
      } catch (e) {
        console.warn('[term]', e.message);
      }
    }));
  }));
  flat.sort((a, b) => a.order - b.order);
  return flat;
}
function tpInitials(name) {
  const c = String(name).replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return (c[0][0] + (c[c.length - 1][0] || '')).toUpperCase();
}
function tpSurname(name) {
  const c = String(name).replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return c[c.length - 1].toUpperCase();
}
function tpHex(id) {
  let h = 0;
  for (const ch of id) h = h * 31 + ch.charCodeAt(0) >>> 0;
  return ('0000' + (h & 0xffff).toString(16).toUpperCase()).slice(-4);
}

/* ── styles ───────────────────────────────────────────────────────────── */

function TermCSS() {
  return null;
} /* styles now in css/kit-terminal.css */

/* ── visual id ────────────────────────────────────────────────────────── */
function TPhoto({
  p
}) {
  const [bad, setBad] = React.useState(false);
  const show = p.photoUrl && !bad;
  return /*#__PURE__*/React.createElement("div", {
    className: "tphoto"
  }, show ? /*#__PURE__*/React.createElement("img", {
    src: p.photoUrl,
    alt: p.name,
    onError: () => setBad(true)
  }) : /*#__PURE__*/React.createElement("div", {
    className: "tphoto-lost"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tpi"
  }, tpInitials(p.name)), /*#__PURE__*/React.createElement("span", {
    className: "tpl"
  }, "NO VISUAL \xB7 ARCHIVE")), /*#__PURE__*/React.createElement("div", {
    className: "tphoto-hold"
  }), /*#__PURE__*/React.createElement("div", {
    className: "tphoto-cap"
  }, "VISUAL ID // ", tpHex(p.id)));
}

/* ── dossier (boot → file) ────────────────────────────────────────────── */
function Dossier({
  p,
  big,
  power,
  closable
}) {
  const [phase, setPhase] = React.useState('boot');
  React.useEffect(() => {
    setPhase('boot');
    const t = setTimeout(() => setPhase('show'), 620);
    return () => clearTimeout(t);
  }, [p.id]);
  const bootLines = [`> QUERY PERSONNEL :: ${tpSurname(p.name)}`, '> UPLINK ASTROSTAT-NET ........ OK', '> DECRYPT DOSSIER 0x' + tpHex(p.id) + ' .... OK', '> RENDER VISUAL ID'];
  return /*#__PURE__*/React.createElement("div", {
    className: 'crt' + (power ? ' power' : '')
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-br"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-screen"
  }, /*#__PURE__*/React.createElement("div", {
    className: "crt-inner"
  }, phase === 'boot' && /*#__PURE__*/React.createElement("div", {
    className: "boot"
  }, bootLines.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "bl",
    style: {
      animationDelay: `${i * 0.12}s`
    }
  }, l.replace(/OK$/, ''), /OK$/.test(l) && /*#__PURE__*/React.createElement("span", {
    className: "ok"
  }, "OK")))), /*#__PURE__*/React.createElement("div", {
    className: 'dsr-wrap' + (phase === 'show' ? ' show' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: 'dsr' + (big ? ' big' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "dsr-top"
  }, /*#__PURE__*/React.createElement("span", null, big ? 'MU-TH-UR 6000 // PERSONNEL FILE' : 'PERSONNEL FILE // ASTROSTAT-NET'), /*#__PURE__*/React.createElement("span", {
    className: "dsr-rec"
  }, /*#__PURE__*/React.createElement("i", null), " REC")), /*#__PURE__*/React.createElement("div", {
    className: "dsr-body"
  }, /*#__PURE__*/React.createElement(TPhoto, {
    p: p
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "dsr-id"
  }, "FILE 0x", tpHex(p.id), " \u2014 CLEARANCE 3"), /*#__PURE__*/React.createElement("h3", {
    className: "dsr-name"
  }, p.name), /*#__PURE__*/React.createElement("div", {
    className: "dsr-role"
  }, p.role, p.title ? ` · ${p.title}` : ''), /*#__PURE__*/React.createElement("div", {
    className: "dsr-aff"
  }, p.inst), /*#__PURE__*/React.createElement("div", {
    className: "dsr-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "FIELD OF INTEREST"), p.bio ? /*#__PURE__*/React.createElement("p", null, p.bio) : /*#__PURE__*/React.createElement("p", {
    className: "none"
  }, "// no record on file")), p.links && Object.keys(p.links).length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "dsr-field dsr-links"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "UPLINK"), /*#__PURE__*/React.createElement("div", {
    className: "dsr-linkrow"
  }, Object.entries(p.links).map(([k, v]) => {
    const href = /^https?:\/\//.test(v) ? v : `https://${v}`;
    return /*#__PURE__*/React.createElement("a", {
      key: k,
      className: "dsr-link",
      href: href,
      target: "_blank",
      rel: "noreferrer",
      onClick: e => e.stopPropagation()
    }, "\u25B8 ", k.toUpperCase());
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "dsr-foot"
  }, /*#__PURE__*/React.createElement("span", null, "STATUS: ACTIVE \xB7 NODE ASX-", tpHex(p.id).slice(0, 2)), closable && /*#__PURE__*/React.createElement("span", {
    className: "dsr-hint"
  }, "\u25C4 CLICK SCREEN TO CLOSE"), /*#__PURE__*/React.createElement("span", {
    className: "dsr-cur"
  }, "READY"))))), /*#__PURE__*/React.createElement("div", {
    className: "crt-sweep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-scan"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-vig"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-flick"
  })));
}
function Standby() {
  return /*#__PURE__*/React.createElement("div", {
    className: "crt"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-br"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-screen"
  }, /*#__PURE__*/React.createElement("div", {
    className: "crt-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stby"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ring"
  }), /*#__PURE__*/React.createElement("div", {
    className: "big"
  }, "ASTROSTAT-NET // STANDBY"), /*#__PURE__*/React.createElement("div", {
    className: "hint"
  }, "\u25C4 SELECT PERSONNEL TO OPEN FILE"))), /*#__PURE__*/React.createElement("div", {
    className: "crt-sweep"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-scan"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-vig"
  }), /*#__PURE__*/React.createElement("div", {
    className: "crt-flick"
  })));
}

/* ── shared roster ────────────────────────────────────────────────────── */
function Roster({
  people,
  selId,
  onSelect,
  cols = 1
}) {
  const groups = [];
  people.forEach((p, i) => {
    let g = groups.find(x => x.role === p.roleKey);
    if (!g) {
      g = {
        role: p.roleKey,
        label: p.role,
        items: []
      };
      groups.push(g);
    }
    g.items.push({
      ...p,
      n: i + 1
    });
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "tp-roster"
  }, groups.map(g => /*#__PURE__*/React.createElement(React.Fragment, {
    key: g.role
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-rgrp"
  }, g.label), /*#__PURE__*/React.createElement("div", {
    className: "tp-rgroup",
    style: {
      gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))`
    }
  }, g.items.map(p => /*#__PURE__*/React.createElement("button", {
    key: p.id,
    className: 'tp-item' + (p.id === selId ? ' on' : ''),
    onClick: e => {
      e.stopPropagation();
      onSelect(p.id);
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "tp-idx"
  }, String(p.n).padStart(2, '0')), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-nm"
  }, p.name), /*#__PURE__*/React.createElement("div", {
    className: "tp-af"
  }, p.title || p.role)), /*#__PURE__*/React.createElement("span", {
    className: "tp-go"
  }, "OPEN \u25B8")))))));
}
function useRoster() {
  const [people, setPeople] = React.useState(null);
  React.useEffect(() => {
    tpLoad().then(setPeople).catch(e => {
      console.warn(e);
      setPeople([]);
    });
  }, []);
  return people;
}
function TermShell({
  lede,
  children
}) {
  const PageHeader = (window.AstroStatAcademyDesignSystem_b004a7 || {}).PageHeader;
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(TermCSS, null), /*#__PURE__*/React.createElement(SiteNav, {
    active: "people"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement(PageHeader, {
    section: "People",
    kicker: "who we are",
    title: 'Personnel\nterminal',
    lede: lede || 'Select a name to open their file.',
    accent: "blue"
  }, children)), /*#__PURE__*/React.createElement(SiteFooter, null));
}

/* ════════════════ OPTION 1 — DOCKED (always on the right) ════════════════ */
function OptDocked() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  React.useEffect(() => {
    if (people && people.length && sel == null) setSel(people[0].id);
  }, [people]);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, {
    lede: "The screen lives on the right at all times. Selecting a name re-tunes it to that file."
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.08fr',
      gap: 26,
      marginTop: 22,
      alignItems: 'stretch',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      maxHeight: 520,
      overflow: 'auto',
      paddingRight: 6
    }
  }, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 520
    }
  }, p ? /*#__PURE__*/React.createElement(Dossier, {
    p: p
  }) : /*#__PURE__*/React.createElement(Standby, null))));
}

/* ════════════════ OPTION 2 — POWER-ON (boots in on click) ════════════════ */
function OptPowerOn() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, {
    lede: "The roster runs full width. Clicking a name powers a CRT panel on over it; dismiss to power down."
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-stage",
    style: {
      marginTop: 22,
      minHeight: 540
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560
    }
  }, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel
  })), p && /*#__PURE__*/React.createElement("div", {
    className: "tp-panel",
    style: {
      height: 540
    }
  }, /*#__PURE__*/React.createElement(Dossier, {
    p: p,
    power: true,
    key: p.id
  }), /*#__PURE__*/React.createElement("button", {
    className: "tp-x",
    onClick: () => setSel(null),
    title: "Power off"
  }, "\u2715")), !p && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      right: 0,
      height: 540,
      width: '54%',
      display: 'grid',
      placeItems: 'center',
      border: '1px dashed rgba(var(--blue-rgb),.22)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "tp-hint"
  }, /*#__PURE__*/React.createElement("i", null), "SCREEN OFF \u2014 SELECT A NAME"))));
}

/* ════════════════ OPTION 3 — MU-TH-UR (fullscreen takeover) ═══════════════ */
function OptFullscreen() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, {
    lede: "Clicking a name hands the whole frame to the terminal \u2014 a full readout. Return to the roster to browse on."
  }, /*#__PURE__*/React.createElement("div", {
    className: "tp-stage",
    style: {
      marginTop: 22,
      minHeight: 560
    }
  }, /*#__PURE__*/React.createElement("div", null, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel,
    cols: 2
  })), p && /*#__PURE__*/React.createElement("div", {
    className: "tp-full"
  }, /*#__PURE__*/React.createElement(Dossier, {
    p: p,
    big: true,
    power: true,
    key: p.id
  }), /*#__PURE__*/React.createElement("button", {
    className: "tp-return",
    onClick: () => setSel(null)
  }, "\u25C4 RETURN TO ROSTER"))));
}

/* ════════ OPTION — ALWAYS-ON CONSOLE (docked right + 2-col roster) ════════
   The terminal is permanently docked on the right in STANDBY; the roster keeps
   the full left width as two columns. Selecting a name opens that file on the
   ever-present screen. Best-of-both: the "computer" feel without the cramp. */
function OptConsole() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return /*#__PURE__*/React.createElement(TermShell, null, /*#__PURE__*/React.createElement("div", {
    onClick: () => p && setSel(null),
    style: {
      paddingBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '0.92fr 1.12fr',
      gap: 26,
      marginTop: 22,
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, people === null ? /*#__PURE__*/React.createElement("p", {
    className: "pp-inst"
  }, "// loading\u2026") : /*#__PURE__*/React.createElement(Roster, {
    people: people,
    selId: sel,
    onSelect: setSel,
    cols: 2
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 600,
      position: 'sticky',
      top: 16
    },
    onClick: e => e.stopPropagation()
  }, p ? /*#__PURE__*/React.createElement(Dossier, {
    p: p,
    key: p.id
  }) : /*#__PURE__*/React.createElement(Standby, null)))));
}
Object.assign(window, {
  OptConsole,
  OptDocked,
  OptPowerOn,
  OptFullscreen,
  Dossier,
  Standby,
  Roster,
  useRoster,
  TermCSS,
  TermShell,
  tpLoad,
  tpSurname
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/page-people-terminal.jsx", error: String((e && e.message) || e) }); }

// explorations/school-options.jsx
try { (() => {
/* Schools overview — exploration of presentations.
   The page is an OVERVIEW / entry point: every edition links out to its own
   webpage. Real editions + real outbound URLs (from astrostat.academy &
   the school-8 legacy list). 4 layout options on one canvas. */

/* ── Single source of truth ──────────────────────────────────────
   Every edition lives in /assets/schools/data/schools.yaml, parsed into
   window.SCHOOLS_DATA before the page renders (see School Options.html).
   The FIRST entry there is the featured / next edition. Everything the
   page needs is derived from that array, so adding a school is a
   one-file edit — no code change. */
function yearOf(date) {
  const m = String(date || '').match(/\d{4}/);
  return m ? m[0] : '';
}

/* Split "16–20 Jun 2025" → { dm:"16–20 Jun", year:"2025" } so the year
   can be rendered larger than the specific day/month in the console. */
function splitDate(date) {
  const s = String(date || '').trim();
  const m = s.match(/^(.*?)\s*(\d{4})\s*$/);
  return m ? {
    dm: m[1].trim(),
    year: m[2]
  } : {
    dm: s,
    year: ''
  };
}
function DateStamp({
  date
}) {
  const {
    dm,
    year
  } = splitDate(date);
  return /*#__PURE__*/React.createElement("span", {
    className: "sk-ds"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sk-ds-yr"
  }, year), dm ? /*#__PURE__*/React.createElement("span", {
    className: "sk-ds-dm"
  }, dm) : null);
}
function deriveSchools() {
  const data = typeof window !== 'undefined' && window.SCHOOLS_DATA || {};
  const editions = (data.editions || []).map(e => ({
    ...e,
    year: yearOf(e.date)
  }));
  if (editions[0]) editions[0].featured = true; // top entry == featured
  const LATEST = editions[0] || null;
  const PAST = editions.slice(1);
  // globe markers: group editions by city, count them; the featured city glows
  const order = [],
    byCity = {};
  editions.forEach(e => {
    if (!byCity[e.city]) {
      byCity[e.city] = {
        name: e.city,
        lat: e.lat,
        lon: e.lon,
        eds: 0,
        latest: false
      };
      order.push(e.city);
    }
    byCity[e.city].eds++;
  });
  if (LATEST) byCity[LATEST.city].latest = true;
  const SITES = order.map(c => byCity[c]);

  /* Header stats — values flagged `auto` in the YAML are computed from data:
     editions = count of editions; alumni = accepted participants in
     participants.csv, floored to the nearest 10 with a trailing "+". */
  const participants = typeof window !== 'undefined' && window.PARTICIPANTS_DATA || [];
  const alumni = participants.filter(p => String(p.accepted).toUpperCase() === 'TRUE');
  const countrySet = new Set();
  participants.forEach(p => {
    if (p.country) countrySet.add(p.country);
    if (p.country2) countrySet.add(p.country2);
  });
  const floorPlus = n => Math.floor(n / 10) * 10 + '+';
  const meta = data.meta || {};
  const stats = (meta.stats || []).map(s => {
    if (s.auto === 'editions') return {
      ...s,
      value: String(editions.length)
    };
    if (s.auto === 'alumni' && alumni.length) return {
      ...s,
      value: floorPlus(alumni.length)
    };
    if (s.auto === 'countries' && countrySet.size) return {
      ...s,
      value: floorPlus(countrySet.size)
    };
    return s;
  });
  return {
    editions,
    LATEST,
    PAST,
    SITES,
    meta: {
      ...meta,
      stats
    }
  };
}

/* ── Alumni origins ──────────────────────────────────────────────
   Home countries of accepted participants (nationality where known,
   else the institute's country), mapped to approximate centroids so
   they can be plotted on the globe. Counts drive the marker size. */
const COUNTRY_COORDS = {
  Greece: [39.0, 22.0],
  Italy: [42.8, 12.8],
  Germany: [51.0, 10.0],
  UAE: [24.0, 54.0],
  Spain: [40.2, -3.7],
  France: [46.6, 2.5],
  India: [22.0, 79.0],
  Estonia: [58.6, 25.0],
  Croatia: [45.1, 15.5],
  Chile: [-35.0, -71.0],
  Russia: [56.0, 45.0],
  UK: [54.0, -2.5],
  Jordan: [31.2, 36.5],
  Oman: [21.0, 57.0],
  Czechia: [49.8, 15.5],
  USA: [39.5, -98.0],
  SouthAfrica: [-29.0, 24.0],
  Poland: [52.0, 19.0],
  Belgium: [50.6, 4.6],
  Mexico: [23.5, -102.0],
  Syria: [35.0, 38.0],
  Pakistan: [30.0, 70.0],
  Egypt: [26.8, 30.0],
  Algeria: [28.0, 3.0],
  Serbia: [44.0, 20.9],
  Israel: [31.5, 34.9],
  Ireland: [53.2, -8.0],
  Finland: [64.0, 26.0],
  Netherlands: [52.2, 5.3],
  Portugal: [39.5, -8.0],
  Switzerland: [46.8, 8.2],
  Romania: [45.9, 25.0],
  Djibouti: [11.8, 42.6],
  SaudiArabia: [24.0, 45.0],
  'Saudi Arabia': [24.0, 45.0],
  Iraq: [33.0, 44.0],
  Tunisia: [34.0, 9.5]
};
const COUNTRY_ALIAS = {
  'United States of America': 'USA'
};
function deriveAlumniOrigins() {
  const participants = typeof window !== 'undefined' && window.PARTICIPANTS_DATA || [];
  const counts = {};
  participants.forEach(p => {
    if (String(p.accepted).toUpperCase() !== 'TRUE') return;
    let c = p.country2 || p.country;
    if (!c) return;
    c = COUNTRY_ALIAS[c] || c;
    counts[c] = (counts[c] || 0) + 1;
  });
  return Object.entries(counts).map(([name, count]) => {
    const co = COUNTRY_COORDS[name];
    return co ? {
      name,
      count,
      lat: co[0],
      lon: co[1]
    } : null;
  }).filter(Boolean);
}

/* Resolve each alumni country to its landmass polygon by testing the
   centroid against the Natural-Earth rings (point-in-polygon). The whole
   country can then be filled on the globe. Computed once and cached —
   it doesn't depend on rotation. */
function pointInRing(lon, lat, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i][0],
      yi = ring[i][1],
      xj = ring[j][0],
      yj = ring[j][1];
    if (yi > lat !== yj > lat && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
let _alumniRingsCache = null;
function alumniCountryRings() {
  if (_alumniRingsCache) return _alumniRingsCache;
  const land = typeof window !== 'undefined' && window.WORLD_LAND || [];
  const out = deriveAlumniOrigins().map(o => {
    for (const r of land) {
      if (pointInRing(o.lon, o.lat, r)) return {
        ...o,
        ring: r
      };
    }
    return null;
  }).filter(Boolean);
  if (out.length) _alumniRingsCache = out;
  return out;
}

/* ── Extended Schools page sections (Mission · Method · Curriculum · Attendants)
   Content ported from astrostat.academy, organised below the planisphere. */

function SectionHead({
  eyebrow,
  accent,
  title,
  lead
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "skx-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'as-eyebrow' + (accent ? ' ' + accent : '')
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, title), lead ? /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, lead) : null);
}
function SkillSpectrum({
  lo = 0.25,
  hi = 0.62
} = {}) {
  // direct gradient between the two brand primaries: blue (#0465ad) -> crimson (#8c0527)
  const stops = [[4, 101, 173], [140, 5, 39]];
  const lerp = (a, b, t) => Math.round(a + (b - a) * t);
  const colorAt = t => {
    const x = Math.max(0, Math.min(1, t)) * (stops.length - 1);
    const i = Math.min(stops.length - 2, Math.floor(x));
    const f = x - i,
      a = stops[i],
      b = stops[i + 1];
    return `rgb(${lerp(a[0], b[0], f)},${lerp(a[1], b[1], f)},${lerp(a[2], b[2], f)})`;
  };
  const N = 40;
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const [level, setLevel] = React.useState(reduce ? hi : lo);
  React.useEffect(() => {
    if (reduce) return;
    let raf;
    const rnd = (a, b) => a + Math.random() * (b - a);
    // rev sweeps between the lo floor and the hi peak
    let phase = 'up',
      t0 = performance.now(),
      from = lo,
      to = rnd(hi - 0.04, hi + 0.04),
      dur = rnd(300, 460);
    const advance = cur => {
      if (phase === 'up') {
        phase = 'hold';
        from = cur;
        to = cur;
        dur = rnd(160, 300);
      } else if (phase === 'hold') {
        phase = 'down';
        from = cur;
        to = rnd(lo - 0.03, lo + 0.03);
        dur = rnd(420, 640);
      } else if (phase === 'down') {
        phase = 'gap';
        from = cur;
        to = cur;
        dur = rnd(180, 460);
      } else {
        phase = 'up';
        from = cur;
        to = rnd(hi - 0.04, hi + 0.04);
        dur = rnd(260, 460);
      }
    };
    const tick = now => {
      let x = (now - t0) / dur;
      if (x >= 1) {
        t0 = now;
        advance(to);
        x = 0;
      }
      let v;
      if (phase === 'hold') v = to + Math.sin(now / 38) * 0.035; // redline jitter
      else if (phase === 'up') v = from + (to - from) * (1 - Math.pow(1 - x, 2));else if (phase === 'down') v = from + (to - from) * (x * x);else v = to; // gap idle
      setLevel(Math.max(0, Math.min(1, v)));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reduce, lo, hi]);
  return /*#__PURE__*/React.createElement("div", {
    className: "skx-skill"
  }, /*#__PURE__*/React.createElement("div", {
    className: "skx-skill-plot"
  }, Array.from({
    length: N
  }).map((_, i) => {
    const pos = i / (N - 1);
    const c = colorAt(pos);
    const lit = pos <= level + 0.001;
    const tip = lit && pos > level - 1 / N;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: "skx-sb",
      style: {
        height: 18 + 82 * (1 - (1 - pos) * (1 - pos)) + '%',
        background: c,
        opacity: lit ? 1 : 0.12,
        filter: tip ? 'brightness(1.45)' : 'none',
        boxShadow: tip ? '0 0 10px ' + c : 'none'
      }
    });
  })), /*#__PURE__*/React.createElement("div", {
    className: "skx-skill-axis"
  }, /*#__PURE__*/React.createElement("span", null, "Basic", /*#__PURE__*/React.createElement("br", null), "knowledge"), /*#__PURE__*/React.createElement("span", null, "Novice", /*#__PURE__*/React.createElement("br", null), "practitioner"), /*#__PURE__*/React.createElement("span", null, "Professional", /*#__PURE__*/React.createElement("br", null), "practitioner"), /*#__PURE__*/React.createElement("span", null, "Teacher")));
}
function MissionSection() {
  return /*#__PURE__*/React.createElement(Rail, {
    n: "03",
    label: "Fronts",
    variant: "matrix"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "How we operate",
    title: "We operate on two fronts"
  }), /*#__PURE__*/React.createElement("div", {
    className: "skx-two",
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "skx-mission"
  }, /*#__PURE__*/React.createElement("span", {
    className: "skx-kick"
  }, "01 \xB7 Support"), /*#__PURE__*/React.createElement("p", {
    className: "skx-mtext"
  }, "We help ", /*#__PURE__*/React.createElement("b", null, "early-career researchers and data scientists"), " master the analysis tools they may know only superficially \u2014 or have struggled to learn without structured guidance."), /*#__PURE__*/React.createElement(SkillSpectrum, null)), /*#__PURE__*/React.createElement("div", {
    className: "skx-mission"
  }, /*#__PURE__*/React.createElement("span", {
    className: "skx-kick"
  }, "02 \xB7 Train"), /*#__PURE__*/React.createElement("p", {
    className: "skx-mtext"
  }, "We prepare ", /*#__PURE__*/React.createElement("b", null, "additional personnel to become instructors"), ", and assist institutes in organising teaching events of their own."), /*#__PURE__*/React.createElement(SkillSpectrum, {
    lo: 0.62,
    hi: 0.98
  }))));
}
function MethodSection() {
  return /*#__PURE__*/React.createElement(Rail, {
    n: "04",
    label: "Method",
    variant: "matrix"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "The School \xB7 Method",
    title: "Theory, then your own keyboard",
    lead: /*#__PURE__*/React.createElement(React.Fragment, null, "Our lectures are a mix of theory and hands-on applications, usually via Python notebooks. This successful recipe provides the necessary variety to keep the interest alive and the students engaged.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null), "Our teaching philosophy is to go hand-in-hand with the students so that no one is left behind! We encourage both teacher\u2013student and student\u2013student interactions.")
  }), /*#__PURE__*/React.createElement("div", {
    className: "skx-method"
  }, /*#__PURE__*/React.createElement("div", {
    className: "skx-strip"
  }, /*#__PURE__*/React.createElement("div", {
    className: "skx-mrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk"
  }, "Format"), /*#__PURE__*/React.createElement("span", {
    className: "mv"
  }, "Theory", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\xB7"), "hands-on applications, interleaved")), /*#__PURE__*/React.createElement("div", {
    className: "skx-mrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk"
  }, "Notebooks"), /*#__PURE__*/React.createElement("span", {
    className: "mv"
  }, "Python", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\xB7"), "reusable code you can refactor to your own work")), /*#__PURE__*/React.createElement("div", {
    className: "skx-mrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk"
  }, "Ethos"), /*#__PURE__*/React.createElement("span", {
    className: "mv"
  }, "Hand-in-hand", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\xB7"), "no one left behind")), /*#__PURE__*/React.createElement("div", {
    className: "skx-mrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk"
  }, "Exchange"), /*#__PURE__*/React.createElement("span", {
    className: "mv"
  }, "Teacher\u2013student", /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\xB7"), "and student\u2013student interaction"))), /*#__PURE__*/React.createElement("figure", {
    className: "skx-video",
    style: {
      margin: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-br"
  }), /*#__PURE__*/React.createElement("span", {
    className: "skx-vtop"
  }, "Field recording \xB7 06"), /*#__PURE__*/React.createElement("span", {
    className: "skx-play"
  }), /*#__PURE__*/React.createElement("figcaption", {
    className: "skx-vcap"
  }, "Sharjah 2025 \u2014 the School in action"))));
}
const CURRICULUM = {
  core: ['Classical Statistics', 'Hypothesis Testing', 'Optimization', 'Bayesian Statistics', 'MCMC', 'ML / DL Introduction', 'Clustering', 'Classification', 'Regression', 'Model Selection', 'ML Best Practices'],
  seasonal: ['Time Series', 'CNNs', 'Diffusion Models', 'Simulation-Based Inference', 'GPU Parallelization', 'Gaussian Processes', 'Bayesian Optimization', 'Citizen Science'],
  future: ['LLM Pipelines', 'AI Agents', 'Knowledge Maps']
};
function CurriculumSection() {
  const Col = ({
    cls,
    label,
    count,
    cap,
    items
  }) => /*#__PURE__*/React.createElement("div", {
    className: 'skx-col ' + cls
  }, /*#__PURE__*/React.createElement("div", {
    className: "skx-ch"
  }, /*#__PURE__*/React.createElement("b", null, label), /*#__PURE__*/React.createElement("i", null, String(count).padStart(2, '0'))), /*#__PURE__*/React.createElement("div", {
    className: "skx-cc"
  }, cap), /*#__PURE__*/React.createElement("ul", {
    className: "skx-topics"
  }, items.map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    className: "skx-t"
  }, t))));
  return /*#__PURE__*/React.createElement(Rail, {
    n: "05",
    label: "Curriculum",
    variant: "matrix"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "Curriculum",
    title: "What we cover",
    lead: "Every schedule balances core foundations \u2014 the fundamentals every researcher must master \u2014 with seasonal, state-of-the-art topics, plus a horizon of subjects we're preparing for future editions."
  }), /*#__PURE__*/React.createElement("div", {
    className: "skx-syllabus"
  }, /*#__PURE__*/React.createElement(Col, {
    cls: "core",
    label: "Core",
    count: CURRICULUM.core.length,
    cap: "Always on the schedule",
    items: CURRICULUM.core
  }), /*#__PURE__*/React.createElement(Col, {
    cls: "seasonal",
    label: "Seasonal",
    count: CURRICULUM.seasonal.length,
    cap: "Rotates each edition",
    items: CURRICULUM.seasonal
  }), /*#__PURE__*/React.createElement(Col, {
    cls: "future",
    label: "Future",
    count: CURRICULUM.future.length,
    cap: "On the horizon",
    items: CURRICULUM.future
  })), /*#__PURE__*/React.createElement("p", {
    className: "skx-fine"
  }, "However complex the topic, our notebooks always ship reusable code a student can refactor to their own purposes with minimal effort."));
}
const ATTEND_STATS = [{
  v: '≈32',
  l: 'Number of participants, median'
}, {
  v: '650+',
  l: 'Applications to date'
}, {
  v: '200+',
  l: 'Students taught'
}];
function AttendantsSection() {
  return /*#__PURE__*/React.createElement(Rail, {
    n: "06",
    label: "Attendants",
    variant: "matrix"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "Who attends",
    title: "Open to all",
    lead: /*#__PURE__*/React.createElement(React.Fragment, null, "Our ideal attendee is an astrophysics PhD candidate \u2014 but we welcome everyone from BSc students to professors, and from Computer Science to Signal Processing. After all, everybody needs a hand with statistics.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null), "At every event we like to keep the number of attendants constrained in order to maximise the interactions between students and teachers.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null), "This mix benefits everyone: students see the techniques applied across domains, while teachers meet a wider range of needs that keeps them current with the latest in Machine Learning.")
  }), /*#__PURE__*/React.createElement("div", {
    className: "skx-stats"
  }, ATTEND_STATS.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.l,
    className: "skx-stat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sv"
  }, s.v), /*#__PURE__*/React.createElement("span", {
    className: "sl"
  }, s.l)))), /*#__PURE__*/React.createElement("p", {
    className: "skx-fine"
  }, "We deliberately cap each cohort near thirty \u2014 small enough to maximise student\u2013teacher interaction, broad enough to keep the room interdisciplinary and the instructors current."));
}
function SchoolsHead() {
  const {
    meta
  } = deriveSchools();
  const stats = meta.stats || [];
  return /*#__PURE__*/React.createElement("div", {
    className: "sk-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-eyebrow"
  }, meta.eyebrow || 'Schools · Editions'), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1pg",
    style: {
      marginTop: 12
    }
  }, meta.title || 'The AstroStat School'), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, meta.blurb), /*#__PURE__*/React.createElement("div", {
    className: "sk-lead"
  }, stats.map((s, i) => s.prefix ? /*#__PURE__*/React.createElement("span", {
    key: i
  }, s.label, " ", /*#__PURE__*/React.createElement("b", null, s.value)) : /*#__PURE__*/React.createElement("span", {
    key: i
  }, /*#__PURE__*/React.createElement("b", null, s.value), " ", s.label))));
}
function SchoolsShell({
  active = 'schools',
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: active
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement(Rail, {
    n: "02",
    label: "Editions",
    variant: "matrix"
  }, /*#__PURE__*/React.createElement(SchoolsHead, null), children))), /*#__PURE__*/React.createElement(SiteFooter, null));
}

/* ── Option A · Ledger ─────────────────────────────────────── */
function OptLedger() {
  const {
    editions
  } = deriveSchools();
  return /*#__PURE__*/React.createElement(SchoolsShell, null, /*#__PURE__*/React.createElement("div", {
    className: "sk-ledger"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sk-lhead"
  }, /*#__PURE__*/React.createElement("span", null, "\u2116"), /*#__PURE__*/React.createElement("span", null, "Edition"), /*#__PURE__*/React.createElement("span", null, "Venue"), /*#__PURE__*/React.createElement("span", null, "Date"), /*#__PURE__*/React.createElement("span", null)), editions.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.ed,
    className: 'sk-lrow' + (s.featured ? ' latest' : ''),
    href: s.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ed"
  }, String(s.ed).padStart(2, '0')), /*#__PURE__*/React.createElement("span", {
    className: "ti"
  }, /*#__PURE__*/React.createElement("b", null, s.city), /*#__PURE__*/React.createElement("i", null, s.country), s.featured ? /*#__PURE__*/React.createElement("span", {
    className: "sk-lb"
  }, s.upcoming ? 'Next' : 'Latest') : null), /*#__PURE__*/React.createElement("span", {
    className: "ve"
  }, s.venue), /*#__PURE__*/React.createElement("span", {
    className: "da"
  }, s.date), /*#__PURE__*/React.createElement("span", {
    className: "ar"
  }, "\u2197")))));
}

/* ── Option B · Timeline ───────────────────────────────────── */
function OptTimeline() {
  const {
    editions
  } = deriveSchools();
  return /*#__PURE__*/React.createElement(SchoolsShell, null, /*#__PURE__*/React.createElement("div", {
    className: "sk-time"
  }, editions.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.ed,
    className: 'sk-tnode' + (s.featured ? ' latest' : ''),
    href: s.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "yr"
  }, s.year), /*#__PURE__*/React.createElement("span", {
    className: "sp"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  })), /*#__PURE__*/React.createElement("span", {
    className: "card"
  }, /*#__PURE__*/React.createElement("b", null, s.city, s.featured ? /*#__PURE__*/React.createElement("i", null, s.upcoming ? 'Next' : 'Latest') : null, s.founding ? /*#__PURE__*/React.createElement("i", null, "Founding") : null), /*#__PURE__*/React.createElement("span", null, s.country, " \xB7 ", s.venue), /*#__PURE__*/React.createElement("em", null, s.date, " edition \u2197"))))));
}

/* ── Option C · Location grid ──────────────────────────────── */
function OptGrid() {
  const {
    LATEST,
    PAST
  } = deriveSchools();
  return /*#__PURE__*/React.createElement(SchoolsShell, null, /*#__PURE__*/React.createElement("div", {
    className: "sk-grid"
  }, /*#__PURE__*/React.createElement("a", {
    className: "sk-scard feat",
    href: LATEST.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "left"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ed"
  }, "Edition ", String(LATEST.ed).padStart(2, '0'), " \xB7 ", LATEST.upcoming ? 'Next' : 'Latest'), /*#__PURE__*/React.createElement("span", {
    className: "cy"
  }, LATEST.city), /*#__PURE__*/React.createElement("span", {
    className: "co"
  }, LATEST.country, " \xB7 ", LATEST.venue)), /*#__PURE__*/React.createElement("span", {
    className: "foot2",
    style: {
      marginTop: 0,
      paddingTop: 0,
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "da2"
  }, LATEST.date), /*#__PURE__*/React.createElement("span", {
    className: "ar2"
  }, "View edition \u2197"))), PAST.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.ed,
    className: "sk-scard",
    href: s.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ed"
  }, "Ed. ", String(s.ed).padStart(2, '0')), /*#__PURE__*/React.createElement("span", {
    className: "cy"
  }, s.city), /*#__PURE__*/React.createElement("span", {
    className: "co"
  }, s.country), /*#__PURE__*/React.createElement("span", {
    className: "foot2"
  }, /*#__PURE__*/React.createElement("span", {
    className: "da2"
  }, s.date), /*#__PURE__*/React.createElement("span", {
    className: "ar2"
  }, "\u2197"))))));
}

/* ── Option D · Featured + archive ─────────────────────────── */
function FeaturedHero() {
  const {
    LATEST
  } = deriveSchools();
  const topics = LATEST.topics || [];
  return /*#__PURE__*/React.createElement("a", {
    className: "sk-hero",
    href: LATEST.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tag"
  }, LATEST.upcoming ? 'Next edition' : 'Latest edition · № ' + String(LATEST.ed).padStart(2, '0')), /*#__PURE__*/React.createElement("div", {
    className: "cy"
  }, LATEST.city, " ", LATEST.year), /*#__PURE__*/React.createElement("div", {
    className: "meta"
  }, LATEST.venue, " \xB7 ", LATEST.country, " \xB7 ", LATEST.date), topics.length ? /*#__PURE__*/React.createElement("div", {
    className: "chips2"
  }, topics.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip"
  }, t))) : null, /*#__PURE__*/React.createElement("div", {
    className: "go"
  }, LATEST.upcoming ? 'Visit the edition ↗' : 'View the edition ↗'));
}
function OptFeatured() {
  const {
    PAST
  } = deriveSchools();
  return /*#__PURE__*/React.createElement(SchoolsShell, null, /*#__PURE__*/React.createElement(FeaturedHero, null), /*#__PURE__*/React.createElement("div", {
    className: "sk-arch"
  }, /*#__PURE__*/React.createElement("h4", null, "Past editions"), /*#__PURE__*/React.createElement("div", {
    className: "sk-arows"
  }, PAST.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.ed,
    className: "sk-arow",
    href: s.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ds-col"
  }, /*#__PURE__*/React.createElement(DateStamp, {
    date: s.date
  })), /*#__PURE__*/React.createElement("span", {
    className: "ac"
  }, s.city), /*#__PURE__*/React.createElement("span", {
    className: "ax"
  }, "\u2197"))))));
}

/* ── Palantir-style wireframe GLOBE — orthographic sphere ────
   A 3D globe of pure graticule: front hemisphere glows, the back
   hemisphere shows through faintly (holographic), slow auto-spin. */
function Globe({
  W = 980,
  H = 560,
  speed = 5,
  showSites = true,
  showLand = true,
  showAlumni = false
}) {
  const R = Math.min(W * 0.26, H * 0.46);
  const cx = W * 0.33,
    cy = H / 2;
  const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const [rot, setRot] = React.useState(-25);
  React.useEffect(() => {
    if (reduce || !speed) return;
    let raf,
      last = performance.now();
    const tick = t => {
      const dt = Math.min(0.05, (t - last) / 1000);
      last = t;
      setRot(r => (r + dt * speed) % 360);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reduce, speed]);
  const lat0 = 22 * Math.PI / 180,
    lon0 = rot * Math.PI / 180;
  const sL0 = Math.sin(lat0),
    cL0 = Math.cos(lat0);
  const pt = (lonD, latD) => {
    const lon = lonD * Math.PI / 180 - lon0,
      lat = latD * Math.PI / 180;
    const cp = Math.cos(lat),
      sp = Math.sin(lat),
      cl = Math.cos(lon),
      sl = Math.sin(lon);
    const cosc = sL0 * sp + cL0 * cp * cl;
    return {
      x: cx + R * cp * sl,
      y: cy - R * (cL0 * sp - sL0 * cp * cl),
      front: cosc >= 0
    };
  };
  const segs = pts => {
    const out = [];
    let cur = null,
      cf = null;
    for (const p of pts) {
      if (cur && p.front !== cf) {
        out.push({
          front: cf,
          pts: cur
        });
        cur = null;
      }
      if (!cur) {
        cur = [];
        cf = p.front;
      }
      cur.push(p);
    }
    if (cur) out.push({
      front: cf,
      pts: cur
    });
    return out;
  };
  const dstr = pts => pts.map((p, i) => (i ? 'L' : 'M') + p.x.toFixed(1) + ' ' + p.y.toFixed(1)).join(' ');
  const lines = [];
  for (let lon = -180; lon < 180; lon += 15) {
    const p = [];
    for (let la = -90; la <= 90; la += 2) p.push(pt(lon, la));
    lines.push({
      major: lon === 0,
      segs: segs(p)
    });
  }
  for (let la = -75; la <= 75; la += 15) {
    const p = [];
    for (let lo = -180; lo <= 180; lo += 2) p.push(pt(lo, la));
    lines.push({
      major: la === 0,
      segs: segs(p)
    });
  }
  const back = [],
    front = [];
  lines.forEach((L, i) => L.segs.forEach((s, j) => {
    (s.front ? front : back).push(/*#__PURE__*/React.createElement("path", {
      key: i + '-' + j,
      d: dstr(s.pts),
      fill: "none",
      stroke: L.major && s.front ? '#7cc4f5' : '#3b9be0',
      strokeWidth: L.major ? 1.5 : 1.1,
      strokeOpacity: s.front ? L.major ? 0.85 : 0.4 : 0.11
    }));
  }));

  // country / coastline outlines projected onto the sphere
  const land = typeof window !== 'undefined' && window.WORLD_LAND || [];
  const lback = [],
    lfront = [];
  land.forEach((ring, i) => {
    segs(ring.map(c => pt(c[0], c[1]))).forEach((s, j) => {
      if (s.pts.length < 2) return;
      (s.front ? lfront : lback).push(/*#__PURE__*/React.createElement("path", {
        key: i + '-' + j,
        d: dstr(s.pts),
        fill: "none",
        stroke: s.front ? '#d6ecff' : '#5aa6dc',
        strokeWidth: s.front ? 1 : 0.8,
        strokeOpacity: s.front ? 0.62 : 0.07,
        strokeLinejoin: "round",
        strokeLinecap: "round"
      }));
    });
  });

  // host-city markers — derived from the YAML (cities grouped + counted),
  // project, keep the visible hemisphere, then declutter labels vertically
  // (the Mediterranean editions cluster tightly) with leader lines.
  const SCHOOL_SITES = deriveSchools().SITES;
  const sites = SCHOOL_SITES.map(s => {
    const p = pt(s.lon, s.lat);
    return {
      ...s,
      x: p.x,
      y: p.y,
      front: p.front
    };
  }).filter(s => s.front);
  // alumni origins — fill the whole home country of accepted participants;
  // fill opacity scales with headcount. Centroid must face the viewer.
  const alumniFills = showAlumni ? alumniCountryRings().map(o => ({
    ...o,
    proj: o.ring.map(c => pt(c[0], c[1])),
    front: pt(o.lon, o.lat).front
  })).filter(o => o.front).sort((a, b) => a.count - b.count) : [];
  const LH = 17;
  ['L', 'R'].forEach(side => {
    const grp = sites.filter(s => side === 'R' === s.x >= cx).sort((a, b) => a.y - b.y);
    grp.forEach((s, i) => {
      s.side = side;
      s.ly = i === 0 ? s.y + 3.6 : Math.max(s.y + 3.6, grp[i - 1].ly + LH);
    });
  });
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`,
    role: "img",
    "aria-label": "Rotating celestial coordinate globe"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("radialGradient", {
    id: "gl-atm",
    cx: "50%",
    cy: "50%",
    r: "50%"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "60%",
    stopColor: "rgba(59,155,224,0)"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "93%",
    stopColor: "rgba(59,155,224,.20)"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "rgba(59,155,224,0)"
  })), /*#__PURE__*/React.createElement("radialGradient", {
    id: "gl-core",
    cx: "50%",
    cy: "44%",
    r: "58%"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: "rgba(4,101,173,.16)"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: "rgba(0,0,0,0)"
  })), /*#__PURE__*/React.createElement("filter", {
    id: "gl-glow",
    x: "-30%",
    y: "-30%",
    width: "160%",
    height: "160%"
  }, /*#__PURE__*/React.createElement("feGaussianBlur", {
    stdDeviation: "3.2"
  }))), /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: R * 1.07,
    fill: "url(#gl-atm)"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: R,
    fill: "url(#gl-core)"
  }), /*#__PURE__*/React.createElement("g", null, back), showLand && /*#__PURE__*/React.createElement("g", null, lback), showAlumni && /*#__PURE__*/React.createElement("g", null, alumniFills.map(o => {
    const fp = o.proj.filter(p => p.front);
    if (fp.length < 3) return null;
    const op = (0.18 + Math.min(0.42, o.count / 50 * 0.42)).toFixed(3);
    return /*#__PURE__*/React.createElement("path", {
      key: o.name,
      d: dstr(fp) + 'Z',
      fill: 'rgba(0,140,140,' + op + ')',
      stroke: "rgba(0,140,140,.9)",
      strokeWidth: "1",
      strokeLinejoin: "round",
      strokeLinecap: "round"
    });
  })), /*#__PURE__*/React.createElement("g", {
    filter: "url(#gl-glow)",
    opacity: "0.5"
  }, front), /*#__PURE__*/React.createElement("g", null, front), showLand && /*#__PURE__*/React.createElement("g", {
    filter: "url(#gl-glow)",
    opacity: "0.45"
  }, lfront), showLand && /*#__PURE__*/React.createElement("g", null, lfront), /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: R,
    fill: "none",
    stroke: "#8fcdf7",
    strokeWidth: "2",
    strokeOpacity: "0.85",
    filter: "url(#gl-glow)"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: R,
    fill: "none",
    stroke: "#8fcdf7",
    strokeWidth: "1.3",
    strokeOpacity: "0.95"
  }), showSites && /*#__PURE__*/React.createElement("g", null, sites.map(s => {
    const right = s.side === 'R';
    const lx = right ? s.x + 13 : s.x - 13;
    const big = s.eds >= 5;
    return /*#__PURE__*/React.createElement("g", {
      key: s.name
    }, s.latest && /*#__PURE__*/React.createElement("circle", {
      className: "sk-ping",
      cx: s.x,
      cy: s.y,
      r: "4",
      fill: "none",
      stroke: "#e8506f",
      strokeWidth: "1.4"
    }), /*#__PURE__*/React.createElement("path", {
      d: `M${s.x.toFixed(1)} ${s.y.toFixed(1)} L${(right ? lx - 3 : lx + 3).toFixed(1)} ${(s.ly - 3.4).toFixed(1)}`,
      stroke: "rgba(251,246,236,.32)",
      strokeWidth: "0.8",
      fill: "none"
    }), big && /*#__PURE__*/React.createElement("circle", {
      cx: s.x,
      cy: s.y,
      r: "7.5",
      fill: "none",
      stroke: "#fbf6ec",
      strokeWidth: "1",
      strokeOpacity: "0.45"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: s.x,
      cy: s.y,
      r: s.latest ? 4.2 : big ? 4 : 3,
      fill: s.latest ? '#ff5d79' : '#fbf6ec',
      stroke: "#000",
      strokeWidth: "1"
    }), /*#__PURE__*/React.createElement("text", {
      className: 'sk-site-lbl' + (s.latest ? ' latest' : ''),
      x: lx,
      y: s.ly,
      textAnchor: right ? 'start' : 'end'
    }, s.name, s.eds > 1 ? '  ×' + s.eds : ''));
  })));
}
const SKY_RATES = [{
  k: 'Off',
  v: 0,
  icon: 'pause'
}, {
  k: 'Slow',
  v: 5,
  icon: 'play'
}, {
  k: 'Fast',
  v: 20,
  icon: 'ffwd'
}];
function SpinIcon({
  type
}) {
  return /*#__PURE__*/React.createElement("svg", {
    className: "sk-spin-ic",
    viewBox: "0 0 14 12",
    fill: "currentColor",
    "aria-hidden": "true"
  }, type === 'pause' && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
    x: "3.4",
    y: "2",
    width: "2.4",
    height: "8"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "8.2",
    y: "2",
    width: "2.4",
    height: "8"
  })), type === 'play' && /*#__PURE__*/React.createElement("path", {
    d: "M4 2 L11 6 L4 10 Z"
  }), type === 'ffwd' && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
    d: "M1 2.5 L6 6 L1 9.5 Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M7.5 2.5 L12.5 6 L7.5 9.5 Z"
  })));
}
function SkyPanel() {
  const [rate, setRate] = React.useState(() => {
    try {
      const s = localStorage.getItem('sk-rate');
      if (s !== null) return Number(s);
    } catch (e) {/* ignore */}
    return 5;
  });
  const [sites, setSites] = React.useState(() => {
    try {
      const s = localStorage.getItem('sk-sites');
      if (s !== null) return s === '1';
    } catch (e) {/* ignore */}
    return true;
  });
  const [land, setLand] = React.useState(() => {
    try {
      const s = localStorage.getItem('sk-land');
      if (s !== null) return s === '1';
    } catch (e) {/* ignore */}
    return true;
  });
  const [alumni, setAlumni] = React.useState(() => {
    try {
      const s = localStorage.getItem('sk-alumni');
      if (s !== null) return s === '1';
    } catch (e) {/* ignore */}
    return false;
  });
  const chooseRate = v => {
    setRate(v);
    try {
      localStorage.setItem('sk-rate', String(v));
    } catch (e) {/* ignore */}
  };
  const chooseSites = on => {
    setSites(on);
    try {
      localStorage.setItem('sk-sites', on ? '1' : '0');
    } catch (e) {/* ignore */}
  };
  const chooseLand = on => {
    setLand(on);
    try {
      localStorage.setItem('sk-land', on ? '1' : '0');
    } catch (e) {/* ignore */}
  };
  const chooseAlumni = on => {
    setAlumni(on);
    try {
      localStorage.setItem('sk-alumni', on ? '1' : '0');
    } catch (e) {/* ignore */}
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "sk-sky"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sk-cnr tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "sk-cnr tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "sk-cnr bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "sk-cnr br"
  }), /*#__PURE__*/React.createElement("div", {
    className: "sk-sky-top"
  }, /*#__PURE__*/React.createElement("span", null, "Host Cities \xB7 Legacy"), /*#__PURE__*/React.createElement("span", {
    className: "dim"
  }, "Orthographic \xB7 3D")), /*#__PURE__*/React.createElement("div", {
    className: "sk-sky-fig"
  }, /*#__PURE__*/React.createElement(Globe, {
    speed: rate,
    showSites: sites,
    showLand: land,
    showAlumni: alumni
  }), /*#__PURE__*/React.createElement("div", {
    className: "sk-ctrl"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sk-ctrl-h"
  }, "Controls"), /*#__PURE__*/React.createElement("div", {
    className: "sk-ctrl-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Spin Velocity"), /*#__PURE__*/React.createElement("span", {
    className: "sk-rate-seg",
    role: "group",
    "aria-label": "Rotation speed"
  }, SKY_RATES.map(r => /*#__PURE__*/React.createElement("button", {
    key: r.k,
    type: "button",
    className: 'sk-rate-b sk-rate-sym' + (r.v === rate ? ' on' : ''),
    "aria-pressed": r.v === rate,
    "aria-label": r.k,
    title: r.k,
    onClick: () => chooseRate(r.v)
  }, /*#__PURE__*/React.createElement(SpinIcon, {
    type: r.icon
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "sk-ctrl-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Locations"), /*#__PURE__*/React.createElement("span", {
    className: "sk-rate-seg",
    role: "group",
    "aria-label": "Show locations"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'sk-rate-b' + (sites ? ' on' : ''),
    "aria-pressed": sites,
    onClick: () => chooseSites(true)
  }, "On"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'sk-rate-b' + (!sites ? ' on' : ''),
    "aria-pressed": !sites,
    onClick: () => chooseSites(false)
  }, "Off"))), /*#__PURE__*/React.createElement("div", {
    className: "sk-ctrl-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Country Outlines"), /*#__PURE__*/React.createElement("span", {
    className: "sk-rate-seg",
    role: "group",
    "aria-label": "Show country outlines"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'sk-rate-b' + (land ? ' on' : ''),
    "aria-pressed": land,
    onClick: () => chooseLand(true)
  }, "On"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'sk-rate-b' + (!land ? ' on' : ''),
    "aria-pressed": !land,
    onClick: () => chooseLand(false)
  }, "Off"))), /*#__PURE__*/React.createElement("div", {
    className: "sk-ctrl-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Past Alumni Origins"), /*#__PURE__*/React.createElement("span", {
    className: "sk-rate-seg",
    role: "group",
    "aria-label": "Show alumni origins"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'sk-rate-b' + (alumni ? ' on' : ''),
    "aria-pressed": alumni,
    onClick: () => chooseAlumni(true)
  }, "On"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'sk-rate-b' + (!alumni ? ' on' : ''),
    "aria-pressed": !alumni,
    onClick: () => chooseAlumni(false)
  }, "Off"))))), /*#__PURE__*/React.createElement("div", {
    className: "sk-sky-bot"
  }, /*#__PURE__*/React.createElement("span", null, alumni ? 'Alumni Origins · Editions' : 'Coastlines · Editions'), /*#__PURE__*/React.createElement("span", null, "Equatorial sphere")));
}

/* ── Option D+ · Full Schools page · featured + planisphere, then the
   rest of the astrostat.academy story below it ────────────────────── */
function OptFeaturedSky() {
  const {
    PAST
  } = deriveSchools();
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: "schools"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(HeroPanel, {
    ctx: PH_CTX.schools
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement(Rail, {
    n: "02",
    label: "Editions",
    variant: "matrix"
  }, /*#__PURE__*/React.createElement(SchoolsHead, null), /*#__PURE__*/React.createElement(FeaturedHero, null), /*#__PURE__*/React.createElement("div", {
    className: "sk-d2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sk-d2-left"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sk-arch",
    style: {
      marginTop: 0
    }
  }, /*#__PURE__*/React.createElement("h4", null, "Past editions"), /*#__PURE__*/React.createElement("div", {
    className: "sk-arows one"
  }, PAST.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.ed,
    className: "sk-arow",
    href: s.url,
    target: "_blank",
    rel: "noopener noreferrer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ds-col"
  }, /*#__PURE__*/React.createElement(DateStamp, {
    date: s.date
  })), /*#__PURE__*/React.createElement("span", {
    className: "ac"
  }, s.city), /*#__PURE__*/React.createElement("span", {
    className: "ax"
  }, "\u2197")))))), /*#__PURE__*/React.createElement("div", {
    className: "sk-d2-right"
  }, /*#__PURE__*/React.createElement(SkyPanel, null)))), /*#__PURE__*/React.createElement(MissionSection, null), /*#__PURE__*/React.createElement(MethodSection, null), /*#__PURE__*/React.createElement(CurriculumSection, null), /*#__PURE__*/React.createElement(AttendantsSection, null))), /*#__PURE__*/React.createElement(SiteFooter, null));
}
Object.assign(window, {
  deriveSchools,
  deriveAlumniOrigins,
  splitDate,
  DateStamp,
  SectionHead,
  MissionSection,
  MethodSection,
  CurriculumSection,
  AttendantsSection,
  OptLedger,
  OptTimeline,
  OptGrid,
  OptFeatured,
  OptFeaturedSky,
  Globe,
  SkyPanel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/school-options.jsx", error: String((e && e.message) || e) }); }

// explorations/site-effects.jsx
try { (() => {
/* Shared effects for the full-site directions.
   CodeRainBG  — configurable falling Greek/maths glyph rain.
   HeroWidget  — the dual-mode hero: ∩ Gaussian histogram (drag mean / σ)
                 ⟷ 〜 AR(1) time series. Toggle restored (∩ / 〜). */

const EXP_RAIN = 'αβγδεζηθικλμνξπρστφχψωΛΦΨΩΣ∑∏∫∮∂∇∆√∝∞≈≠≡≤≥±×÷∈∉⊂∪∩∅∴⊕⊗⊙ℓℏℝℕ☉★0123456789';
function hexToRgb(hex) {
  const m = hex.replace('#', '');
  return [0, 2, 4].map(i => parseInt(m.slice(i, i + 2), 16)).join(', ');
}
function CodeRainBG({
  color = '#8c0527',
  alpha = 0.5,
  font = 16,
  frame = 110
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const canvas = ref.current,
      ctx = canvas.getContext('2d');
    const rgb = hexToRgb(color);
    let cols = 0,
      drops = [];
    const init = () => {
      const w = canvas.parentElement.clientWidth,
        h = canvas.parentElement.clientHeight;
      canvas.width = w;
      canvas.height = h;
      cols = Math.floor(w / font);
      drops = Array.from({
        length: cols
      }, () => Math.random() * h / font);
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, w, h); // initial paint
    };
    const tick = () => {
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = font + 'px ui-monospace, monospace';
      ctx.textBaseline = 'top';
      for (let i = 0; i < cols; i++) {
        ctx.fillStyle = `rgba(${rgb}, ${alpha})`;
        ctx.fillText(EXP_RAIN[Math.random() * EXP_RAIN.length | 0], i * font, drops[i] * font);
        if (drops[i] * font > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    };
    init();
    // Pre-roll a few frames so glyphs are visible immediately, then animate.
    for (let i = 0; i < 40; i++) tick();
    const id = setInterval(tick, frame);
    const ro = new ResizeObserver(() => {
      init();
      for (let i = 0; i < 40; i++) tick();
    });
    ro.observe(canvas.parentElement);
    return () => {
      clearInterval(id);
      ro.disconnect();
    };
  }, [color, alpha, font, frame]);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none'
    }
  });
}

/* Dual-mode hero widget. mode: 'hist' (Beta distribution) | 'ts' (AR(1)).
   Drag the figure in hist mode: centre = mean (α:β skew), grips = concentration. */
function HeroWidget({
  accent = '#0465ad',
  data = '#8c0527',
  w = 440,
  h = 190,
  toggleStyle = 'pill',
  mode: cMode,
  onMode,
  onReadout,
  hideToggle = false,
  hideGrips = false,
  alpha: cAlpha,
  beta: cBeta,
  phi: cPhi,
  noise: cNoise
}) {
  const [iMode, setIMode] = React.useState('hist');
  const mode = cMode ?? iMode;
  const setMode = onMode ?? setIMode;
  const ref = React.useRef(null);
  const st = React.useRef({
    alpha: 2,
    beta: 2,
    phi: 0.92,
    noise: 0.5,
    drag: 'none',
    series: []
  });
  // Controlled params: external sliders write here without re-running the effect.
  if (cAlpha != null) st.current.alpha = cAlpha;
  if (cBeta != null) st.current.beta = cBeta;
  if (cPhi != null) st.current.phi = cPhi;
  if (cNoise != null) st.current.noise = cNoise;
  React.useEffect(() => {
    const canvas = ref.current,
      ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const aRGB = hexToRgb(accent),
      dRGB = hexToRgb(data);
    const BASE = h - 42;
    // seed AR(1)
    if (!st.current.series.length) {
      let v = 0;
      const arr = [];
      for (let i = 0; i < 90; i++) {
        v = 0.92 * v + (Math.random() - 0.5) * 0.5;
        arr.push(v);
      }
      st.current.series = arr;
    }
    let raf = 0,
      last = 0,
      phase = 0;
    const draw = now => {
      ctx.clearRect(0, 0, w, h);
      if (mode === 'hist') {
        // Ease the *displayed* α/β toward their targets so the shape morphs slowly
        // when dragged or slid, instead of snapping. Smaller ease = slower glide.
        if (st.current.dAlpha == null) {
          st.current.dAlpha = st.current.alpha;
          st.current.dBeta = st.current.beta;
        }
        const ease = 0.16;
        st.current.dAlpha += (st.current.alpha - st.current.dAlpha) * ease;
        st.current.dBeta += (st.current.beta - st.current.dBeta) * ease;
        // Beta(α, β) density over [0,1] — the histogram x-axis.
        const alpha = st.current.dAlpha,
          beta = st.current.dBeta,
          cols = 28,
          bw = w / cols,
          amp = BASE * 0.9,
          wig = now / 900;
        const dens = [];
        let peak = 1e-9;
        for (let k = 0; k < cols; k++) {
          const xf = (k + 0.5) / cols;
          const d = Math.pow(xf, alpha - 1) * Math.pow(1 - xf, beta - 1);
          dens.push(d);
          if (d > peak) peak = d;
        }
        for (let k = 0; k < cols; k++) {
          const g = dens[k] / peak; // normalised height 0..1
          const bh = Math.max(0, g * amp + Math.sin(wig + k * 0.7) * 5 * g);
          ctx.fillStyle = `rgba(${aRGB}, 0.28)`;
          ctx.fillRect(k * bw + 1.5, BASE - bh + 2, bw - 1, bh);
          ctx.fillStyle = `rgba(${dRGB}, ${0.5 + g * 0.4})`;
          ctx.fillRect(k * bw + 0.5, BASE - bh, bw - 1, bh);
        }
        if (!hideGrips) {
          // Draggable mean / ±σ control bracket beneath the bars.
          const s = alpha + beta,
            mean = alpha / s;
          const sd = Math.sqrt(alpha * beta / (s * s * (s + 1)));
          const mx = mean * w,
            half = sd * w,
            lx = Math.max(6, mx - half),
            rx = Math.min(w - 6, mx + half);
          const py = BASE + 18,
            pulse = 0.5 + 0.5 * Math.sin(now / 2000 * Math.PI * 2);
          ctx.strokeStyle = `rgba(${aRGB}, 0.45)`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.roundRect(lx, py - 3, rx - lx, 6, 3);
          ctx.stroke();
          const grip = x => {
            ctx.save();
            ctx.shadowColor = `rgba(${aRGB},0.5)`;
            ctx.shadowBlur = 3 + pulse * 4;
            ctx.fillStyle = `rgba(${aRGB}, ${0.65 + pulse * 0.1})`;
            ctx.beginPath();
            ctx.roundRect(x - 3, py - 8, 6, 16, 3);
            ctx.fill();
            ctx.restore();
          };
          grip(lx);
          grip(rx);
          ctx.save();
          ctx.shadowColor = `rgba(${aRGB},0.5)`;
          ctx.shadowBlur = 3 + pulse * 4;
          ctx.fillStyle = `rgba(${aRGB}, ${0.65 + pulse * 0.1})`;
          ctx.beginPath();
          ctx.arc(mx, py, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      } else {
        // Live AR(1): stream a new sample each frame so the series visibly runs.
        const phi = st.current.phi,
          noise = st.current.noise;
        const gauss = () => Math.random() + Math.random() + Math.random() + Math.random() - 2;
        const arr = st.current.series;
        const lastV = arr.length ? arr[arr.length - 1] : 0;
        arr.push(phi * lastV + noise * gauss());
        while (arr.length > 90) arr.shift();
        const n = arr.length;
        // Locked y-axis: fixed reference scale (≈ default σ/φ) so the axis no longer
        // breathes with the params. Now σ and φ genuinely move the line relative to μ —
        // small σ hugs the mean, large σ (or φ→1) swings wide and clips.
        const REF_SD = 0.5 / Math.sqrt(1 - 0.92 * 0.92);
        const div = 3.2 * REF_SD,
          midY = BASE / 2 + 12,
          ampY = BASE / 2 - 6;
        const PW = w - 6; // plot width
        const yOf = v => midY - Math.max(-1, Math.min(1, v / div)) * ampY;
        // μ baseline — the level the AR(1) regresses toward (μ = 0 here).
        ctx.save();
        ctx.strokeStyle = `rgba(${aRGB},0.5)`;
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(0, midY);
        ctx.lineTo(PW, midY);
        ctx.stroke();
        ctx.restore();
        ctx.beginPath();
        ctx.moveTo(0, BASE + 6);
        arr.forEach((v, i) => ctx.lineTo(i / (n - 1) * PW, yOf(v)));
        ctx.lineTo(PW, BASE + 6);
        ctx.closePath();
        const grd = ctx.createLinearGradient(0, 0, 0, BASE);
        grd.addColorStop(0, `rgba(${dRGB},0.22)`);
        grd.addColorStop(1, `rgba(${dRGB},0)`);
        ctx.fillStyle = grd;
        ctx.fill();
        ctx.strokeStyle = `rgba(${dRGB},0.9)`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        arr.forEach((v, i) => {
          const x = i / (n - 1) * PW,
            y = yOf(v);
          i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        });
        ctx.stroke();
        const ly = yOf(arr[n - 1]);
        ctx.fillStyle = `rgba(${aRGB},0.9)`;
        ctx.beginPath();
        ctx.arc(PW - 2, ly, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    draw(performance.now());
    if (onReadout) onReadout(st.current.alpha, st.current.beta);
    const drawId = setInterval(() => draw(performance.now()), 70);
    const pos = e => {
      const r = canvas.getBoundingClientRect();
      return e.clientX - r.left;
    };
    const params = () => {
      const {
          alpha,
          beta
        } = st.current,
        s = alpha + beta;
      return {
        mean: alpha / s,
        sd: Math.sqrt(alpha * beta / (s * s * (s + 1))),
        s
      };
    };
    const down = e => {
      if (mode !== 'hist' || hideGrips) return;
      const x = pos(e),
        {
          mean,
          sd
        } = params();
      const mx = mean * w,
        lx = mx - sd * w,
        rx = mx + sd * w;
      if (Math.abs(x - mx) < 12) st.current.drag = 'move';else if (Math.abs(x - lx) < 10 || Math.abs(x - rx) < 10) st.current.drag = 'spread';
      canvas.setPointerCapture(e.pointerId);
    };
    const move = e => {
      const x = pos(e),
        d = st.current.drag;
      if (d === 'none') return;
      let {
        mean,
        s
      } = params();
      if (d === 'move') {
        mean = Math.max(0.1, Math.min(0.9, x / w));
      } else if (d === 'spread') {
        const sd = Math.max(0.04, Math.min(0.42, Math.abs(x - mean * w) / w));
        s = Math.max(1.4, Math.min(40, mean * (1 - mean) / (sd * sd) - 1));
      }
      const alpha = Math.max(0.4, Math.min(8, mean * s)),
        beta = Math.max(0.4, Math.min(8, (1 - mean) * s));
      st.current.alpha = alpha;
      st.current.beta = beta;
      if (onReadout) onReadout(alpha, beta);
      canvas.style.cursor = 'grabbing';
    };
    const up = () => {
      st.current.drag = 'none';
      canvas.style.cursor = mode === 'hist' && !hideGrips ? 'grab' : 'default';
    };
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    return () => {
      clearInterval(drawId);
      canvas.removeEventListener('pointerdown', down);
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerup', up);
    };
  }, [mode, accent, data, w, h]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: w,
      maxWidth: '100%'
    }
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    style: {
      cursor: mode === 'hist' && !hideGrips ? 'grab' : 'default',
      touchAction: 'none',
      display: 'block'
    }
  }), !hideToggle && /*#__PURE__*/React.createElement("div", {
    className: 'hw-toggle hw-toggle-' + toggleStyle
  }, /*#__PURE__*/React.createElement("button", {
    className: mode === 'hist' ? 'on' : '',
    onClick: () => setMode('hist'),
    title: "Beta distribution",
    "aria-label": "Distribution view"
  }, "\u2229"), /*#__PURE__*/React.createElement("button", {
    className: mode === 'ts' ? 'on' : '',
    onClick: () => setMode('ts'),
    title: "Time series",
    "aria-label": "Time-series view"
  }, "\u301C")));
}

/* Small draggable parameter slider (μ, σ …) — instrument styled, label-light. */
function ParamSlider({
  label,
  value,
  min,
  max,
  onChange
}) {
  const ref = React.useRef(null);
  const frac = Math.max(0, Math.min(1, (value - min) / (max - min)));
  const setFromX = clientX => {
    const r = ref.current.getBoundingClientRect();
    const f = Math.max(0, Math.min(1, (clientX - r.left) / r.width));
    onChange(min + f * (max - min));
  };
  const down = e => {
    setFromX(e.clientX);
    const mv = ev => setFromX(ev.clientX);
    const up = () => {
      window.removeEventListener('pointermove', mv);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', mv);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "ps"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ps-l"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "ps-track",
    ref: ref,
    onPointerDown: down
  }, /*#__PURE__*/React.createElement("div", {
    className: "ps-fill",
    style: {
      width: frac * 100 + '%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "ps-knob",
    style: {
      left: frac * 100 + '%'
    }
  })));
}

/* Standalone toggle — tiny, icon-only. Sliders carry the parameter values. */
function HeroControls({
  mode,
  onMode
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "hwc-mini"
  }, /*#__PURE__*/React.createElement("button", {
    className: mode === 'hist' ? 'on' : '',
    onClick: () => onMode('hist'),
    title: "Distribution",
    "aria-label": "Distribution"
  }, "\u2229"), /*#__PURE__*/React.createElement("button", {
    className: mode === 'ts' ? 'on' : '',
    onClick: () => onMode('ts'),
    title: "Time series",
    "aria-label": "Time series"
  }, "\u301C"));
}

/* AstroTerminal — a fake LLM-on-a-Linux-shell streaming pseudo-statistical
   blather, typed line by line with a blinking caret, then looping.
   Used in the home page's Problem band. */
function AstroTerminal({
  accent = '#c8607a',
  w = 380,
  h = 210,
  fs = 'clamp(8px, 1.15vw, 12px)'
}) {
  const SCRIPT = [{
    t: 'in',
    s: '$ astro-llm "is p significant?"'
  }, {
    t: 'sys',
    s: '▸ loading posterior weights … ok'
  }, {
    t: 'out',
    s: 'Fitting a hierarchical model to your'
  }, {
    t: 'out',
    s: 'noise. Bootstrapping 10,000 resamples…'
  }, {
    t: 'ok',
    s: '✓ p = 0.049 → "basically significant"'
  }, {
    t: 'warn',
    s: '⚠ assumptions: not checked'
  }, {
    t: 'warn',
    s: '⚠ multiple comparisons: ignored'
  }, {
    t: 'out',
    s: 'Recommendation: ship it. Looks right.'
  }, {
    t: 'in',
    s: '$ _'
  }];
  const [ln, setLn] = React.useState(0);
  const [ch, setCh] = React.useState(0);
  React.useEffect(() => {
    const cur = SCRIPT[ln];
    if (!cur) {
      const r = setTimeout(() => {
        setLn(0);
        setCh(0);
      }, 2200);
      return () => clearTimeout(r);
    }
    if (ch < cur.s.length) {
      const id = setTimeout(() => setCh(ch + 1), 26);
      return () => clearTimeout(id);
    }
    const id = setTimeout(() => {
      setLn(ln + 1);
      setCh(0);
    }, cur.t === 'in' ? 420 : 240);
    return () => clearTimeout(id);
  }, [ln, ch]);
  const colorFor = t => t === 'in' ? '#fbf6ec' : t === 'ok' ? '#3fb9b9' : t === 'warn' ? accent : t === 'sys' ? 'rgba(251,246,236,.45)' : 'rgba(251,246,236,.72)';
  const shown = SCRIPT.slice(0, ln);
  const typing = SCRIPT[ln];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: w,
      maxWidth: '100%',
      height: h,
      border: '1px solid rgba(251,246,236,.24)',
      background: '#040404',
      fontFamily: 'ui-monospace,monospace',
      fontSize: fs,
      lineHeight: 1.55,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: '7px 10px',
      borderBottom: '1px solid rgba(251,246,236,.16)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: accent,
      opacity: .8
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      letterSpacing: '.12em',
      textTransform: 'uppercase',
      color: 'rgba(251,246,236,.4)'
    }
  }, "astro-llm \u2014 bash")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 12px',
      flex: 1,
      overflow: 'hidden'
    }
  }, shown.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      color: colorFor(l.t),
      whiteSpace: 'pre'
    }
  }, l.s)), typing && /*#__PURE__*/React.createElement("div", {
    style: {
      color: colorFor(typing.t),
      whiteSpace: 'pre'
    }
  }, typing.s.slice(0, ch), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: 7,
      height: 13,
      background: accent,
      verticalAlign: '-2px',
      animation: 'atb 1s steps(1) infinite'
    }
  }))), /*#__PURE__*/React.createElement("style", null, `@keyframes atb{50%{opacity:0}}`));
}
Object.assign(window, {
  CodeRainBG,
  HeroWidget,
  HeroControls,
  ParamSlider,
  AstroTerminal,
  EXP_hexToRgb: hexToRgb
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/site-effects.jsx", error: String((e && e.message) || e) }); }

// explorations/stat-viz.jsx
try { (() => {
/* Statistics-themed animated visuals for filling the rail-band void.
   Each is sized to sit on the right of a rail body (~260×150). Brand colours only.
   Exposed on window at the end for the Babel-scope sharing rule. */

const VIZ_BLUE = '#3b9be0';
const VIZ_BLUEDIM = 'rgba(59,155,224,.9)';
const VIZ_RED = '#c8607a';
const vizColor = accent => accent === 'red' ? VIZ_RED : VIZ_BLUE;
function useTick(ms, deps = []) {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setT(v => v + 1), ms);
    return () => clearInterval(id);
  }, deps);
  return t;
}

/* 1 — Live histogram: bars resample toward a bell shape, heights ease each tick */
function VizHistogram({
  accent,
  w = 260,
  h = 150
}) {
  const c = vizColor(accent);
  const n = 13;
  const target = React.useRef([...Array(n)].map((_, i) => {
    const x = (i - (n - 1) / 2) / 3;
    return Math.exp(-x * x / 2);
  }));
  const [hgt, setHgt] = React.useState(() => target.current.map(() => 0.1));
  useTick(140, []);
  React.useEffect(() => {
    const id = setInterval(() => {
      setHgt(prev => prev.map((v, i) => {
        const jitter = target.current[i] * (0.75 + Math.random() * 0.5);
        return v + (jitter - v) * 0.25;
      }));
    }, 140);
    return () => clearInterval(id);
  }, []);
  const bw = w / n;
  return /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: h,
    viewBox: `0 0 ${w} ${h}`
  }, /*#__PURE__*/React.createElement("line", {
    x1: "0",
    y1: h - 12,
    x2: w,
    y2: h - 12,
    stroke: "rgba(251,246,236,.2)",
    strokeWidth: "1"
  }), hgt.map((v, i) => {
    const bh = Math.max(3, v * (h - 26));
    return /*#__PURE__*/React.createElement("rect", {
      key: i,
      x: i * bw + 2,
      y: h - 12 - bh,
      width: bw - 4,
      height: bh,
      fill: c,
      opacity: 0.35 + v * 0.5
    });
  }));
}

/* 2 — Scatter + least-squares line: points jitter around a trend, line tracks them */
function VizScatter({
  accent,
  w = 260,
  h = 150
}) {
  const c = vizColor(accent);
  const n = 22;
  const base = React.useRef([...Array(n)].map(() => ({
    x: Math.random(),
    n1: Math.random(),
    n2: Math.random()
  })));
  const t = useTick(90, []);
  const pad = 12;
  const pts = base.current.map((p, i) => {
    const wobble = Math.sin(t / 8 + i) * 0.04 + (p.n1 - 0.5) * 0.16;
    const x = pad + p.x * (w - 2 * pad);
    const yv = 0.15 + p.x * 0.6 + wobble;
    const y = pad + yv * (h - 2 * pad);
    return {
      x,
      y
    };
  });
  const mx = pts.reduce((s, p) => s + p.x, 0) / n,
    my = pts.reduce((s, p) => s + p.y, 0) / n;
  let num = 0,
    den = 0;
  pts.forEach(p => {
    num += (p.x - mx) * (p.y - my);
    den += (p.x - mx) * (p.x - mx);
  });
  const slope = num / den,
    b = my - slope * mx;
  return /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: h,
    viewBox: `0 0 ${w} ${h}`
  }, /*#__PURE__*/React.createElement("line", {
    x1: pad,
    y1: slope * pad + b,
    x2: w - pad,
    y2: slope * (w - pad) + b,
    stroke: c,
    strokeWidth: "1.5",
    opacity: "0.85"
  }), pts.map((p, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: p.x,
    cy: p.y,
    r: "2.6",
    fill: c,
    opacity: "0.7"
  })));
}

/* 3 — Gaussian curve with a sliding shaded quantile area */
function VizBellCurve({
  accent,
  w = 260,
  h = 150
}) {
  const c = vizColor(accent);
  const t = useTick(60, []);
  const pad = 12,
    span = w - 2 * pad,
    base = h - 16;
  const gauss = x => {
    const d = (x - 0.5) * 6;
    return Math.exp(-(d * d) / 2);
  };
  const path = [];
  for (let i = 0; i <= 60; i++) {
    const fx = i / 60,
      x = pad + fx * span,
      y = base - gauss(fx) * (h - 34);
    path.push(`${i === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  const cut = 0.5 + Math.sin(t / 30) * 0.32;
  const area = [`M${pad} ${base}`];
  for (let i = 0; i <= 60; i++) {
    const fx = i / 60;
    if (fx > cut) break;
    area.push(`L${(pad + fx * span).toFixed(1)} ${(base - gauss(fx) * (h - 34)).toFixed(1)}`);
  }
  area.push(`L${(pad + cut * span).toFixed(1)} ${base}Z`);
  return /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: h,
    viewBox: `0 0 ${w} ${h}`
  }, /*#__PURE__*/React.createElement("line", {
    x1: pad,
    y1: base,
    x2: w - pad,
    y2: base,
    stroke: "rgba(251,246,236,.2)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: area.join(' '),
    fill: c,
    opacity: "0.22"
  }), /*#__PURE__*/React.createElement("path", {
    d: path.join(' '),
    fill: "none",
    stroke: c,
    strokeWidth: "1.8"
  }), /*#__PURE__*/React.createElement("line", {
    x1: pad + cut * span,
    y1: base,
    x2: pad + cut * span,
    y2: base - gauss(cut) * (h - 34),
    stroke: c,
    strokeWidth: "1",
    opacity: "0.7"
  }));
}

/* 4 — Random walk / live signal trace scrolling left */
function VizRandomWalk({
  accent,
  w = 260,
  h = 150
}) {
  const c = vizColor(accent);
  const [pts, setPts] = React.useState(() => [...Array(40)].map(() => 0.5));
  React.useEffect(() => {
    const id = setInterval(() => {
      setPts(prev => {
        const last = prev[prev.length - 1];
        let nx = last + (Math.random() - 0.5) * 0.18;
        nx = Math.max(0.08, Math.min(0.92, nx));
        return [...prev.slice(1), nx];
      });
    }, 110);
    return () => clearInterval(id);
  }, []);
  const step = w / (pts.length - 1);
  const d = pts.map((v, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)} ${(v * (h - 20) + 10).toFixed(1)}`).join(' ');
  return /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: h,
    viewBox: `0 0 ${w} ${h}`
  }, /*#__PURE__*/React.createElement("line", {
    x1: "0",
    y1: h / 2,
    x2: w,
    y2: h / 2,
    stroke: "rgba(251,246,236,.14)",
    strokeWidth: "1",
    strokeDasharray: "3 4"
  }), /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "none",
    stroke: c,
    strokeWidth: "1.8"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: w,
    cy: pts[pts.length - 1] * (h - 20) + 10,
    r: "3",
    fill: c
  }));
}

/* 5 — Convergence: running mean of noisy samples settling toward a line */
function VizConvergence({
  accent,
  w = 260,
  h = 150
}) {
  const c = vizColor(accent);
  const [data, setData] = React.useState({
    pts: [],
    mean: []
  });
  React.useEffect(() => {
    let running = 0,
      k = 0;
    const id = setInterval(() => {
      setData(prev => {
        k++;
        const s = 0.5 + (Math.random() - 0.5) * (0.8 / Math.sqrt(k));
        running += s;
        const m = running / k;
        const pts = [...prev.pts, s].slice(-46),
          mean = [...prev.mean, m].slice(-46);
        if (k > 200) {
          running = 0;
          k = 0;
          return {
            pts: [],
            mean: []
          };
        }
        return {
          pts,
          mean
        };
      });
    }, 90);
    return () => clearInterval(id);
  }, []);
  const N = 46,
    step = w / (N - 1);
  const y = v => (1 - v) * (h - 20) + 10;
  return /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: h,
    viewBox: `0 0 ${w} ${h}`
  }, /*#__PURE__*/React.createElement("line", {
    x1: "0",
    y1: y(0.5),
    x2: w,
    y2: y(0.5),
    stroke: "rgba(251,246,236,.2)",
    strokeWidth: "1",
    strokeDasharray: "3 4"
  }), data.pts.map((v, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: i * step,
    cy: y(v),
    r: "1.8",
    fill: c,
    opacity: "0.35"
  })), /*#__PURE__*/React.createElement("path", {
    d: data.mean.map((v, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)} ${y(v).toFixed(1)}`).join(' '),
    fill: "none",
    stroke: c,
    strokeWidth: "1.8"
  }));
}

/* 6 — the original animated pixel matrix, enlarged */
function VizPixels({
  accent,
  w = 260,
  h = 150
}) {
  const cols = 16,
    rows = Math.round(cols * h / w);
  const total = cols * rows;
  const c = vizColor(accent);
  const t = useTick(70, []);
  const active = t % total;
  const cw = w / cols;
  const cells = [];
  for (let i = 0; i < total; i++) {
    const dist = (active - i + total) % total;
    const op = dist === 0 ? 1 : dist === 1 ? 0.5 : dist === 2 ? 0.28 : dist === 3 ? 0.16 : 0.07;
    const cx = i % cols * cw,
      cy = Math.floor(i / cols) * cw;
    cells.push(/*#__PURE__*/React.createElement("rect", {
      key: i,
      x: cx + 1,
      y: cy + 1,
      width: cw - 2,
      height: cw - 2,
      fill: c,
      opacity: op
    }));
  }
  return /*#__PURE__*/React.createElement("svg", {
    width: w,
    height: rows * cw,
    viewBox: `0 0 ${w} ${rows * cw}`
  }, cells);
}
Object.assign(window, {
  VizHistogram,
  VizScatter,
  VizBellCurve,
  VizRandomWalk,
  VizConvergence,
  VizPixels,
  VizTerminal
});

/* Terminal — a fake LLM-on-a-Linux-shell streaming pseudo-statistical blather,
   typed out line by line with a blinking caret, then looping. */
function VizTerminal({
  accent = 'red',
  w = 380,
  h = 210
}) {
  const c = vizColor(accent);
  const SCRIPT = [{
    t: 'in',
    s: '$ astro-llm "is my p-value significant?"'
  }, {
    t: 'sys',
    s: '▸ loading posterior weights ........ ok'
  }, {
    t: 'out',
    s: 'Fitting a hierarchical model to your'
  }, {
    t: 'out',
    s: 'noise. Bootstrapping 10,000 resamples…'
  }, {
    t: 'ok',
    s: '✓ p = 0.049 → "basically significant"'
  }, {
    t: 'warn',
    s: '⚠ assumptions: not checked'
  }, {
    t: 'warn',
    s: '⚠ multiple comparisons: ignored'
  }, {
    t: 'out',
    s: 'Recommendation: ship it. Looks right.'
  }, {
    t: 'in',
    s: '$ _'
  }];
  const [ln, setLn] = React.useState(0);
  const [ch, setCh] = React.useState(0);
  React.useEffect(() => {
    const cur = SCRIPT[ln];
    if (!cur) {
      const r = setTimeout(() => {
        setLn(0);
        setCh(0);
      }, 2200);
      return () => clearTimeout(r);
    }
    if (ch < cur.s.length) {
      const id = setTimeout(() => setCh(ch + 1), 26);
      return () => clearTimeout(id);
    }
    const id = setTimeout(() => {
      setLn(ln + 1);
      setCh(0);
    }, cur.t === 'in' ? 420 : 240);
    return () => clearTimeout(id);
  }, [ln, ch]);
  const colorFor = t => t === 'in' ? '#fbf6ec' : t === 'ok' ? '#3fb9b9' : t === 'warn' ? c : t === 'sys' ? 'rgba(251,246,236,.45)' : 'rgba(251,246,236,.72)';
  const shown = SCRIPT.slice(0, ln);
  const typing = SCRIPT[ln];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: w,
      height: h,
      border: '1px solid rgba(251,246,236,.24)',
      background: '#040404',
      fontFamily: 'ui-monospace,monospace',
      fontSize: 12,
      lineHeight: 1.55,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: '7px 10px',
      borderBottom: '1px solid rgba(251,246,236,.16)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: c,
      opacity: .8
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      letterSpacing: '.12em',
      textTransform: 'uppercase',
      color: 'rgba(251,246,236,.4)'
    }
  }, "astro-llm \u2014 bash")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 12px',
      flex: 1,
      overflow: 'hidden'
    }
  }, shown.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      color: colorFor(l.t),
      whiteSpace: 'pre'
    }
  }, l.s)), typing && /*#__PURE__*/React.createElement("div", {
    style: {
      color: colorFor(typing.t),
      whiteSpace: 'pre'
    }
  }, typing.s.slice(0, ch), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: 7,
      height: 13,
      background: c,
      verticalAlign: '-2px',
      animation: 'vtb 1s steps(1) infinite'
    }
  }))), /*#__PURE__*/React.createElement("style", null, `@keyframes vtb{50%{opacity:0}}`));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/stat-viz.jsx", error: String((e && e.message) || e) }); }

// explorations/world-land.js
try { (() => {
/* World land + country outlines — Natural Earth 1:110m (public domain), RDP eps=0.35, 2dp. [lon,lat] rings. */
window.WORLD_LAND = [[[61.21, 35.65], [62.98, 35.4], [65.75, 37.66], [69.2, 37.15], [70.81, 38.49], [71.84, 36.74], [73.26, 37.5], [75.16, 37.13], [71.85, 36.51], [71.26, 36.07], [71.61, 35.15], [70.88, 33.99], [69.93, 34.02], [70.32, 33.36], [69.26, 32.5], [69.32, 31.9], [66.94, 31.3], [66.35, 29.89], [64.15, 29.34], [60.87, 29.83], [61.78, 30.74], [60.54, 32.98], [61.21, 35.65]], [[16.33, -5.88], [17.47, -8.07], [19.02, -7.99], [20.09, -6.94], [21.73, -7.29], [22.16, -11.08], [23.91, -10.93], [24.02, -12.91], [21.93, -12.9], [21.89, -16.08], [23.22, -17.52], [21.38, -17.93], [18.26, -17.31], [14.06, -17.42], [13.46, -16.97], [11.73, -17.3], [12.18, -14.45], [13.74, -11.3], [12.23, -6.29], [16.33, -5.88]], [[12.44, -5.68], [11.91, -5.04], [12.62, -4.44], [13, -4.78], [12.44, -5.68]], [[20.59, 41.86], [21, 40.58], [20.15, 39.62], [19.41, 40.25], [19.3, 42.2], [19.74, 42.69], [20.59, 41.86]], [[51.58, 24.25], [54.01, 24.12], [56.07, 26.06], [56.26, 25.71], [56.4, 24.92], [55.89, 24.92], [55.98, 24.13], [55.01, 22.5], [52, 23], [51.58, 24.25]], [[-65.5, -55.2], [-68.63, -54.87], [-68.63, -52.64], [-67.75, -53.85], [-65.05, -54.7], [-65.5, -55.2]], [[-64.96, -22.08], [-64.38, -22.8], [-63.99, -21.99], [-62.85, -22.03], [-60.85, -23.88], [-57.78, -25.16], [-58.62, -27.12], [-55.7, -27.39], [-54.13, -25.55], [-53.65, -26.92], [-57.63, -30.22], [-58.5, -34.43], [-57.23, -35.29], [-56.79, -36.9], [-57.75, -38.18], [-59.23, -38.72], [-62.34, -38.83], [-62.15, -40.68], [-62.75, -41.03], [-65.12, -41.06], [-64.98, -42.06], [-63.76, -42.04], [-63.46, -42.56], [-65.18, -43.5], [-65.57, -45.04], [-67.29, -45.55], [-67.58, -46.3], [-65.64, -47.24], [-65.99, -48.13], [-69.14, -50.73], [-68.15, -52.35], [-71.91, -52.01], [-72.31, -50.68], [-73.33, -50.38], [-73.42, -49.32], [-72.33, -48.24], [-71.66, -44.97], [-71.22, -44.78], [-72.15, -42.25], [-71.41, -38.92], [-70.81, -38.55], [-71.12, -36.66], [-70.36, -36.01], [-69.82, -34.19], [-70.54, -31.37], [-69.66, -28.46], [-68.3, -26.9], [-68.42, -24.52], [-67.33, -24.03], [-67.11, -22.74], [-66.27, -21.83], [-64.96, -22.08]], [[43.58, 41.09], [45.56, 40.81], [46.51, 38.77], [43.66, 40.25], [43.58, 41.09]], [[-59.57, -80.04], [-60.16, -81], [-64.49, -80.92], [-66.29, -80.26], [-61.88, -80.39], [-60.61, -79.63], [-59.57, -80.04]], [[-159.21, -79.5], [-161.13, -79.63], [-163.71, -78.6], [-161.25, -78.38], [-159.21, -79.5]], [[-45.15, -78.05], [-43.92, -78.48], [-43.33, -80.03], [-50.48, -81.03], [-54.16, -80.63], [-50.99, -79.61], [-48.66, -78.05], [-45.15, -78.05]], [[-121.21, -73.5], [-118.72, -73.48], [-120.23, -74.09], [-122.62, -73.66], [-121.21, -73.5]], [[-125.56, -73.48], [-124.03, -73.87], [-127.28, -73.46], [-125.56, -73.48]], [[-98.98, -71.93], [-96.79, -71.95], [-96.2, -72.52], [-100.78, -72.5], [-102.33, -71.89], [-98.98, -71.93]], [[-68.45, -70.96], [-68.78, -72.17], [-71.08, -72.5], [-72.39, -72.48], [-71.9, -72.09], [-74.19, -72.37], [-75.01, -71.66], [-72.07, -71.19], [-71.74, -69.51], [-70.25, -68.88], [-68.45, -70.96]], [[-58.61, -64.15], [-62.02, -64.8], [-62.65, -65.48], [-62.12, -66.19], [-63.75, -66.5], [-65.67, -67.95], [-63.2, -69.23], [-61.81, -70.72], [-60.83, -73.7], [-64.35, -75.26], [-70.6, -76.63], [-77.24, -76.71], [-73.66, -77.91], [-77.93, -78.38], [-78.02, -79.18], [-75.36, -80.26], [-59.69, -82.38], [-58.22, -83.22], [-49.76, -81.73], [-42.81, -82.08], [-40.77, -81.36], [-28.55, -80.34], [-29.69, -79.26], [-35.64, -79.46], [-35.78, -78.34], [-35.33, -78.12], [-28.88, -76.67], [-17.52, -75.13], [-15.7, -74.5], [-15.41, -74.11], [-16.47, -73.87], [-15.45, -73.15], [-12.29, -72.4], [-10.3, -71.27], [-7.42, -71.7], [-6.87, -70.93], [-4.34, -71.46], [-0.66, -71.23], [-0.23, -71.64], [7.74, -69.89], [9.53, -70.01], [10.82, -70.83], [13.42, -69.97], [15.13, -70.4], [19.26, -69.89], [22.57, -70.7], [27.09, -70.46], [31.99, -69.66], [33.87, -68.5], [38.65, -69.78], [54.53, -65.82], [56.36, -65.97], [58.74, -67.29], [61.43, -67.95], [64.05, -67.41], [68.89, -67.93], [69.67, -69.23], [67.81, -70.31], [69.07, -70.68], [67.95, -71.85], [69.87, -72.26], [71.02, -72.09], [73.86, -69.87], [77.64, -69.46], [79.11, -68.33], [82.78, -67.21], [86.75, -67.15], [87.99, -66.21], [89.67, -67.15], [95.78, -67.39], [99.72, -67.25], [102.83, -65.56], [106.18, -66.93], [113.6, -65.88], [115.6, -66.7], [119.83, -67.27], [123.22, -66.48], [128.8, -66.76], [134.76, -66.21], [135.07, -65.31], [137.46, -66.95], [145.49, -66.92], [146.65, -67.9], [148.84, -68.39], [152.5, -68.87], [154.28, -68.56], [161.57, -70.58], [167.31, -70.83], [171.21, -71.7], [169.29, -73.66], [166.09, -74.38], [163.57, -76.24], [163.49, -77.07], [164.74, -78.18], [167, -78.75], [161.77, -79.16], [159.79, -80.95], [169.4, -83.83], [180, -84.71], [-179.94, -84.72], [-179.06, -84.14], [-174.38, -84.53], [-169.95, -83.88], [-158.07, -85.37], [-148.53, -85.61], [-143.11, -85.04], [-142.89, -84.57], [-153.59, -83.69], [-152.86, -82.04], [-156.84, -81.1], [-150.65, -81.34], [-146.42, -80.34], [-149.53, -79.36], [-155.33, -79.06], [-158.05, -78.03], [-158.37, -76.89], [-151.33, -77.4], [-146.1, -76.48], [-146.2, -75.38], [-144.91, -75.2], [-144.32, -75.54], [-135.21, -74.3], [-119.7, -74.48], [-113.94, -73.71], [-112.3, -74.71], [-100.65, -75.3], [-100.12, -74.87], [-102.55, -74.11], [-103.68, -72.62], [-96.34, -73.62], [-90.09, -73.32], [-89.23, -72.56], [-85.19, -73.48], [-81.47, -73.85], [-80.3, -73.13], [-76.22, -73.97], [-68.94, -73.01], [-67.13, -72.05], [-68.54, -69.72], [-67.58, -68.54], [-67.74, -67.33], [-67.25, -66.88], [-63, -64.64], [-57.81, -63.27], [-57.22, -63.53], [-58.61, -64.15]], [[68.94, -48.62], [70.56, -49.25], [70.28, -49.71], [68.75, -49.77], [68.94, -48.62]], [[145.4, -40.79], [148.29, -40.88], [147.91, -43.21], [146.05, -43.55], [144.72, -41.16], [144.74, -40.7], [145.4, -40.79]], [[143.56, -13.76], [143.92, -14.55], [144.56, -14.17], [145.37, -14.98], [146.39, -18.96], [148.85, -20.39], [149.68, -22.34], [150.73, -22.4], [150.9, -23.46], [153.14, -26.07], [153.57, -28.11], [152.89, -31.64], [150.33, -35.67], [150, -37.43], [146.32, -39.04], [144.88, -38.42], [145.03, -37.9], [143.61, -38.81], [140.64, -38.02], [139.57, -36.14], [138.12, -35.61], [138.21, -34.38], [136.83, -35.26], [137.89, -33.64], [137.81, -32.9], [135.99, -34.89], [135.21, -34.48], [134.27, -32.62], [131.33, -31.5], [126.15, -32.22], [124.22, -32.96], [123.66, -33.89], [119.89, -33.98], [118.02, -35.06], [116.63, -35.03], [115.03, -34.2], [115.71, -33.26], [115.69, -31.61], [113.34, -26.12], [113.78, -26.55], [113.44, -25.62], [114.23, -26.3], [113.39, -24.38], [114.15, -21.76], [114.23, -22.52], [116.71, -20.7], [120.86, -19.68], [123.01, -16.41], [123.43, -17.27], [123.86, -17.07], [123.5, -16.6], [123.82, -16.11], [124.26, -16.33], [125.69, -14.23], [127.07, -13.82], [128.36, -14.87], [129.62, -14.97], [129.41, -14.42], [130.62, -12.54], [132.58, -12.11], [131.82, -11.27], [132.36, -11.13], [135.3, -12.25], [136.49, -11.86], [136.95, -12.35], [135.96, -13.32], [135.5, -15], [140.22, -17.71], [140.88, -17.37], [141.7, -15.04], [142.14, -11.04], [142.52, -10.67], [142.8, -11.16], [143.56, -13.76]], [[16.98, 48.12], [16.01, 46.68], [14.63, 46.43], [12.15, 47.12], [11.05, 46.75], [9.48, 47.1], [9.9, 47.58], [12.93, 47.47], [12.88, 48.29], [13.6, 48.88], [16.5, 48.79], [16.98, 48.12]], [[45, 39.74], [46.14, 38.74], [45.46, 38.87], [45, 39.74]], [[47.37, 41.22], [48.58, 41.81], [50.39, 40.26], [49.57, 40.18], [48.88, 38.32], [48.01, 38.79], [48.06, 39.58], [46.51, 38.77], [46.48, 39.46], [45.61, 39.9], [45.89, 40.22], [44.97, 41.25], [46.5, 41.06], [46.4, 41.86], [47.37, 41.22]], [[29.34, -4.5], [29.02, -2.84], [30.47, -2.41], [30.75, -3.36], [29.34, -4.5]], [[3.31, 51.35], [4.97, 51.48], [6.16, 50.8], [6.04, 50.13], [5.67, 49.53], [4.29, 49.91], [2.66, 50.8], [2.51, 51.15], [3.31, 51.35]], [[2.69, 6.26], [1.87, 6.14], [1.66, 9.13], [0.77, 10.47], [1.45, 11.55], [2.85, 12.24], [3.8, 10.73], [2.72, 8.51], [2.69, 6.26]], [[-2.83, 9.64], [-4.78, 9.82], [-5.4, 10.37], [-5.22, 11.71], [-4.01, 13.47], [-1.07, 14.97], [0.37, 14.93], [1.02, 12.85], [2.18, 12.63], [2.15, 11.94], [0.9, 11], [-2.94, 10.96], [-2.83, 9.64]], [[92.67, 22.04], [92.37, 20.67], [91.42, 22.77], [90.5, 22.81], [90.27, 21.84], [89.03, 22.06], [88.7, 24.23], [88.08, 24.5], [88.93, 25.24], [88.21, 25.77], [88.56, 26.45], [89.83, 25.97], [89.92, 25.27], [92.38, 24.98], [91.16, 23.5], [91.71, 22.99], [92.15, 23.63], [92.67, 22.04]], [[22.66, 44.23], [22.94, 43.82], [27.24, 44.18], [28.56, 43.71], [27.67, 42.58], [28, 42.01], [26.12, 41.83], [26.11, 41.33], [22.95, 41.34], [22.38, 42.32], [22.99, 43.21], [22.66, 44.23]], [[-77.53, 23.76], [-78.41, 24.58], [-78.19, 25.21], [-77.53, 23.76]], [[19.01, 44.86], [19.6, 44.04], [18.56, 42.65], [15.75, 44.82], [15.96, 45.23], [19.01, 44.86]], [[23.48, 53.91], [25.54, 54.28], [26.49, 55.62], [28.18, 56.17], [30.87, 55.55], [30.76, 54.81], [32.69, 53.35], [31.31, 53.07], [31.79, 52.1], [30.93, 52.04], [30.56, 51.32], [25.33, 51.91], [23.53, 51.58], [23.48, 53.91]], [[-89.14, 17.81], [-88.11, 18.35], [-88.93, 15.89], [-89.14, 17.81]], [[-62.85, -22.03], [-63.99, -21.99], [-64.38, -22.8], [-64.96, -22.08], [-66.27, -21.83], [-67.83, -22.87], [-68.76, -20.37], [-68.44, -19.41], [-69.59, -17.58], [-68.96, -16.5], [-69.34, -14.95], [-68.67, -12.56], [-69.53, -10.95], [-68.27, -11.01], [-66.65, -9.93], [-65.34, -9.76], [-65.4, -11.57], [-64.32, -12.46], [-60.5, -13.78], [-60.16, -16.26], [-58.24, -16.3], [-58.28, -17.27], [-57.5, -18.17], [-57.85, -19.97], [-59.12, -19.36], [-61.79, -19.63], [-62.85, -22.03]], [[-57.63, -30.22], [-53.65, -26.92], [-53.63, -26.12], [-54.13, -25.55], [-54.63, -25.74], [-54.29, -24.02], [-55.4, -23.96], [-55.8, -22.36], [-57.94, -22.09], [-58.17, -20.18], [-57.5, -18.17], [-58.28, -17.27], [-58.24, -16.3], [-60.16, -16.26], [-60.5, -13.78], [-64.32, -12.46], [-65.4, -11.57], [-65.34, -9.76], [-66.65, -9.93], [-68.27, -11.01], [-70.55, -11.01], [-70.48, -9.49], [-72.18, -10.05], [-73.23, -9.46], [-73.02, -9.03], [-73.99, -7.52], [-73.12, -6.63], [-72.89, -5.27], [-69.89, -4.3], [-69.42, -1.12], [-70.02, 0.54], [-69.22, 0.99], [-69.8, 1.09], [-69.82, 1.71], [-67.54, 2.04], [-67.07, 1.13], [-65.55, 0.79], [-63.37, 2.2], [-64.27, 2.5], [-64.82, 4.06], [-63.09, 3.77], [-60.21, 5.24], [-59.54, 3.96], [-59.97, 2.76], [-59.03, 1.32], [-56, 1.82], [-55.97, 2.51], [-52.94, 2.12], [-51.32, 4.2], [-50.51, 1.9], [-49.97, 1.74], [-50.7, 0.22], [-50.39, -0.08], [-48.62, -0.24], [-48.58, -1.24], [-47.82, -0.58], [-44.91, -1.55], [-44.58, -2.69], [-43.42, -2.38], [-39.98, -2.87], [-37.22, -4.82], [-35.6, -5.15], [-34.73, -7.34], [-35.13, -9], [-38.67, -13.06], [-39.27, -17.87], [-40.94, -21.94], [-41.99, -22.97], [-44.65, -23.35], [-47.65, -24.89], [-48.5, -25.88], [-48.89, -28.67], [-53.37, -33.77], [-53.65, -33.2], [-53.21, -32.73], [-53.79, -32.05], [-56.98, -30.11], [-57.63, -30.22]], [[114.2, 4.53], [115.45, 5.45], [115.35, 4.32], [114.66, 4.01], [114.2, 4.53]], [[91.7, 27.77], [92.03, 26.84], [88.84, 27.1], [90.02, 28.3], [91.7, 27.77]], [[25.65, -18.54], [27.72, -20.5], [28.02, -21.49], [29.43, -22.09], [27.12, -23.57], [25.66, -25.49], [23.31, -25.27], [20.89, -26.83], [19.9, -24.77], [19.9, -21.85], [20.88, -21.81], [20.91, -18.25], [23.2, -17.87], [23.58, -18.28], [25.08, -17.66], [25.65, -18.54]], [[15.28, 7.42], [17.96, 7.89], [18.81, 8.98], [21, 9.48], [22.86, 11.14], [23.55, 10.09], [23.46, 8.95], [27.37, 5.23], [24.41, 5.11], [22.84, 4.71], [22.41, 4.03], [19.47, 5.03], [18.45, 3.5], [17.13, 3.73], [16.01, 2.27], [14.48, 4.73], [14.54, 6.23], [15.28, 7.42]], [[-63.66, 46.55], [-62.01, 46.44], [-62.87, 45.97], [-64.14, 46.39], [-64.01, 47.04], [-63.66, 46.55]], [[-123.51, 48.51], [-125.66, 48.83], [-128.06, 49.99], [-128.36, 50.77], [-125.76, 50.3], [-123.51, 48.51]], [[-56.13, 50.69], [-56.8, 49.81], [-56.14, 50.15], [-55.47, 49.94], [-55.82, 49.59], [-53.48, 49.25], [-53.79, 48.52], [-53.09, 48.69], [-52.65, 47.54], [-53.07, 46.66], [-54.18, 46.81], [-54.24, 47.75], [-55.4, 46.88], [-56, 46.92], [-55.29, 47.39], [-56.25, 47.63], [-59.27, 47.6], [-58.8, 48.25], [-59.23, 48.52], [-57.36, 50.72], [-55.87, 51.63], [-55.41, 51.59], [-56.13, 50.69]], [[-132.71, 54.04], [-131.75, 54.12], [-132.05, 52.98], [-131.18, 52.18], [-133.05, 53.41], [-133.18, 54.17], [-132.71, 54.04]], [[-81.9, 62.71], [-83.07, 62.16], [-83.99, 62.45], [-83.25, 62.91], [-81.9, 62.71]], [[-85.16, 65.66], [-80.1, 63.73], [-80.99, 63.41], [-83.11, 64.1], [-85.52, 63.05], [-85.87, 63.64], [-87.22, 63.54], [-86.35, 64.04], [-85.88, 65.74], [-85.16, 65.66]], [[-75.87, 67.15], [-76.99, 67.1], [-77.24, 67.59], [-75.9, 68.29], [-75.1, 67.58], [-75.87, 67.15]], [[-95.65, 69.11], [-96.27, 68.76], [-99.8, 69.4], [-98.22, 70.14], [-95.65, 69.11]], [[-90.55, 69.5], [-90.55, 68.47], [-89.22, 69.26], [-88.02, 68.62], [-88.32, 67.87], [-87.35, 67.2], [-85.58, 68.78], [-85.52, 69.88], [-82.62, 69.66], [-81.28, 69.16], [-81.96, 68.13], [-81.26, 67.6], [-81.39, 67.11], [-83.34, 66.41], [-85.77, 66.56], [-87.32, 64.78], [-90.7, 63.61], [-90.77, 62.96], [-91.93, 62.84], [-94.24, 60.9], [-94.68, 58.95], [-93.22, 58.78], [-92.3, 57.09], [-90.9, 57.28], [-85.01, 55.3], [-82.27, 55.15], [-82.13, 53.28], [-79.91, 51.21], [-78.6, 52.56], [-79.83, 54.67], [-78.23, 55.14], [-76.54, 56.53], [-77.3, 58.05], [-78.52, 58.8], [-77.34, 59.85], [-78.11, 62.32], [-77.41, 62.55], [-73.84, 62.44], [-71.37, 61.14], [-69.59, 61.06], [-69.29, 58.96], [-67.65, 58.21], [-66.2, 58.77], [-64.58, 60.34], [-61.4, 56.97], [-61.8, 56.34], [-57.33, 54.63], [-56.94, 53.78], [-55.76, 53.27], [-55.68, 52.15], [-60.03, 50.24], [-66.4, 50.23], [-71.1, 46.82], [-68.65, 48.3], [-65.06, 49.23], [-64.17, 48.74], [-65.12, 48.07], [-64.47, 46.24], [-61.52, 45.88], [-60.52, 47.01], [-59.8, 45.92], [-65.36, 43.55], [-66.12, 43.62], [-66.16, 44.47], [-64.43, 45.29], [-67.14, 45.14], [-68.23, 47.35], [-69.24, 47.45], [-71.51, 45.01], [-74.87, 45], [-76.82, 43.63], [-78.72, 43.63], [-79.17, 43.47], [-78.94, 42.86], [-82.69, 41.68], [-83.12, 42.08], [-82.14, 43.57], [-82.55, 45.35], [-88.38, 48.3], [-91.64, 48.14], [-94.33, 48.67], [-94.82, 49.39], [-95.16, 49], [-122.97, 49], [-127.44, 50.83], [-127.85, 52.33], [-129.13, 52.76], [-129.31, 53.56], [-130.51, 54.29], [-130.01, 55.92], [-131.71, 56.55], [-135.48, 59.79], [-137.45, 58.91], [-139.04, 60], [-141, 60.31], [-140.99, 69.71], [-136.5, 68.9], [-129.79, 70.19], [-129.11, 69.78], [-128.14, 70.48], [-125.76, 69.48], [-124.42, 70.16], [-124.29, 69.4], [-121.47, 69.8], [-115.25, 68.91], [-113.9, 68.4], [-115.3, 67.9], [-113.5, 67.69], [-109.95, 67.98], [-108.88, 67.38], [-107.79, 67.89], [-108.81, 68.31], [-108.17, 68.65], [-106.15, 68.8], [-101.45, 67.65], [-98.44, 67.78], [-98.56, 68.4], [-97.67, 68.58], [-96.12, 68.24], [-96.13, 67.29], [-95.49, 68.09], [-94.68, 68.06], [-94.23, 69.07], [-96.47, 70.09], [-96.39, 71.19], [-95.21, 71.92], [-92.88, 71.32], [-91.52, 70.19], [-92.41, 69.7], [-90.55, 69.5]], [[-114.17, 73.12], [-114.67, 72.65], [-112.44, 72.96], [-111.05, 72.45], [-109.92, 72.96], [-108.19, 71.65], [-107.69, 72.07], [-108.4, 73.09], [-106.52, 73.08], [-105.4, 72.67], [-104.46, 70.99], [-100.98, 70.02], [-101.09, 69.58], [-102.73, 69.5], [-102.09, 69.12], [-102.43, 68.75], [-105.96, 69.18], [-113.31, 68.54], [-116.11, 69.17], [-117.34, 69.96], [-112.42, 70.37], [-117.9, 70.54], [-118.43, 70.91], [-116.11, 71.31], [-119.4, 71.56], [-117.87, 72.71], [-114.17, 73.12]], [[-104.5, 73.42], [-105.38, 72.76], [-106.94, 73.46], [-104.5, 73.42]], [[-76.34, 73.1], [-79.49, 72.74], [-80.88, 73.33], [-80.35, 73.76], [-78.06, 73.65], [-76.34, 73.1]], [[-86.56, 73.16], [-85.77, 72.53], [-84.85, 73.34], [-82.32, 73.75], [-80.6, 72.72], [-80.75, 72.06], [-77.82, 72.75], [-74.23, 71.77], [-74.1, 71.33], [-72.24, 71.56], [-67.91, 70.12], [-66.97, 69.19], [-68.81, 68.72], [-61.85, 66.86], [-63.92, 65], [-66.72, 66.39], [-68.02, 66.26], [-68.14, 65.69], [-65.32, 64.38], [-64.67, 63.39], [-65.01, 62.67], [-68.78, 63.75], [-66.17, 61.93], [-71.02, 62.91], [-74.83, 64.68], [-77.71, 64.23], [-78.56, 64.57], [-77.9, 65.31], [-73.96, 65.45], [-74.29, 65.81], [-72.65, 67.28], [-72.93, 67.73], [-76.87, 68.89], [-76.23, 69.15], [-78.96, 70.17], [-81.31, 69.74], [-88.68, 70.41], [-89.51, 70.76], [-88.47, 71.22], [-89.89, 71.22], [-90.21, 72.24], [-88.41, 73.54], [-85.83, 73.8], [-86.56, 73.16]], [[-100.36, 73.84], [-97.38, 73.76], [-97.12, 73.47], [-98.05, 72.99], [-96.54, 72.56], [-96.72, 71.66], [-99.32, 71.36], [-102.5, 72.51], [-100.44, 72.71], [-101.54, 73.36], [-100.36, 73.84]], [[-93.2, 72.77], [-94.27, 72.02], [-95.41, 72.06], [-96.02, 73.44], [-94.5, 74.13], [-90.51, 73.86], [-93.2, 72.77]], [[-120.46, 71.38], [-123.09, 70.9], [-125.93, 71.87], [-123.94, 73.68], [-124.92, 74.29], [-117.56, 74.19], [-115.51, 73.48], [-119.22, 72.52], [-120.46, 71.38]], [[-93.61, 74.98], [-94.16, 74.59], [-96.82, 74.93], [-94.85, 75.65], [-93.61, 74.98]], [[-98.5, 76.72], [-97.74, 76.26], [-98.16, 75], [-102.5, 75.56], [-102.57, 76.34], [-98.5, 76.72]], [[-108.21, 76.2], [-105.88, 75.97], [-105.7, 75.48], [-106.31, 75.01], [-113.74, 74.39], [-113.87, 74.72], [-111.79, 75.16], [-117.71, 75.22], [-115.4, 76.48], [-109.07, 75.47], [-110.5, 76.43], [-109.58, 76.79], [-108.21, 76.2]], [[-94.68, 77.1], [-91.61, 76.78], [-90.74, 76.45], [-90.97, 76.07], [-89.19, 75.61], [-81.13, 75.71], [-79.83, 74.92], [-88.15, 74.39], [-92.42, 74.84], [-92.89, 75.88], [-93.89, 76.32], [-97.12, 76.75], [-96.75, 77.16], [-94.68, 77.1]], [[-116.2, 77.65], [-116.34, 76.88], [-117.11, 76.53], [-122.85, 76.12], [-119.1, 77.51], [-116.2, 77.65]], [[-110.19, 77.7], [-113.53, 77.73], [-111.26, 78.15], [-109.85, 78], [-110.19, 77.7]], [[-109.66, 78.6], [-112.54, 78.41], [-111.5, 78.85], [-109.66, 78.6]], [[-95.83, 78.06], [-98.12, 78.08], [-98.63, 78.87], [-95.56, 78.42], [-95.83, 78.06]], [[-100.06, 78.32], [-99.67, 77.91], [-105.18, 78.38], [-104.21, 78.68], [-105.49, 79.3], [-100.06, 78.32]], [[-87.02, 79.66], [-85.81, 79.34], [-90.8, 78.22], [-92.88, 78.34], [-93.95, 78.75], [-93.15, 79.38], [-94.97, 79.37], [-96.71, 80.16], [-94.3, 80.98], [-94.74, 81.21], [-92.41, 81.26], [-87.81, 80.32], [-87.02, 79.66]], [[-68.5, 83.11], [-61.89, 82.36], [-67.66, 81.5], [-65.48, 81.51], [-71.18, 79.8], [-76.91, 79.32], [-75.53, 79.2], [-76.22, 79.02], [-75.39, 78.53], [-79.76, 77.21], [-77.89, 76.78], [-80.56, 76.18], [-89.49, 76.47], [-89.62, 76.95], [-87.77, 77.18], [-88.26, 77.9], [-84.98, 77.54], [-87.96, 78.37], [-85.09, 79.35], [-86.93, 80.25], [-81.85, 80.46], [-87.6, 80.52], [-91.59, 81.89], [-85.5, 82.65], [-83.18, 82.32], [-82.42, 82.86], [-79.31, 83.13], [-68.5, 83.11]], [[9.59, 47.53], [9.48, 47.1], [10.44, 46.89], [9.92, 46.31], [7.27, 45.78], [6.02, 46.27], [6.74, 47.54], [9.59, 47.53]], [[-68.63, -52.64], [-68.63, -54.87], [-66.96, -54.9], [-68.15, -55.61], [-71.01, -55.05], [-74.66, -52.84], [-71.11, -54.07], [-70.27, -52.93], [-68.63, -52.64]], [[-68.22, -21.49], [-67.83, -22.87], [-66.99, -22.99], [-67.33, -24.03], [-68.42, -24.52], [-68.3, -26.9], [-69.66, -28.46], [-70.54, -31.37], [-69.82, -34.19], [-70.36, -36.01], [-71.12, -36.66], [-70.81, -38.55], [-71.41, -38.92], [-72.15, -42.25], [-71.22, -44.78], [-71.66, -44.97], [-72.33, -48.24], [-73.42, -49.32], [-73.33, -50.38], [-72.31, -50.68], [-71.91, -52.01], [-68.57, -52.3], [-70.85, -52.9], [-71.43, -53.86], [-74.95, -52.26], [-75.61, -48.67], [-74.13, -46.94], [-75.64, -46.65], [-74.69, -45.76], [-74.35, -44.1], [-73.24, -44.45], [-72.72, -42.38], [-73.39, -42.12], [-73.7, -43.37], [-74.33, -43.22], [-73.22, -39.26], [-73.59, -37.16], [-73.17, -37.12], [-71.44, -32.42], [-71.49, -28.86], [-70.91, -27.64], [-70.09, -21.39], [-70.37, -18.35], [-69.59, -17.58], [-69.1, -18.26], [-68.22, -21.49]], [[110.34, 18.68], [109.48, 18.2], [108.66, 18.51], [108.63, 19.37], [110.79, 20.08], [110.34, 18.68]], [[127.66, 49.76], [129.4, 49.44], [130.58, 48.73], [130.99, 47.79], [135.03, 48.48], [133.77, 46.12], [133.1, 45.14], [131.03, 44.97], [131.14, 42.93], [130.63, 42.9], [130.64, 42.4], [129.99, 42.99], [128.05, 41.99], [128.21, 41.47], [126.87, 41.82], [124.27, 39.93], [121.05, 38.9], [122.17, 40.42], [121.64, 40.95], [117.53, 38.74], [119.7, 37.16], [120.82, 37.87], [122.36, 37.45], [122.52, 36.93], [121.1, 36.65], [119.15, 34.91], [120.23, 34.36], [121.91, 31.69], [121.89, 30.95], [121.26, 30.68], [122.09, 29.83], [121.68, 28.23], [121.13, 28.14], [118.66, 24.55], [115.89, 22.78], [110.79, 21.4], [110.44, 20.34], [109.89, 20.28], [109.86, 21.4], [107.04, 21.81], [106.73, 22.79], [105.33, 23.35], [101.65, 22.32], [101.8, 21.17], [101.27, 21.2], [101.15, 21.85], [100.42, 21.56], [99.24, 22.12], [99.53, 22.95], [98.9, 23.14], [98.66, 24.06], [97.6, 23.9], [97.72, 25.08], [98.67, 25.92], [98.68, 27.51], [97.91, 28.34], [96.25, 28.41], [96.59, 28.83], [96.12, 29.45], [94.57, 29.28], [92.5, 27.9], [90.02, 28.3], [88.81, 27.3], [88.73, 28.09], [85.82, 28.2], [79.72, 30.88], [78.74, 31.52], [78.46, 32.62], [79.18, 32.48], [78.91, 34.32], [77.84, 35.49], [76.19, 35.9], [74.98, 37.42], [74.86, 38.38], [73.93, 38.51], [73.68, 39.43], [74.78, 40.37], [76.53, 40.43], [76.9, 41.07], [80.12, 42.12], [80.18, 42.92], [80.87, 43.18], [79.97, 44.92], [82.46, 45.54], [83.18, 47.33], [85.16, 47], [85.77, 48.46], [87.75, 49.3], [88.01, 48.6], [90.28, 47.69], [90.97, 46.89], [90.59, 45.72], [90.95, 45.29], [95.31, 44.24], [96.35, 42.73], [100.85, 42.66], [104.96, 41.6], [110.41, 42.87], [111.83, 43.74], [111.35, 44.46], [111.87, 45.1], [113.46, 44.81], [117.42, 46.67], [119.66, 46.69], [118.06, 48.07], [115.74, 47.73], [115.49, 48.14], [116.68, 49.89], [117.88, 49.51], [119.29, 50.14], [120.74, 51.96], [120.18, 52.75], [121, 53.25], [123.57, 53.46], [125.95, 52.79], [127.66, 49.76]], [[-2.86, 4.99], [-4.65, 5.17], [-7.71, 4.36], [-7.57, 5.71], [-8.6, 6.47], [-7.83, 8.58], [-8.23, 10.13], [-6.21, 10.52], [-4.33, 9.61], [-2.83, 9.64], [-2.56, 8.22], [-3.24, 6.25], [-2.86, 4.99]], [[13.08, 2.27], [9.65, 2.28], [9.8, 3.07], [8.5, 4.77], [9.23, 6.44], [10.12, 7.04], [11.06, 6.64], [11.75, 6.98], [14.42, 11.57], [14.5, 12.86], [15.47, 9.98], [14.17, 10.02], [13.95, 9.55], [15.44, 7.69], [14.54, 6.23], [14.48, 4.73], [15.86, 3.01], [15.94, 1.73], [13.08, 2.27]], [[30.83, 3.51], [30.77, 2.34], [31.17, 2.2], [29.88, 0.6], [29.02, -2.84], [29.42, -5.94], [30.74, -8.34], [29, -8.41], [28.45, -9.16], [28.37, -11.79], [29.62, -12.18], [29.7, -13.26], [28.93, -13.25], [27.16, -11.61], [26.55, -11.92], [24.26, -10.95], [22.16, -11.08], [21.73, -7.29], [20.09, -6.94], [19.02, -7.99], [17.47, -8.07], [16.33, -5.88], [12.32, -6.1], [12.63, -4.99], [13.6, -4.5], [14.58, -4.97], [16.01, -3.54], [16.41, -1.74], [17.64, -0.42], [18.54, 4.2], [19.47, 5.03], [22.41, 4.03], [22.84, 4.71], [24.41, 5.11], [27.37, 5.23], [27.98, 4.41], [29.72, 4.6], [30.83, 3.51]], [[13, -4.78], [12.62, -4.44], [11.91, -5.04], [11.09, -3.98], [11.86, -3.43], [11.48, -2.77], [12.58, -1.95], [13.99, -2.47], [14.3, -2], [13.84, 0.04], [14.28, 1.2], [13.28, 1.31], [13.08, 2.27], [15.94, 1.73], [17.13, 3.73], [18.45, 3.5], [17.64, -0.42], [16.41, -1.74], [16.01, -3.54], [14.58, -4.97], [14.14, -4.51], [13, -4.78]], [[-75.37, -0.15], [-77.42, 0.4], [-78.99, 1.69], [-77.13, 3.85], [-77.75, 7.71], [-77.24, 7.94], [-77.35, 8.67], [-75.67, 9.44], [-74.91, 11.08], [-73.41, 11.23], [-71.4, 12.38], [-71.33, 11.78], [-72.91, 10.45], [-73.3, 9.15], [-72.79, 9.09], [-71.96, 6.99], [-70.09, 6.96], [-69.39, 6.1], [-67.34, 6.1], [-67.82, 4.5], [-67.3, 3.32], [-67.81, 2.82], [-66.88, 1.25], [-67.54, 2.04], [-69.82, 1.71], [-69.8, 1.09], [-69.22, 0.99], [-70.02, 0.54], [-69.42, -1.12], [-69.89, -4.3], [-70.69, -3.74], [-70.05, -2.73], [-70.81, -2.26], [-73.07, -2.31], [-73.66, -1.26], [-75.37, -0.15]], [[-82.97, 8.23], [-84.98, 10.09], [-85.11, 9.56], [-85.66, 9.93], [-85.94, 10.9], [-83.66, 10.94], [-82.55, 9.57], [-82.97, 8.23]], [[-82.27, 23.19], [-78.35, 22.51], [-74.18, 20.28], [-77.76, 19.86], [-77.09, 20.41], [-78.14, 20.74], [-78.72, 21.6], [-81.82, 22.19], [-82.17, 22.39], [-81.8, 22.64], [-84.97, 21.9], [-82.27, 23.19]], [[32.73, 35.14], [34.58, 35.67], [33.97, 35.06], [32.73, 35.14]], [[33.97, 35.06], [32.98, 34.57], [32.26, 35.1], [33.97, 35.06]], [[16.96, 48.6], [15.25, 49.04], [14.34, 48.56], [12.52, 49.55], [12.24, 50.27], [14.31, 51.12], [17.55, 50.36], [18.85, 49.5], [16.96, 48.6]], [[9.92, 54.98], [10.94, 54.01], [12.52, 54.47], [14.35, 53.25], [15.02, 51.11], [12.24, 50.27], [13.6, 48.88], [12.88, 48.29], [12.93, 47.47], [7.47, 47.62], [8.1, 49.02], [6.19, 49.46], [5.99, 51.85], [6.84, 52.23], [6.91, 53.48], [8.8, 54.02], [8.53, 54.96], [9.92, 54.98]], [[43.08, 12.7], [42.78, 10.93], [41.76, 11.05], [42.35, 12.54], [43.08, 12.7]], [[12.69, 55.61], [12.09, 54.8], [10.9, 55.78], [12.37, 56.11], [12.69, 55.61]], [[10.91, 56.46], [9.65, 55.47], [9.92, 54.98], [8.53, 54.96], [8.12, 55.52], [8.54, 57.11], [10.58, 57.73], [10.25, 56.89], [10.91, 56.46]], [[-71.71, 19.71], [-69.95, 19.65], [-68.32, 18.61], [-68.69, 18.21], [-70.67, 18.43], [-71.4, 17.6], [-71.95, 18.62], [-71.71, 19.71]], [[12, 23.47], [5.68, 19.6], [3.16, 19.06], [3.15, 19.69], [-8.68, 27.4], [-8.67, 28.84], [-5.24, 30], [-3.69, 30.9], [-3.65, 31.64], [-1.31, 32.26], [-2.17, 35.17], [-1.21, 35.71], [1.47, 36.61], [8.42, 36.95], [8.14, 34.66], [7.52, 34.1], [7.61, 33.34], [9.06, 32.1], [9.81, 29.42], [9.32, 26.09], [10.3, 24.38], [10.77, 24.56], [12, 23.47]], [[-80.3, -3.4], [-79.77, -2.66], [-80.97, -2.25], [-80.93, -1.06], [-80.09, 0.77], [-78.86, 1.38], [-75.37, -0.15], [-75.54, -1.56], [-77.84, -3], [-79.21, -4.96], [-80.44, -4.43], [-80.3, -3.4]], [[34.92, 29.5], [33.92, 27.65], [32.32, 29.76], [35.69, 23.93], [35.53, 23.1], [36.87, 22], [25, 22], [24.7, 30.04], [25.16, 31.57], [28.91, 30.87], [30.98, 31.56], [31.96, 30.93], [34.27, 31.22], [34.92, 29.5]], [[42.35, 12.54], [40.03, 14.52], [37.91, 14.96], [37.59, 14.21], [36.43, 14.42], [36.85, 16.96], [38.41, 18], [39.27, 15.92], [43.08, 12.7], [42.35, 12.54]], [[-9.03, 41.88], [-9.39, 43.03], [-7.98, 43.75], [-1.9, 43.42], [0.34, 42.58], [2.99, 42.47], [3.04, 41.89], [0.81, 41.01], [-0.68, 37.64], [-2.15, 36.67], [-4.37, 36.68], [-5.38, 35.95], [-7.54, 37.43], [-7.03, 38.08], [-7.5, 39.63], [-6.39, 41.38], [-6.67, 41.88], [-8.01, 41.79], [-8.26, 42.28], [-9.03, 41.88]], [[24.31, 57.79], [24.43, 58.38], [23.43, 58.61], [23.34, 59.19], [25.86, 59.61], [28.13, 59.3], [27.42, 58.72], [27.72, 57.79], [27.29, 57.47], [24.31, 57.79]], [[37.91, 14.96], [40.03, 14.52], [41.6, 13.45], [42.35, 12.54], [41.76, 11.05], [42.78, 10.93], [42.56, 10.57], [43.68, 9.18], [47.79, 8], [44.96, 5], [43.66, 4.96], [41.86, 3.92], [40.77, 4.26], [39.56, 3.42], [38.12, 3.6], [36.16, 4.45], [34.71, 6.59], [32.95, 7.78], [33.83, 8.38], [34.26, 10.63], [35.86, 12.58], [36.43, 14.42], [37.59, 14.21], [37.91, 14.96]], [[28.59, 69.06], [28.45, 68.36], [29.98, 67.7], [29.05, 66.94], [30.22, 65.81], [29.54, 64.95], [30.44, 64.2], [30.04, 63.55], [31.52, 62.87], [31.14, 62.36], [28.07, 60.5], [22.87, 59.85], [21.32, 60.72], [21.54, 61.71], [21.06, 62.61], [21.54, 63.19], [25.4, 65.11], [23.57, 66.4], [23.54, 67.94], [20.65, 69.11], [24.74, 68.65], [26.18, 69.83], [27.73, 70.16], [29.02, 69.77], [28.59, 69.06]], [[178.37, -17.34], [178.55, -18.15], [177.38, -18.16], [177.67, -17.38], [178.37, -17.34]], [[179.36, -16.8], [178.6, -16.64], [180, -16.07], [179.36, -16.8]], [[-61.2, -51.85], [-58.55, -51.1], [-57.75, -51.55], [-59.4, -52.2], [-61.2, -51.85]], [[-52.56, 2.5], [-53.42, 2.05], [-54.52, 2.31], [-54.01, 3.62], [-54.48, 4.9], [-53.96, 5.76], [-51.82, 4.57], [-52.56, 2.5]], [[9.56, 42.15], [9.23, 41.38], [8.54, 42.26], [9.39, 43.01], [9.56, 42.15]], [[3.59, 50.38], [8.1, 49.02], [7.47, 47.62], [6.04, 46.73], [6.84, 45.99], [7.44, 43.69], [6.53, 43.13], [3.1, 43.08], [2.99, 42.47], [1.83, 42.34], [-1.5, 43.03], [-1.9, 43.42], [-1.19, 46.01], [-2.96, 47.57], [-4.49, 47.95], [-4.59, 48.68], [-1.62, 48.64], [-1.93, 49.78], [-0.99, 49.35], [1.34, 50.13], [1.64, 50.95], [2.51, 51.15], [3.59, 50.38]], [[11.09, -3.98], [8.83, -0.78], [9.49, 1.01], [11.29, 1.06], [11.28, 2.26], [12.95, 2.32], [13.28, 1.31], [14.28, 1.2], [13.84, 0.04], [14.3, -2], [13.99, -2.47], [12.58, -1.95], [11.48, -2.77], [11.86, -3.43], [11.09, -3.98]], [[-5.66, 54.55], [-6.2, 53.87], [-7.57, 54.06], [-7.57, 55.13], [-5.66, 54.55]], [[-3.01, 58.64], [-4.07, 57.55], [-1.96, 57.68], [-3.12, 55.97], [-2.09, 55.91], [0.47, 52.93], [1.68, 52.74], [1.05, 51.81], [1.45, 51.29], [-5.25, 49.96], [-5.78, 50.16], [-3.41, 51.43], [-5.27, 51.99], [-4.22, 52.3], [-4.77, 52.84], [-4.58, 53.5], [-3.09, 53.4], [-2.95, 53.99], [-4.84, 54.79], [-5.05, 55.78], [-5.59, 55.31], [-6.15, 56.79], [-5.01, 58.63], [-3.01, 58.64]], [[41.55, 41.54], [41.45, 42.65], [40.08, 43.55], [45.47, 42.5], [46.64, 41.18], [41.55, 41.54]], [[1.06, 5.93], [-1.96, 4.71], [-2.86, 4.99], [-3.24, 6.25], [-2.56, 8.22], [-2.94, 10.96], [0.02, 11.02], [1.06, 5.93]], [[-8.44, 7.69], [-9.21, 7.31], [-9.76, 8.54], [-10.51, 8.35], [-11.12, 10.05], [-12.43, 9.84], [-13.25, 8.9], [-15.13, 11.04], [-13.74, 11.81], [-13.7, 12.59], [-10.17, 11.84], [-9.13, 12.31], [-8.03, 10.21], [-7.83, 8.58], [-8.44, 7.69]], [[-16.84, 13.15], [-15.4, 13.86], [-13.84, 13.51], [-16.84, 13.15]], [[-15.13, 11.04], [-16.68, 12.38], [-13.7, 12.59], [-13.74, 11.81], [-15.13, 11.04]], [[9.49, 1.01], [9.65, 2.28], [11.28, 2.26], [11.29, 1.06], [9.49, 1.01]], [[23.7, 35.71], [26.29, 35.3], [24.72, 34.92], [23.51, 35.28], [23.7, 35.71]], [[26.6, 41.56], [26.06, 40.82], [23.71, 40.69], [24.41, 40.12], [23.9, 39.96], [22.81, 40.48], [23.35, 39.19], [22.97, 38.97], [24.04, 37.66], [23.12, 37.92], [23.41, 37.41], [22.77, 37.31], [23.15, 36.42], [21.67, 36.84], [20.15, 39.62], [21.02, 40.84], [26.6, 41.56]], [[-46.76, 82.63], [-38.62, 83.55], [-27.1, 83.52], [-20.85, 82.73], [-31.4, 82.02], [-22.9, 82.09], [-22.07, 81.73], [-23.17, 81.15], [-15.77, 81.91], [-12.21, 81.29], [-20.05, 80.18], [-17.73, 80.13], [-19.7, 78.75], [-19.67, 77.64], [-18.47, 76.99], [-21.68, 76.63], [-19.83, 76.1], [-19.6, 75.25], [-20.67, 75.16], [-19.37, 74.3], [-21.59, 74.22], [-20.43, 73.82], [-20.76, 73.46], [-23.57, 73.31], [-22.3, 72.18], [-24.79, 72.33], [-22.13, 71.47], [-21.75, 70.66], [-23.54, 70.47], [-25.54, 71.43], [-25.2, 70.75], [-26.36, 70.23], [-22.35, 70.13], [-27.75, 68.47], [-31.78, 68.12], [-34.2, 66.68], [-39.81, 65.46], [-41.19, 63.48], [-42.82, 62.68], [-42.42, 61.9], [-43.38, 60.1], [-44.79, 60.04], [-46.26, 60.85], [-48.26, 60.86], [-51.63, 63.63], [-52.28, 65.18], [-53.66, 66.1], [-53.3, 66.84], [-53.97, 67.19], [-52.98, 68.36], [-51.48, 68.73], [-50.87, 69.93], [-53.46, 69.28], [-54.68, 69.61], [-54.36, 70.82], [-51.39, 70.57], [-55.83, 71.65], [-54.72, 72.59], [-58.59, 75.52], [-61.27, 76.1], [-68.5, 76.06], [-71.4, 77.01], [-66.76, 77.38], [-73.3, 78.04], [-73.16, 78.43], [-65.71, 79.39], [-65.32, 79.76], [-68.02, 80.12], [-62.23, 81.32], [-62.65, 81.77], [-57.21, 82.19], [-53.04, 81.89], [-50.39, 82.44], [-44.52, 81.66], [-46.9, 82.2], [-46.76, 82.63]], [[-90.1, 13.74], [-91.69, 14.13], [-92.23, 15.25], [-91.75, 16.07], [-90.46, 16.07], [-91.45, 17.25], [-91, 17.25], [-91, 17.82], [-89.14, 17.81], [-89.23, 15.89], [-88.23, 15.73], [-90.1, 13.74]], [[-59.76, 8.37], [-57.15, 5.97], [-58.04, 4.06], [-56.54, 1.9], [-58.54, 1.27], [-59.65, 1.79], [-59.98, 5.01], [-61.41, 5.96], [-59.76, 8.37]], [[-87.32, 12.98], [-87.86, 13.89], [-89.35, 14.42], [-88.23, 15.73], [-84.98, 16], [-83.15, 15], [-84.92, 14.79], [-87.32, 12.98]], [[18.83, 45.91], [19.39, 45.24], [19.01, 44.86], [15.96, 45.23], [15.75, 44.82], [18.45, 42.48], [16.02, 43.51], [14.9, 45.08], [13.66, 45.14], [15.33, 45.45], [16.56, 46.5], [18.83, 45.91]], [[-73.19, 19.92], [-71.71, 19.71], [-71.71, 18.04], [-74.46, 18.34], [-72.33, 18.67], [-73.19, 19.92]], [[16.2, 46.85], [16.98, 48.12], [17.86, 47.76], [20.8, 48.62], [22.71, 47.88], [21.02, 46.32], [18.46, 45.76], [16.2, 46.85]], [[120.72, -10.24], [118.97, -9.56], [119.9, -9.36], [120.72, -10.24]], [[124.44, -10.14], [123.58, -10.36], [123.55, -9.9], [124.97, -8.89], [124.44, -10.14]], [[117.9, -8.1], [119.13, -8.71], [116.74, -9.03], [117.9, -8.1]], [[122.9, -8.09], [122.76, -8.65], [119.92, -8.81], [120.72, -8.24], [122.9, -8.09]], [[108.62, -6.78], [110.54, -6.88], [110.76, -6.47], [115.71, -8.37], [114.56, -8.75], [108.28, -7.77], [105.37, -6.85], [106.05, -5.9], [108.62, -6.78]], [[134.72, -6.21], [134.21, -6.9], [134.5, -5.45], [134.72, -6.21]], [[127.25, -3.46], [126.87, -3.79], [125.99, -3.18], [127.25, -3.46]], [[130.47, -3.09], [130.83, -3.86], [127.9, -3.39], [128.14, -2.84], [130.47, -3.09]], [[134.14, -1.15], [134.42, -2.77], [135.46, -3.37], [137.44, -1.7], [141, -2.6], [141.03, -9.12], [140.14, -8.3], [137.61, -8.41], [138.67, -7.32], [137.93, -5.39], [133.66, -3.54], [132.98, -4.11], [131.99, -2.82], [133.7, -2.21], [132.23, -2.21], [130.52, -0.94], [132.38, -0.37], [134.14, -1.15]], [[125.24, 1.42], [123.69, 0.24], [120.18, 0.24], [120.04, -0.52], [120.94, -1.41], [123.34, -0.62], [121.51, -1.9], [123.16, -5.34], [122.24, -5.28], [122.72, -4.46], [121.49, -4.57], [120.97, -2.63], [120.31, -2.93], [120.43, -5.53], [119.37, -5.38], [119.5, -3.49], [118.77, -2.8], [120.04, 0.57], [120.89, 1.31], [122.93, 0.88], [125.24, 1.42]], [[128.69, 1.13], [128.1, -0.9], [127.6, 1.81], [127.93, 2.17], [128.69, 1.13]], [[117.88, 1.83], [119, 0.9], [117.81, 0.78], [117.52, -0.8], [116.56, -1.49], [116.15, -4.01], [116, -3.66], [114.86, -4.11], [113.26, -3.12], [112.07, -3.48], [111.7, -2.99], [110.22, -2.93], [110.07, -1.59], [109.09, -0.46], [109.07, 1.34], [109.66, 2.01], [110.51, 0.77], [114.62, 1.43], [115.87, 4.31], [117.88, 4.14], [117.31, 3.23], [117.88, 1.83]], [[105.82, -5.85], [104.71, -5.87], [102.58, -4.22], [98.6, 1.82], [95.29, 5.48], [97.48, 5.25], [100.64, 2.1], [101.66, 2.08], [103.84, 0.1], [103.44, -0.71], [106.11, -3.06], [105.82, -5.85]], [[77.84, 35.49], [78.91, 34.32], [79.21, 32.99], [79.18, 32.48], [78.46, 32.62], [78.74, 31.52], [81.11, 30.18], [80.09, 28.79], [83.3, 27.36], [88.06, 26.41], [88.12, 27.88], [88.73, 28.09], [88.84, 27.1], [89.74, 26.72], [92.03, 26.84], [91.7, 27.77], [94.57, 29.28], [96.12, 29.45], [96.59, 28.83], [96.25, 28.41], [97.4, 27.88], [97.13, 27.08], [96.42, 27.26], [95.12, 26.57], [94.11, 23.85], [93.33, 24.08], [93.17, 22.28], [92.67, 22.04], [92.15, 23.63], [91.71, 22.99], [91.16, 23.5], [92.38, 24.98], [89.92, 25.27], [89.83, 25.97], [88.56, 26.45], [88.21, 25.77], [88.93, 25.24], [88.08, 24.5], [88.7, 24.23], [88.89, 21.69], [86.98, 21.5], [86.5, 20.15], [85.06, 19.48], [82.19, 16.56], [80.32, 15.9], [79.86, 10.36], [77.54, 7.97], [76.59, 8.9], [73.53, 15.99], [72.63, 21.36], [70.47, 20.88], [69.16, 22.09], [69.64, 22.45], [69.35, 22.84], [68.18, 23.69], [68.84, 24.36], [71.04, 24.36], [69.51, 26.94], [70.62, 27.99], [71.78, 27.91], [75.26, 32.27], [74.45, 32.76], [73.75, 34.32], [74.24, 34.75], [76.87, 34.65], [77.84, 35.49]], [[-6.2, 53.87], [-6.03, 53.15], [-6.79, 52.26], [-9.98, 51.82], [-9.17, 52.86], [-9.69, 53.88], [-7.57, 55.13], [-7.57, 54.06], [-6.2, 53.87]], [[53.92, 37.2], [56.62, 38.12], [61.12, 36.49], [60.54, 32.98], [61.78, 30.74], [60.87, 29.83], [62.73, 28.26], [63.32, 26.76], [61.87, 26.24], [61.5, 25.08], [57.4, 25.74], [56.49, 27.14], [54.72, 26.48], [51.52, 27.87], [50.12, 30.15], [48.57, 29.93], [48.01, 30.45], [47.33, 32.47], [45.42, 33.97], [46.15, 35.09], [44.23, 37.97], [44.11, 39.43], [44.79, 39.71], [46.14, 38.74], [48.06, 39.58], [48.01, 38.79], [49.2, 37.58], [50.84, 36.87], [53.92, 37.2]], [[45.42, 35.98], [46.15, 35.09], [45.42, 33.97], [47.33, 32.47], [48.57, 29.93], [47.3, 30.06], [46.57, 29.1], [44.71, 29.18], [41.89, 31.19], [39.2, 32.16], [38.79, 33.38], [41.01, 34.42], [41.29, 36.36], [42.35, 37.23], [44.77, 37.17], [45.42, 35.98]], [[-14.51, 66.46], [-14.74, 65.81], [-13.61, 65.13], [-18.66, 63.5], [-22.76, 63.96], [-21.78, 64.4], [-23.96, 64.89], [-22.23, 65.38], [-24.33, 65.61], [-23.65, 66.26], [-22.13, 66.41], [-20.58, 65.73], [-19.06, 66.28], [-14.51, 66.46]], [[35.72, 32.71], [34.97, 31.87], [35.42, 31.1], [34.92, 29.5], [34.27, 31.22], [35.1, 33.08], [35.82, 33.28], [35.72, 32.71]], [[15.52, 38.23], [15.1, 36.62], [12.43, 37.61], [12.57, 38.13], [15.52, 38.23]], [[9.21, 41.21], [9.81, 40.5], [9.67, 39.18], [8.81, 38.91], [8.16, 40.95], [9.21, 41.21]], [[12.38, 46.77], [13.81, 46.51], [13.94, 45.59], [12.33, 45.38], [12.59, 44.09], [15.14, 41.96], [15.93, 41.96], [15.89, 41.54], [18.48, 40.17], [18.29, 39.81], [16.87, 40.44], [16.45, 39.8], [17.17, 39.42], [17.05, 38.9], [16.1, 37.99], [15.68, 37.91], [16.11, 38.96], [15.41, 40.05], [11.19, 42.36], [10.2, 43.92], [8.89, 44.37], [7.44, 43.69], [7.55, 44.13], [7.01, 44.25], [6.84, 45.99], [8.97, 46.04], [10.44, 46.89], [12.38, 46.77]], [[-77.57, 18.49], [-76.2, 17.89], [-77.77, 17.86], [-78.34, 18.23], [-77.57, 18.49]], [[35.55, 32.39], [36.83, 32.31], [38.79, 33.38], [39.2, 32.16], [37, 31.51], [38, 30.51], [36.07, 29.2], [34.92, 29.5], [35.55, 32.39]], [[134.64, 34.15], [134.2, 33.2], [133.79, 33.52], [133.01, 32.7], [132.36, 32.99], [132.92, 34.06], [134.64, 34.15]], [[140.98, 37.14], [140.25, 35.14], [137.22, 34.61], [135.79, 33.46], [135.12, 33.85], [135.08, 34.6], [130.99, 33.89], [132, 33.15], [131.33, 31.45], [130.69, 31.03], [130.2, 31.42], [130.45, 32.32], [129.41, 33.3], [132.62, 35.43], [135.68, 35.53], [136.72, 37.3], [137.39, 36.83], [139.43, 38.22], [140.31, 41.2], [141.37, 41.38], [141.91, 39.99], [140.98, 37.14]], [[143.91, 44.17], [145.32, 44.38], [145.54, 43.26], [144.06, 42.99], [143.18, 42], [141.61, 42.68], [141.07, 41.58], [139.96, 41.57], [139.82, 42.56], [140.31, 43.33], [141.38, 43.39], [141.97, 45.55], [143.91, 44.17]], [[70.96, 42.27], [68.26, 40.66], [67.99, 41.14], [66.71, 41.17], [66.51, 41.99], [66.02, 41.99], [66.1, 43], [64.9, 43.73], [62.01, 43.5], [58.5, 45.59], [55.93, 45], [55.97, 41.31], [54.08, 42.32], [52.5, 41.78], [52.5, 42.79], [51.34, 43.13], [50.31, 44.61], [51.28, 44.51], [51.32, 45.25], [53.04, 45.26], [53.04, 46.85], [51.19, 47.05], [49.1, 46.4], [48.06, 47.74], [46.47, 48.39], [47.55, 50.45], [48.58, 49.87], [48.7, 50.61], [50.77, 51.69], [52.33, 51.72], [55.72, 50.62], [56.78, 51.04], [61.34, 50.8], [61.59, 51.27], [59.97, 51.96], [61.7, 52.98], [60.98, 53.66], [61.44, 54.01], [69.07, 55.39], [70.87, 55.17], [71.18, 54.13], [73.51, 54.04], [73.43, 53.49], [76.89, 54.49], [76.53, 54.18], [80.04, 50.86], [80.57, 51.39], [81.95, 50.81], [83.38, 51.07], [87.36, 49.21], [85.77, 48.46], [85.16, 47], [83.18, 47.33], [82.46, 45.54], [79.97, 44.92], [80.87, 43.18], [80.18, 42.92], [80.26, 42.35], [74.21, 43.3], [73.49, 42.5], [71.84, 42.85], [70.96, 42.27]], [[40.99, -0.86], [41.59, -1.68], [40.26, -2.57], [39.2, -4.68], [37.77, -3.68], [37.7, -3.1], [33.9, -0.95], [33.89, 0.11], [35.04, 1.91], [34.01, 4.25], [35.3, 5.51], [36.16, 4.45], [38.12, 3.6], [39.56, 3.42], [40.77, 4.26], [41.86, 3.92], [40.98, 2.78], [40.99, -0.86]], [[70.96, 42.27], [71.84, 42.85], [73.49, 42.5], [74.21, 43.3], [80.26, 42.35], [76.9, 41.07], [76.53, 40.43], [75.47, 40.56], [73.68, 39.43], [71.78, 39.28], [69.46, 39.53], [69.56, 40.1], [71.77, 40.15], [73.06, 40.87], [70.42, 41.52], [70.96, 42.27]], [[103.5, 10.63], [102.35, 13.39], [102.99, 14.23], [106.04, 13.88], [106.5, 14.57], [107.38, 14.2], [107.49, 12.34], [105.81, 11.57], [106.25, 10.96], [103.5, 10.63]], [[128.35, 38.61], [129.46, 36.78], [129.47, 35.63], [129.09, 35.08], [126.49, 34.39], [126.12, 36.73], [126.86, 36.89], [126.17, 37.75], [128.35, 38.61]], [[20.76, 42.05], [20.07, 42.59], [20.81, 43.27], [21.78, 42.68], [20.76, 42.05]], [[47.97, 29.98], [48.42, 28.55], [46.57, 29.1], [47.3, 30.06], [47.97, 29.98]], [[105.22, 14.27], [105.59, 15.57], [103.96, 18.24], [101.06, 17.51], [101.28, 19.46], [100.61, 19.51], [100.12, 20.42], [101.18, 21.44], [101.8, 21.17], [101.65, 22.32], [102.17, 22.46], [103.2, 20.77], [104.44, 20.76], [104.82, 19.89], [103.9, 19.27], [105.09, 18.67], [107.31, 15.91], [107.38, 14.2], [106.5, 14.57], [106.04, 13.88], [105.22, 14.27]], [[35.82, 33.28], [35.13, 33.09], [35.48, 33.91], [36.45, 34.59], [35.82, 33.28]], [[-7.71, 4.36], [-11.44, 6.79], [-10.23, 8.41], [-9.76, 8.54], [-9.21, 7.31], [-8.44, 7.69], [-8.6, 6.47], [-7.57, 5.71], [-7.71, 4.36]], [[14.85, 22.86], [14.14, 22.49], [10.77, 24.56], [10.3, 24.38], [9.32, 26.09], [9.86, 28.96], [9.48, 30.31], [9.97, 30.54], [9.95, 31.38], [11.43, 32.37], [11.49, 33.14], [15.25, 32.27], [15.71, 31.38], [19.09, 30.27], [20.05, 30.99], [19.82, 31.75], [20.85, 32.71], [24.92, 31.9], [25, 20], [23.85, 20], [23.84, 19.58], [15.86, 23.41], [14.85, 22.86]], [[81.79, 7.52], [81.64, 6.48], [80.35, 5.97], [79.7, 8.2], [80.15, 9.82], [81.79, 7.52]], [[28.98, -28.96], [29.33, -29.26], [28.11, -30.55], [27, -29.88], [28.07, -28.85], [28.98, -28.96]], [[22.73, 54.33], [22.76, 54.86], [21.27, 55.19], [21.06, 56.03], [24.86, 56.37], [26.49, 55.62], [25.54, 54.28], [24.45, 53.91], [22.73, 54.33]], [[21.06, 56.03], [21.58, 57.41], [22.52, 57.75], [23.32, 57.01], [24.12, 57.03], [24.31, 57.79], [25.16, 57.97], [27.77, 57.24], [28.18, 56.17], [26.49, 55.62], [24.86, 56.37], [21.06, 56.03]], [[-5.19, 35.76], [-2.17, 35.17], [-1.31, 32.26], [-3.65, 31.64], [-3.69, 30.9], [-5.24, 30], [-8.67, 28.84], [-8.79, 27.12], [-11.39, 26.88], [-12.5, 24.77], [-13.89, 23.69], [-14.75, 21.5], [-17.02, 21.42], [-14.44, 26.25], [-9.56, 29.93], [-9.81, 31.18], [-9.3, 32.56], [-6.91, 34.11], [-5.93, 35.76], [-5.19, 35.76]], [[26.62, 48.22], [28.67, 48.12], [30.02, 46.42], [28.86, 46.44], [28.23, 45.49], [28.13, 46.81], [26.62, 48.22]], [[49.54, -12.47], [50.38, -15.71], [49.67, -15.71], [49.77, -16.88], [47.1, -24.94], [45.41, -25.6], [44.04, -24.99], [43.35, -22.78], [43.43, -21.34], [44.46, -19.44], [43.96, -17.41], [44.45, -16.22], [46.31, -15.78], [47.71, -14.59], [49.19, -12.04], [49.54, -12.47]], [[-97.14, 25.87], [-97.87, 22.44], [-95.9, 18.83], [-94.43, 18.14], [-91.41, 18.88], [-90.77, 19.28], [-90.28, 21], [-89.6, 21.26], [-87.05, 21.54], [-86.85, 20.85], [-87.84, 18.26], [-91, 17.82], [-91, 17.25], [-91.45, 17.25], [-90.46, 16.07], [-91.75, 16.07], [-92.23, 14.54], [-94.69, 16.2], [-96.56, 15.65], [-98.01, 16.11], [-104.99, 19.32], [-105.73, 20.43], [-105.27, 21.42], [-106.03, 22.77], [-112.23, 28.95], [-113.15, 31.17], [-114.78, 31.8], [-114.67, 30.16], [-111.62, 26.66], [-110.66, 24.3], [-109.41, 23.36], [-110.03, 22.82], [-112.18, 24.74], [-112.3, 26.01], [-115.06, 27.72], [-114.16, 28.57], [-115.52, 29.56], [-117.13, 32.54], [-114.72, 32.72], [-111.02, 31.33], [-106.51, 31.75], [-103.94, 29.27], [-103.11, 28.97], [-102.48, 29.76], [-100.96, 29.38], [-99.02, 26.37], [-97.14, 25.87]], [[20.59, 41.86], [22.38, 42.32], [22.95, 41.34], [21.02, 40.84], [20.59, 41.86]], [[-12.17, 14.62], [-11.67, 15.39], [-5.54, 15.5], [-6.45, 24.96], [-4.92, 24.97], [3.15, 19.69], [3.16, 19.06], [4.27, 19.16], [4.27, 16.85], [3.64, 15.57], [-1.07, 14.97], [-4.01, 13.47], [-5.22, 11.71], [-5.4, 10.37], [-6.05, 10.1], [-6.21, 10.52], [-8.03, 10.21], [-9.13, 12.31], [-10.17, 11.84], [-11.46, 12.08], [-12.17, 14.62]], [[99.54, 20.19], [98.25, 19.71], [97.38, 18.45], [98.9, 16.18], [98.19, 15.12], [99.59, 11.89], [98.55, 9.93], [98.51, 13.12], [97.16, 16.93], [95.37, 15.71], [94.19, 16.04], [94.32, 18.21], [93.66, 19.73], [92.37, 20.67], [92.3, 21.48], [93.17, 22.28], [93.33, 24.08], [94.11, 23.85], [95.12, 26.57], [96.42, 27.26], [97.13, 27.08], [97.33, 28.26], [97.91, 28.34], [98.68, 27.51], [98.67, 25.92], [97.72, 25.08], [97.6, 23.9], [98.66, 24.06], [98.9, 23.14], [99.53, 22.95], [99.24, 22.12], [100.42, 21.56], [101.15, 21.85], [99.54, 20.19]], [[19.8, 42.5], [19.37, 41.88], [18.45, 42.48], [19.22, 43.52], [20.34, 42.9], [19.8, 42.5]], [[87.75, 49.3], [92.23, 50.8], [97.26, 49.73], [98.23, 50.42], [97.83, 51.01], [98.86, 52.05], [102.07, 51.26], [102.26, 50.51], [103.68, 50.09], [106.89, 50.27], [108.48, 49.28], [110.66, 49.13], [114.36, 50.25], [116.68, 49.89], [115.49, 48.14], [115.74, 47.73], [118.06, 48.07], [119.77, 47.05], [117.42, 46.67], [113.46, 44.81], [111.87, 45.1], [111.35, 44.46], [111.83, 43.74], [110.41, 42.87], [104.96, 41.6], [100.85, 42.66], [96.35, 42.73], [95.31, 44.24], [90.95, 45.29], [90.59, 45.72], [90.97, 46.89], [90.28, 47.69], [88.01, 48.6], [87.75, 49.3]], [[34.56, -11.52], [37.47, -11.57], [40.32, -10.32], [40.78, -14.69], [39.45, -16.72], [37.41, -17.59], [34.79, -19.78], [35.56, -22.09], [35.46, -24.12], [33.01, -25.36], [32.57, -25.73], [32.83, -26.74], [32.07, -26.73], [31.19, -22.25], [32.66, -20.3], [32.85, -16.71], [30.34, -15.88], [30.18, -14.8], [33.21, -13.97], [34.46, -14.61], [34.38, -16.18], [35.03, -16.8], [35.77, -15.9], [35.69, -14.61], [34.56, -13.58], [34.56, -11.52]], [[-12.17, 14.62], [-14.58, 16.6], [-16.46, 16.14], [-16.28, 20.09], [-17.06, 21], [-12.93, 21.33], [-12.87, 23.28], [-11.94, 23.37], [-11.97, 25.93], [-8.69, 25.88], [-8.68, 27.4], [-4.92, 24.97], [-6.45, 24.96], [-5.32, 16.2], [-5.54, 15.5], [-11.67, 15.39], [-12.17, 14.62]], [[34.56, -11.52], [34.56, -13.58], [35.69, -14.61], [35.77, -15.9], [35.03, -16.8], [34.38, -16.18], [34.46, -14.61], [32.69, -13.71], [33.49, -10.53], [32.76, -9.23], [33.74, -9.42], [34.56, -11.52]], [[101.08, 6.2], [101.15, 5.69], [102.14, 6.22], [102.96, 5.52], [104.23, 1.29], [103.52, 1.23], [101.39, 2.76], [100.09, 6.46], [101.08, 6.2]], [[118.62, 4.48], [115.87, 4.31], [114.62, 1.43], [110.51, 0.77], [109.83, 1.34], [109.66, 2.01], [111.17, 1.85], [111.37, 2.7], [113, 3.1], [114.2, 4.53], [114.66, 4.01], [115.35, 4.32], [115.45, 5.45], [116.73, 6.92], [119.18, 5.41], [118.44, 4.97], [118.62, 4.48]], [[16.34, -28.58], [15.21, -27.09], [14.26, -22.11], [11.73, -17.3], [13.46, -16.97], [14.06, -17.42], [18.26, -17.31], [21.38, -17.93], [24.03, -17.3], [25.08, -17.58], [23.58, -18.28], [23.2, -17.87], [20.91, -18.25], [20.88, -21.81], [19.9, -21.85], [19.89, -28.46], [18.46, -29.05], [16.82, -28.08], [16.34, -28.58]], [[165.78, -21.08], [167.12, -22.16], [166.19, -22.13], [164.03, -20.11], [165.78, -21.08]], [[2.15, 11.94], [2.18, 12.63], [1.02, 12.85], [0.37, 14.93], [3.64, 15.57], [4.27, 16.85], [4.27, 19.16], [12, 23.47], [14.14, 22.49], [14.85, 22.86], [15.1, 21.31], [15.9, 20.39], [15.25, 16.63], [13.97, 15.68], [13.54, 14.37], [13.95, 13.35], [14.6, 13.33], [14.18, 12.48], [13.08, 13.6], [12.3, 13.04], [10.99, 13.39], [9.01, 12.83], [5.44, 13.87], [4.11, 13.53], [3.61, 11.66], [2.85, 12.24], [2.15, 11.94]], [[8.5, 4.77], [5.9, 4.26], [4.33, 6.27], [2.69, 6.26], [2.72, 8.51], [3.71, 10.06], [4.11, 13.53], [5.44, 13.87], [9.01, 12.83], [13.32, 13.56], [14.58, 12.09], [14.42, 11.57], [11.75, 6.98], [11.06, 6.64], [10.12, 7.04], [9.23, 6.44], [8.5, 4.77]], [[-85.71, 11.09], [-87.67, 12.91], [-84.92, 14.79], [-83.15, 15], [-83.66, 10.94], [-85.71, 11.09]], [[6.07, 53.51], [7.09, 53.14], [6.59, 51.85], [5.99, 51.85], [6.16, 50.8], [4.97, 51.48], [3.31, 51.35], [4.71, 53.09], [6.07, 53.51]], [[28.17, 71.19], [31.29, 70.45], [30.01, 70.19], [31.1, 69.56], [28.59, 69.06], [29.02, 69.77], [27.73, 70.16], [26.18, 69.83], [24.74, 68.65], [21.24, 69.37], [20.03, 69.07], [19.88, 68.41], [17.99, 68.57], [17.73, 68.01], [16.77, 68.01], [13.56, 64.79], [13.92, 64.45], [13.57, 64.05], [12.58, 64.07], [11.93, 63.13], [11.99, 61.8], [12.63, 61.29], [12.3, 60.12], [11.03, 58.86], [10.36, 59.47], [8.38, 58.31], [7.05, 58.08], [5.67, 58.59], [4.99, 61.97], [10.53, 64.49], [14.76, 67.81], [19.18, 69.82], [23.02, 70.2], [24.55, 71.03], [28.17, 71.19]], [[24.72, 77.85], [20.73, 77.68], [21.42, 77.94], [20.81, 78.25], [22.88, 78.45], [24.72, 77.85]], [[18.25, 79.7], [21.54, 78.96], [19.03, 78.56], [17.12, 76.81], [15.91, 76.77], [13.76, 77.38], [14.67, 77.74], [11.22, 78.87], [10.44, 79.65], [16.99, 80.05], [18.25, 79.7]], [[25.45, 80.41], [27.41, 80.06], [23.02, 79.4], [17.37, 80.32], [25.45, 80.41]], [[88.12, 27.88], [88.06, 26.41], [87.23, 26.4], [80.09, 28.79], [81.53, 30.42], [85.82, 28.2], [88.12, 27.88]], [[173.02, -40.92], [174.25, -41.35], [172.71, -43.37], [173.08, -43.85], [171.45, -44.24], [170.62, -45.91], [169.33, -46.64], [166.68, -46.22], [167.05, -45.11], [170.52, -43.03], [172.1, -40.96], [172.8, -40.49], [173.02, -40.92]], [[174.61, -36.16], [175.34, -37.21], [175.36, -36.53], [176.76, -37.88], [178.52, -37.7], [177.97, -39.17], [177.21, -39.15], [176.01, -41.29], [175.24, -41.69], [174.65, -41.28], [175.23, -40.46], [174.9, -39.91], [173.82, -39.51], [174.57, -38.8], [174.7, -37.38], [172.64, -34.53], [174.33, -35.27], [174.61, -36.16]], [[58.86, 21.11], [57.83, 20.24], [57.69, 18.94], [54.79, 16.95], [53.11, 16.65], [52, 19], [55, 20], [55.89, 24.92], [59.81, 22.53], [58.86, 21.11]], [[75.16, 37.13], [76.19, 35.9], [77.84, 35.49], [76.87, 34.65], [74.24, 34.75], [73.75, 34.32], [74.45, 32.76], [75.26, 32.27], [71.78, 27.91], [70.62, 27.99], [69.51, 26.94], [71.04, 24.36], [68.84, 24.36], [68.18, 23.69], [66.37, 25.43], [61.5, 25.08], [61.87, 26.24], [63.32, 26.76], [62.73, 28.26], [60.87, 29.83], [62.55, 29.32], [66.35, 29.89], [66.94, 31.3], [69.32, 31.9], [69.26, 32.5], [70.32, 33.36], [69.93, 34.02], [70.88, 33.99], [71.61, 35.15], [71.26, 36.07], [75.16, 37.13]], [[-77.88, 7.22], [-78.18, 8.32], [-79.12, 9], [-80.38, 8.3], [-80, 7.55], [-80.42, 7.27], [-81.72, 8.11], [-82.85, 8.07], [-82.93, 9.48], [-81.44, 8.79], [-79.57, 9.61], [-78.06, 9.25], [-77.24, 7.94], [-77.88, 7.22]], [[-69.59, -17.58], [-70.37, -18.35], [-76.01, -14.65], [-79.76, -7.19], [-81.25, -6.14], [-81.1, -4.04], [-80.3, -3.4], [-80.44, -4.43], [-79.21, -4.96], [-77.84, -3], [-75.54, -1.56], [-75.11, -0.06], [-73.07, -2.31], [-70.81, -2.26], [-70.05, -2.73], [-70.69, -3.74], [-69.89, -4.3], [-72.89, -5.27], [-73.12, -6.63], [-73.99, -7.52], [-73.02, -9.03], [-73.23, -9.46], [-72.18, -10.05], [-70.48, -9.49], [-70.55, -11.01], [-69.53, -10.95], [-68.67, -12.56], [-69.34, -14.95], [-68.96, -16.5], [-69.59, -17.58]], [[126.38, 8.41], [126.54, 7.19], [126.2, 6.27], [125.83, 7.29], [125.36, 6.79], [125.4, 5.58], [124.22, 6.16], [124.24, 7.36], [123.61, 7.83], [121.92, 7.19], [123.49, 8.69], [123.84, 8.24], [125.47, 8.99], [125.41, 9.76], [126.22, 9.29], [126.38, 8.41]], [[123.98, 10.28], [123, 9.02], [122.38, 9.71], [122.95, 10.88], [123.5, 10.94], [123.34, 10.27], [124.08, 11.23], [123.98, 10.28]], [[118.5, 9.32], [117.17, 8.37], [119.51, 11.37], [119.69, 10.55], [118.5, 9.32]], [[121.88, 11.89], [123.12, 11.58], [122, 10.44], [121.88, 11.89]], [[125.5, 12.16], [125.78, 11.05], [125.01, 11.31], [125.28, 10.36], [124.8, 10.13], [124.3, 11.5], [124.88, 11.79], [124.27, 12.56], [125.5, 12.16]], [[121.53, 13.07], [121.26, 12.21], [120.32, 13.47], [121.53, 13.07]], [[121.32, 18.5], [122.25, 18.48], [122.52, 17.09], [121.66, 15.93], [121.73, 14.33], [123.95, 13.78], [124.08, 12.54], [122.93, 13.55], [122.67, 13.19], [122.03, 13.78], [120.63, 13.86], [120.99, 14.53], [120.07, 14.97], [119.88, 16.36], [120.29, 16.03], [120.72, 18.51], [121.32, 18.5]], [[155.88, -6.82], [155.17, -6.54], [154.51, -5.14], [155.88, -6.82]], [[151.98, -5.48], [150.24, -6.32], [148.32, -5.75], [149.85, -5.51], [150.14, -5], [150.24, -5.53], [150.81, -5.46], [151.65, -4.76], [151.54, -4.17], [152.34, -4.31], [151.98, -5.48]], [[147.19, -7.39], [150.69, -10.58], [147.91, -10.13], [146.05, -8.07], [144.74, -7.63], [143.29, -8.25], [143.41, -8.98], [142.63, -9.33], [141.03, -9.12], [141, -2.6], [144.58, -3.86], [145.98, -5.47], [147.65, -6.08], [147.89, -6.61], [146.97, -6.72], [147.19, -7.39]], [[153.14, -4.5], [152.83, -4.77], [152.41, -3.79], [150.66, -2.74], [152.24, -3.24], [153.14, -4.5]], [[15.02, 51.11], [14.12, 53.76], [17.62, 54.85], [23.24, 54.22], [23.8, 52.69], [23.2, 52.49], [24.03, 50.71], [22.52, 49.48], [22.78, 49.03], [18.91, 49.44], [15.02, 51.11]], [[-66.28, 18.51], [-65.59, 18.23], [-65.85, 17.98], [-67.18, 17.95], [-67.1, 18.52], [-66.28, 18.51]], [[130.64, 42.4], [129.67, 41.6], [129.71, 40.88], [127.53, 39.76], [127.39, 39.21], [128.21, 38.37], [125.28, 37.67], [124.71, 38.11], [125.39, 39.39], [124.27, 39.93], [125.08, 40.57], [126.87, 41.82], [128.21, 41.47], [128.05, 41.99], [129.99, 42.99], [130.64, 42.4]], [[-9.03, 41.88], [-8.26, 42.28], [-6.39, 41.38], [-7.5, 39.63], [-7.03, 38.08], [-7.86, 36.84], [-8.9, 36.87], [-8.84, 38.27], [-9.53, 38.74], [-8.77, 40.76], [-9.03, 41.88]], [[-62.69, -22.25], [-61.79, -19.63], [-59.12, -19.36], [-58.18, -19.87], [-57.94, -22.09], [-55.8, -22.36], [-55.4, -23.96], [-54.29, -24.02], [-54.79, -26.62], [-56.49, -27.55], [-58.62, -27.12], [-57.78, -25.16], [-60.85, -23.88], [-62.69, -22.25]], [[50.81, 24.75], [51.29, 26.11], [51.61, 25.22], [51.39, 24.63], [50.81, 24.75]], [[22.71, 47.88], [26.92, 48.12], [28.13, 46.81], [28.23, 45.49], [29.63, 45.04], [28.84, 44.91], [28.56, 43.71], [27.24, 44.18], [22.94, 43.82], [22.71, 44.58], [21.56, 44.77], [20.22, 46.13], [22.71, 47.88]], [[143.65, 50.75], [144.65, 48.98], [143.17, 49.31], [142.56, 47.86], [143.53, 46.84], [143.51, 46.14], [142.75, 46.74], [142.09, 45.97], [142.18, 50.95], [141.59, 51.94], [141.68, 53.3], [142.61, 53.76], [142.21, 54.23], [142.65, 54.37], [143.65, 50.75]], [[22.73, 54.33], [19.66, 54.43], [21.27, 55.19], [22.76, 54.86], [22.73, 54.33]], [[-175.01, 66.58], [-174.34, 66.34], [-174.57, 67.06], [-171.86, 66.91], [-169.9, 65.98], [-172.53, 65.44], [-172.96, 64.25], [-176.21, 65.36], [-178.36, 65.39], [-178.9, 65.74], [-178.69, 66.11], [-179.88, 65.87], [-179.43, 65.4], [-180, 64.98], [-180, 68.96], [-174.93, 67.21], [-175.01, 66.58]], [[180, 70.83], [178.73, 71.1], [180, 71.52], [180, 70.83]], [[-178.69, 70.89], [-180, 70.83], [-180, 71.52], [-177.58, 71.27], [-178.69, 70.89]], [[143.6, 73.21], [139.86, 73.37], [142.06, 73.86], [143.6, 73.21]], [[150.73, 75.08], [149.58, 74.69], [146.12, 75.17], [150.73, 75.08]], [[145.09, 75.56], [144.3, 74.82], [138.96, 74.61], [136.97, 75.26], [137.51, 75.95], [138.83, 76.14], [145.09, 75.56]], [[57.54, 70.72], [53.68, 70.76], [51.6, 71.47], [51.46, 72.01], [52.48, 72.23], [52.44, 72.77], [54.43, 73.63], [53.51, 73.75], [55.9, 74.63], [55.63, 75.08], [61.17, 76.25], [68.16, 76.94], [68.85, 76.54], [58.48, 74.31], [55.42, 72.37], [55.62, 71.54], [57.54, 70.72]], [[106.97, 76.97], [107.24, 76.48], [111.08, 76.71], [114.13, 75.85], [113.89, 75.33], [109.4, 74.18], [113.02, 73.98], [113.53, 73.34], [115.57, 73.75], [123.2, 72.97], [123.26, 73.74], [126.98, 73.57], [128.59, 73.04], [129.05, 72.4], [128.46, 71.98], [131.29, 70.79], [132.25, 71.84], [133.86, 71.39], [139.87, 71.49], [139.15, 72.42], [140.47, 72.85], [149.5, 72.2], [152.97, 70.84], [159, 70.87], [159.83, 70.45], [159.71, 69.72], [160.94, 69.44], [167.84, 69.58], [169.58, 68.69], [170.82, 69.01], [170.01, 69.65], [170.45, 70.1], [175.72, 69.88], [180, 68.96], [180, 64.98], [177.41, 64.61], [179.37, 62.98], [179.23, 62.3], [177.36, 62.52], [173.68, 61.65], [170.33, 59.88], [168.9, 60.57], [166.29, 59.79], [165.84, 60.16], [163.54, 59.87], [162.02, 58.24], [163.19, 57.62], [163.06, 56.16], [162.13, 56.12], [161.7, 55.29], [162.12, 54.86], [160.37, 54.34], [160.02, 53.2], [158.53, 52.96], [158.23, 51.94], [156.79, 51.01], [155.43, 55.38], [155.91, 56.77], [156.81, 57.83], [158.36, 58.06], [163.67, 61.14], [164.47, 62.55], [163.26, 62.47], [162.66, 61.64], [160.12, 60.54], [159.3, 61.77], [156.72, 61.43], [154.22, 59.76], [155.04, 59.14], [151.27, 58.78], [151.34, 59.5], [149.78, 59.66], [148.54, 59.16], [142.2, 59.04], [135.13, 54.73], [136.7, 54.6], [138.16, 53.76], [139.9, 54.19], [141.35, 53.09], [141.38, 52.24], [140.6, 51.24], [140.06, 48.45], [134.87, 43.4], [133.54, 42.81], [132.28, 43.28], [130.78, 42.22], [131.03, 44.97], [133.1, 45.14], [135.03, 48.48], [130.99, 47.79], [130.58, 48.73], [129.4, 49.44], [127.66, 49.76], [125.95, 52.79], [123.57, 53.46], [120.18, 52.75], [120.74, 51.96], [119.29, 50.14], [117.88, 49.51], [114.36, 50.25], [110.66, 49.13], [108.48, 49.28], [106.89, 50.27], [103.68, 50.09], [102.26, 50.51], [102.07, 51.26], [98.86, 52.05], [97.83, 51.01], [98.23, 50.42], [97.26, 49.73], [92.23, 50.8], [87.36, 49.21], [83.38, 51.07], [81.95, 50.81], [80.57, 51.39], [80.04, 50.86], [76.53, 54.18], [76.89, 54.49], [73.43, 53.49], [73.51, 54.04], [71.18, 54.13], [70.87, 55.17], [69.07, 55.39], [61.44, 54.01], [60.98, 53.66], [61.7, 52.98], [59.97, 51.96], [61.59, 51.27], [61.34, 50.8], [56.78, 51.04], [55.72, 50.62], [52.33, 51.72], [50.77, 51.69], [48.7, 50.61], [48.58, 49.87], [47.55, 50.45], [46.47, 48.39], [48.06, 47.74], [49.1, 46.4], [46.68, 44.61], [48.58, 41.81], [47.82, 41.15], [45.47, 42.5], [39.96, 43.43], [36.68, 45.24], [38.23, 46.24], [37.67, 46.64], [39.15, 47.04], [38.22, 47.1], [38.26, 47.55], [39.74, 47.9], [40.07, 49.6], [35.36, 50.58], [35.02, 51.21], [34.22, 51.26], [34.39, 51.77], [33.75, 52.34], [31.79, 52.1], [31.31, 53.07], [32.69, 53.35], [30.76, 54.81], [30.87, 55.55], [28.18, 56.17], [27.29, 57.47], [27.72, 57.79], [27.42, 58.72], [29.12, 60.03], [28.07, 60.5], [31.52, 62.87], [30.04, 63.55], [30.44, 64.2], [29.54, 64.95], [30.22, 65.81], [29.05, 66.94], [29.98, 67.7], [28.45, 68.36], [28.59, 69.06], [32.13, 69.91], [41.06, 67.46], [41.13, 66.79], [38.38, 66], [33.18, 66.63], [34.81, 65.9], [34.94, 64.41], [37.01, 63.85], [36.54, 64.76], [37.18, 65.14], [39.59, 64.52], [40.44, 64.76], [39.76, 65.5], [42.09, 66.48], [43.95, 66.07], [44.53, 66.76], [43.7, 67.35], [44.19, 67.95], [43.45, 68.57], [46.25, 68.25], [46.82, 67.69], [45.56, 67.57], [45.56, 67.01], [46.35, 66.67], [53.72, 68.86], [54.47, 68.81], [53.49, 68.2], [58.8, 68.88], [59.94, 68.28], [61.08, 68.94], [60.03, 69.52], [60.55, 69.85], [68.51, 68.09], [69.18, 68.62], [66.93, 69.45], [67.26, 69.93], [66.69, 71.03], [69.94, 73.04], [72.59, 72.78], [72.8, 72.22], [71.85, 71.41], [72.79, 70.39], [72.56, 69.02], [73.67, 68.41], [71.28, 66.32], [72.42, 66.17], [75.05, 67.76], [74.47, 68.33], [74.94, 68.99], [73.84, 69.07], [73.6, 69.63], [74.4, 70.63], [73.1, 71.45], [74.89, 72.12], [74.66, 72.83], [75.68, 72.3], [75.29, 71.34], [76.36, 71.15], [75.9, 71.87], [77.58, 72.27], [81.5, 71.75], [80.61, 72.58], [80.51, 73.65], [86.82, 73.94], [86.01, 74.46], [87.17, 75.12], [100.76, 76.43], [101.99, 77.29], [104.35, 77.7], [106.07, 77.37], [104.71, 77.13], [106.97, 76.97]], [[105.08, 78.31], [99.44, 77.92], [102.09, 79.35], [105.37, 78.71], [105.08, 78.31]], [[51.14, 80.55], [47.59, 80.01], [46.5, 80.25], [47.07, 80.56], [44.85, 80.59], [50.04, 80.92], [51.14, 80.55]], [[99.94, 78.88], [94.97, 79.04], [91.18, 80.34], [95.94, 81.25], [100.19, 79.78], [99.94, 78.88]], [[30.42, -1.13], [30.76, -2.29], [29.02, -2.84], [29.29, -1.62], [30.42, -1.13]], [[-8.79, 27.12], [-8.69, 25.88], [-11.97, 25.93], [-11.94, 23.37], [-12.87, 23.28], [-12.93, 21.33], [-17.06, 21], [-17.02, 21.42], [-14.75, 21.5], [-13.89, 23.69], [-12.5, 24.77], [-11.39, 26.88], [-8.79, 27.12]], [[42.78, 16.35], [40.94, 19.49], [39.14, 21.29], [38.49, 23.69], [37.48, 24.29], [35.13, 28.06], [34.63, 28.06], [34.96, 29.36], [36.07, 29.2], [38, 30.51], [37, 31.51], [39.2, 32.16], [40.4, 31.89], [44.71, 29.18], [48.42, 28.55], [50.15, 26.69], [50.24, 25.61], [51.39, 24.63], [52, 23], [55.21, 22.71], [55.67, 22], [55, 20], [49.12, 18.62], [47, 16.95], [43.38, 17.58], [42.78, 16.35]], [[33.96, 9.46], [33.21, 10.72], [33.21, 12.18], [32.74, 12.25], [32.07, 11.97], [32.4, 11.08], [31.35, 9.81], [30, 10.29], [28.97, 9.4], [26.75, 9.47], [25.79, 10.41], [25.07, 10.27], [24.54, 8.92], [23.46, 8.95], [23.55, 10.09], [21.94, 12.59], [23.02, 15.68], [23.89, 15.61], [23.85, 20], [25, 20], [25, 22], [36.87, 22], [37.48, 18.61], [38.41, 18], [36.85, 16.96], [36.27, 13.56], [33.96, 9.46]], [[33.96, 9.46], [33.83, 8.38], [32.95, 7.78], [34.08, 7.23], [35.3, 5.51], [33.39, 3.79], [31.88, 3.56], [30.83, 3.51], [29.72, 4.6], [27.98, 4.41], [23.89, 8.62], [24.54, 8.92], [25.07, 10.27], [25.79, 10.41], [26.75, 9.47], [28.97, 9.4], [30, 10.29], [31.35, 9.81], [32.4, 11.08], [32.07, 11.97], [32.74, 12.25], [33.21, 12.18], [33.21, 10.72], [33.96, 9.46]], [[-16.71, 13.59], [-17.63, 14.73], [-16.12, 16.46], [-14.58, 16.6], [-12.17, 14.62], [-11.51, 12.44], [-16.68, 12.38], [-16.84, 13.15], [-13.84, 13.51], [-16.71, 13.59]], [[160.85, -9.87], [159.85, -9.79], [159.7, -9.24], [160.85, -9.87]], [[-11.44, 6.79], [-12.95, 7.8], [-13.25, 8.9], [-11.92, 10.05], [-11.12, 10.05], [-10.23, 8.41], [-11.44, 6.79]], [[-87.79, 13.38], [-90.1, 13.74], [-89.35, 14.42], [-87.86, 13.89], [-87.79, 13.38]], [[48.94, 9.45], [47.79, 8], [46.95, 8], [43.68, 9.18], [42.56, 10.57], [43.15, 11.46], [44.12, 10.45], [48.95, 11.41], [48.94, 9.45]], [[49.73, 11.58], [51.11, 12.02], [51.05, 10.64], [48.59, 5.34], [41.59, -1.68], [40.99, -0.86], [40.98, 2.78], [42.13, 4.23], [44.96, 5], [48.94, 9.45], [48.94, 11.39], [49.73, 11.58]], [[20.87, 45.42], [22.71, 44.58], [22.41, 44.01], [22.99, 43.21], [22.38, 42.32], [21.58, 42.25], [21.78, 42.68], [20.81, 43.27], [20.26, 42.81], [19.22, 43.52], [19.6, 44.04], [18.83, 45.91], [20.22, 46.13], [20.87, 45.42]], [[-57.15, 5.97], [-53.96, 5.76], [-54.48, 4.9], [-54.01, 3.62], [-54.52, 2.31], [-55.97, 2.51], [-56, 1.82], [-56.54, 1.9], [-57.6, 3.33], [-58.04, 4.06], [-57.15, 5.97]], [[18.85, 49.5], [22.56, 49.09], [21.87, 48.32], [20.8, 48.62], [17.86, 47.76], [16.88, 48.47], [18.85, 49.5]], [[13.81, 46.51], [16.56, 46.5], [15.33, 45.45], [13.72, 45.5], [13.81, 46.51]], [[22.18, 65.72], [21.21, 65.03], [21.37, 64.41], [17.85, 62.75], [17.12, 61.34], [18.79, 60.08], [17.87, 58.95], [16.83, 58.72], [15.88, 56.1], [14.67, 56.2], [14.1, 55.41], [12.94, 55.36], [11.03, 58.86], [12.3, 60.12], [12.63, 61.29], [11.99, 61.8], [11.93, 63.13], [12.58, 64.07], [13.57, 64.05], [13.92, 64.45], [13.56, 64.79], [16.77, 68.01], [17.73, 68.01], [17.99, 68.57], [19.88, 68.41], [20.03, 69.07], [23.54, 67.94], [23.9, 66.01], [22.18, 65.72]], [[32.07, -26.73], [31.28, -27.29], [30.69, -26.74], [31.04, -25.73], [31.84, -25.84], [32.07, -26.73]], [[38.79, 33.38], [36.83, 32.31], [35.7, 32.72], [36.61, 34.2], [35.91, 35.41], [36.74, 36.82], [42.35, 37.23], [41.29, 36.36], [41.01, 34.42], [38.79, 33.38]], [[14.5, 12.86], [13.54, 14.37], [13.97, 15.68], [15.25, 16.63], [15.9, 20.39], [15.1, 21.31], [14.85, 22.86], [15.86, 23.41], [23.84, 19.58], [23.89, 15.61], [23.02, 15.68], [21.94, 12.59], [22.86, 11.14], [21, 9.48], [18.81, 8.98], [17.96, 7.89], [15.28, 7.42], [14.98, 8.8], [13.95, 9.55], [14.17, 10.02], [15.47, 9.98], [14.5, 12.86]], [[1.87, 6.14], [1.06, 5.93], [0.57, 6.91], [0.02, 11.02], [0.9, 11], [1.43, 9.83], [1.87, 6.14]], [[102.58, 12.19], [100.83, 12.63], [100.98, 13.41], [100.1, 13.41], [99.15, 9.96], [100.46, 7.43], [102.14, 6.22], [101.81, 5.81], [100.09, 6.46], [98.5, 8.38], [98.34, 7.79], [98.26, 8.97], [99.59, 11.89], [98.19, 15.12], [98.9, 16.18], [97.38, 18.45], [98.25, 19.71], [100.12, 20.42], [100.61, 19.51], [101.28, 19.46], [101.06, 17.51], [103.2, 18.31], [104.72, 17.43], [105.54, 14.72], [105.22, 14.27], [102.99, 14.23], [102.35, 13.39], [102.58, 12.19]], [[71.01, 40.24], [69.56, 40.1], [69.46, 39.53], [73.68, 39.43], [73.93, 38.51], [74.86, 38.38], [74.98, 37.42], [73.26, 37.5], [71.84, 36.74], [70.81, 38.49], [69.2, 37.15], [67.83, 37.14], [68.39, 38.16], [68.18, 38.9], [67.44, 39.14], [67.7, 39.58], [68.54, 39.53], [69.33, 40.73], [70.67, 40.96], [70.46, 40.5], [71.01, 40.24]], [[61.21, 35.65], [61.12, 36.49], [57.33, 38.03], [55.51, 37.96], [53.92, 37.2], [53.88, 38.95], [53.1, 39.29], [53.36, 39.98], [52.69, 40.03], [52.92, 40.88], [54.74, 40.95], [53.72, 42.12], [52.92, 41.87], [52.81, 41.14], [52.5, 41.78], [54.08, 42.32], [55.46, 41.26], [57.1, 41.32], [56.93, 41.83], [58.63, 42.75], [59.98, 42.22], [60.47, 41.22], [61.88, 41.08], [62.37, 40.05], [64.17, 38.89], [66.55, 37.97], [66.52, 37.36], [65.75, 37.66], [64.75, 37.11], [64.55, 36.31], [62.98, 35.4], [61.21, 35.65]], [[124.97, -8.89], [127.34, -8.4], [125.09, -9.39], [124.97, -8.89]], [[9.48, 30.31], [9.06, 32.1], [7.61, 33.34], [7.52, 34.1], [8.14, 34.66], [8.42, 36.95], [9.51, 37.35], [10.21, 37.23], [10.18, 36.72], [11.03, 37.09], [10.6, 36.41], [10.81, 34.83], [10.15, 34.33], [11.49, 33.14], [11.43, 32.37], [9.95, 31.38], [9.97, 30.54], [9.48, 30.31]], [[36.91, 41.34], [40.37, 41.01], [42.62, 41.58], [43.58, 41.09], [43.66, 40.25], [44.79, 39.71], [44.11, 39.43], [44.77, 37.17], [44.29, 37], [42.78, 37.39], [39.52, 36.72], [36.74, 36.82], [36.15, 35.82], [35.78, 36.27], [36.16, 36.65], [34.71, 36.8], [34.03, 36.22], [30.62, 36.68], [29.7, 36.14], [27.64, 36.66], [26.32, 38.21], [26.8, 38.99], [26.17, 39.46], [27.28, 40.42], [28.82, 40.46], [29.24, 41.22], [31.15, 41.09], [33.51, 42.02], [36.91, 41.34]], [[27.19, 40.69], [26.36, 40.15], [26.06, 40.82], [26.6, 41.56], [26.12, 41.83], [28, 42.01], [28.99, 41.3], [27.19, 40.69]], [[121.78, 24.39], [120.75, 21.97], [120.11, 23.56], [121.5, 25.3], [121.78, 24.39]], [[33.9, -0.95], [37.7, -3.1], [37.77, -3.68], [39.2, -4.68], [38.74, -5.91], [39.44, -6.84], [39.19, -8.49], [40.32, -10.32], [39.52, -10.9], [36.51, -11.72], [34.56, -11.52], [33.74, -9.42], [30.74, -8.34], [29.62, -6.52], [29.34, -4.5], [30.75, -3.36], [30.42, -1.13], [33.9, -0.95]], [[31.87, -1.03], [29.58, -1.34], [29.88, 0.6], [31.17, 2.2], [30.77, 2.34], [30.83, 3.51], [34.01, 4.25], [35.04, 1.91], [33.89, 0.11], [33.9, -0.95], [31.87, -1.03]], [[31.79, 52.1], [33.75, 52.34], [34.39, 51.77], [34.22, 51.26], [35.02, 51.21], [35.36, 50.58], [40.07, 49.6], [39.74, 47.9], [34.96, 46.27], [35.02, 45.65], [36.53, 45.47], [36.33, 45.11], [33.88, 44.36], [33.33, 44.56], [33.55, 45.03], [32.45, 45.33], [33.59, 45.85], [31.68, 46.71], [30.75, 46.58], [29.6, 45.29], [28.68, 45.3], [28.23, 45.49], [28.86, 46.44], [30.02, 46.42], [28.67, 48.12], [27.52, 48.47], [24.87, 47.74], [22.71, 47.88], [22.09, 48.42], [22.78, 49.03], [22.52, 49.48], [23.92, 50.42], [23.53, 51.58], [25.33, 51.91], [30.56, 51.32], [30.93, 52.04], [31.79, 52.1]], [[-57.63, -30.22], [-56.98, -30.11], [-53.79, -32.05], [-53.21, -32.73], [-53.81, -34.4], [-56.22, -34.86], [-58.43, -33.91], [-57.63, -30.22]], [[-155.54, 19.08], [-155.94, 19.06], [-155.86, 20.27], [-154.81, 19.51], [-155.54, 19.08]], [[-94.82, 49.39], [-94.33, 48.67], [-91.64, 48.14], [-88.38, 48.3], [-84.14, 46.51], [-82.55, 45.35], [-82.14, 43.57], [-83.12, 42.08], [-82.69, 41.68], [-78.94, 42.86], [-79.17, 43.47], [-78.72, 43.63], [-76.82, 43.63], [-74.87, 45], [-71.51, 45.01], [-69.24, 47.45], [-67.79, 47.07], [-67.79, 45.7], [-66.96, 44.81], [-70.12, 43.68], [-70.82, 42.34], [-69.97, 41.64], [-73.71, 40.93], [-71.94, 40.93], [-73.95, 40.75], [-74.91, 38.94], [-75.53, 39.5], [-75.06, 38.4], [-75.94, 37.22], [-75.72, 37.94], [-76.35, 39.15], [-76.33, 38.08], [-76.99, 38.24], [-76.3, 37.92], [-75.73, 35.55], [-81.34, 31.44], [-81.31, 30.04], [-80.06, 26.88], [-80.68, 25.08], [-82.71, 27.5], [-82.93, 29.1], [-84.1, 30.09], [-85.11, 29.64], [-86.4, 30.4], [-89.18, 30.32], [-89.59, 30.16], [-89.41, 29.16], [-93.23, 29.78], [-94.69, 29.48], [-97.14, 27.83], [-97.14, 25.87], [-97.53, 25.84], [-99.02, 26.37], [-100.96, 29.38], [-102.48, 29.76], [-103.11, 28.97], [-103.94, 29.27], [-106.51, 31.75], [-111.02, 31.33], [-114.72, 32.72], [-117.13, 32.54], [-118.52, 34.03], [-120.62, 34.61], [-124.4, 40.31], [-124.53, 42.77], [-123.9, 45.52], [-124.69, 48.18], [-123.12, 48.04], [-122.59, 47.1], [-122.84, 49], [-95.16, 49], [-94.82, 49.39]], [[-153.01, 57.12], [-154.01, 56.73], [-154.67, 57.46], [-152.56, 57.9], [-152.14, 57.59], [-153.01, 57.12]], [[-165.58, 59.91], [-167.46, 60.21], [-165.67, 60.29], [-165.58, 59.91]], [[-171.73, 63.78], [-168.69, 63.3], [-169.53, 62.98], [-171.55, 63.32], [-171.73, 63.78]], [[-155.07, 71.15], [-154.34, 70.7], [-140.99, 69.71], [-141, 60.31], [-139.04, 60], [-137.45, 58.91], [-135.48, 59.79], [-131.71, 56.55], [-130.01, 55.92], [-129.98, 55.28], [-130.54, 54.8], [-131.97, 55.5], [-134.08, 58.12], [-136.63, 58.21], [-142.57, 60.08], [-147.11, 60.88], [-148.22, 60.67], [-148.02, 59.98], [-151.72, 59.16], [-151.41, 60.73], [-150.35, 61.03], [-150.62, 61.28], [-154.02, 59.35], [-153.29, 58.86], [-154.23, 58.15], [-158.43, 55.99], [-164.79, 54.4], [-157.72, 57.57], [-157.04, 58.92], [-159.06, 58.42], [-160.36, 59.07], [-161.97, 58.67], [-161.87, 59.63], [-162.52, 59.99], [-163.82, 59.8], [-165.35, 60.51], [-166.12, 61.5], [-165.73, 62.07], [-164.56, 63.15], [-160.77, 63.77], [-161.52, 64.4], [-160.78, 64.79], [-164.96, 64.45], [-168.11, 65.67], [-164.47, 66.58], [-163.65, 66.58], [-163.79, 66.08], [-161.68, 66.12], [-166.76, 68.36], [-166.2, 68.88], [-163.17, 69.37], [-161.91, 70.33], [-156.58, 71.36], [-155.07, 71.15]], [[66.52, 37.36], [66.55, 37.97], [64.17, 38.89], [62.37, 40.05], [61.88, 41.08], [60.47, 41.22], [59.98, 42.22], [58.63, 42.75], [56.93, 41.83], [57.1, 41.32], [55.97, 41.31], [55.93, 45], [58.5, 45.59], [62.01, 43.5], [64.9, 43.73], [66.1, 43], [66.02, 41.99], [66.51, 41.99], [66.71, 41.17], [67.99, 41.14], [68.26, 40.66], [71.26, 42.17], [70.42, 41.52], [73.06, 40.87], [71.77, 40.15], [70.6, 40.22], [70.67, 40.96], [69.33, 40.73], [68.54, 39.53], [67.44, 39.14], [68.18, 38.9], [68.39, 38.16], [67.83, 37.14], [66.52, 37.36]], [[-71.33, 11.78], [-71.95, 11.42], [-71.7, 9.07], [-71.04, 9.86], [-71.4, 10.97], [-70.16, 11.38], [-69.94, 12.16], [-68.19, 10.55], [-66.23, 10.65], [-64.89, 10.08], [-64.32, 10.64], [-61.88, 10.72], [-62.73, 10.42], [-62.39, 9.95], [-59.76, 8.37], [-61.41, 5.96], [-60.6, 4.92], [-63.09, 3.77], [-64.82, 4.06], [-64.27, 2.5], [-63.37, 2.2], [-66.33, 0.72], [-67.81, 2.82], [-67.3, 3.32], [-67.82, 4.5], [-67.34, 6.1], [-69.39, 6.1], [-70.09, 6.96], [-71.96, 6.99], [-72.79, 9.09], [-73.3, 9.15], [-72.91, 10.45], [-71.33, 11.78]], [[108.05, 21.55], [106.72, 20.7], [105.66, 19.06], [108.88, 15.28], [109.2, 11.67], [105.16, 8.6], [105.08, 9.92], [104.33, 10.49], [106.25, 10.96], [105.81, 11.57], [107.49, 12.34], [107.56, 15.2], [105.09, 18.67], [103.9, 19.27], [104.82, 19.89], [104.44, 20.76], [103.2, 20.77], [102.17, 22.46], [105.33, 23.35], [108.05, 21.55]], [[53.11, 16.65], [52.39, 16.38], [52.17, 15.6], [48.68, 14], [44.18, 12.59], [43.48, 12.64], [42.6, 15.21], [43.38, 17.58], [47, 16.95], [49.12, 18.62], [52, 19], [53.11, 16.65]], [[31.52, -29.26], [27.46, -33.23], [25.78, -33.94], [22.57, -33.86], [19.62, -34.82], [18.38, -34.14], [17.93, -32.61], [18.22, -31.66], [16.34, -28.58], [16.82, -28.08], [18.46, -29.05], [19.89, -28.46], [19.9, -24.77], [20.89, -26.83], [21.61, -26.73], [23.31, -25.27], [25.66, -25.49], [28.02, -22.83], [29.84, -22.1], [31.19, -22.25], [31.93, -24.37], [31.84, -25.84], [31.04, -25.73], [30.69, -26.74], [31.28, -27.29], [32.83, -26.74], [32.46, -28.3], [31.52, -29.26]], [[28.98, -28.96], [28.07, -28.85], [27, -29.88], [28.11, -30.55], [29.33, -29.26], [28.98, -28.96]], [[32.76, -9.23], [33.49, -10.53], [32.69, -13.71], [33.21, -13.97], [30.18, -14.8], [30.27, -15.51], [28.95, -16.04], [27.04, -17.94], [23.22, -17.52], [21.89, -16.08], [21.93, -12.9], [24.02, -12.91], [23.91, -10.93], [25.75, -11.78], [27.16, -11.61], [28.93, -13.25], [29.7, -13.26], [29.62, -12.18], [28.37, -11.79], [28.73, -8.53], [30.35, -8.24], [32.76, -9.23]], [[31.19, -22.25], [28.02, -21.49], [25.26, -17.74], [27.04, -17.94], [28.95, -16.04], [30.27, -15.51], [32.85, -16.71], [32.66, -20.3], [31.19, -22.25]]];
})(); } catch (e) { __ds_ns.__errors.push({ path: "explorations/world-land.js", error: String((e && e.message) || e) }); }

// site/page-detail.jsx
try { (() => {
/* School detail — header band, description, lecturers, topics, attendance chart, interest form. */
function PageDetail() {
  const bars = [30, 45, 55, 62, 70, 50, 85];
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: "schools"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '34px 36px',
      borderBottom: '1px solid rgba(251,246,236,.22)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "as-btn ghost",
    style: {
      padding: '6px 12px',
      fontSize: 11
    }
  }, "\u2190 All schools"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-badge"
  }, "Upcoming"), /*#__PURE__*/React.createElement("span", {
    className: "as-mono",
    style: {
      fontSize: 11,
      color: 'rgba(251,246,236,.5)'
    }
  }, "27\u201331 JUL 2026 \xB7 ROME")), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1pg",
    style: {
      marginTop: 14
    }
  }, "Bayesian Inference", /*#__PURE__*/React.createElement("br", null), "for Astronomy"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "Five days of hierarchical modelling, MCMC and posterior diagnostics, applied to real survey data with daily hands-on labs."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "as-btn solid"
  }, "Apply Now"))), /*#__PURE__*/React.createElement(Rail, {
    n: "A",
    label: "Overview"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "What you'll learn"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "From the foundations of probability to building and checking full hierarchical models, you'll leave able to design, fit and critique a Bayesian analysis end to end \u2014 and to read the literature with a sharper eye.")), /*#__PURE__*/React.createElement(Rail, {
    n: "B",
    label: "Faculty",
    accent: "red"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Lecturers"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14,
      marginTop: 18
    }
  }, ['Inference & priors', 'MCMC & diagnostics', 'Hierarchical models', 'Model checking'].map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "as-card",
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-av"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 15
    }
  }, "Lecturer ", i + 1), /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 11,
      color: 'rgba(251,246,236,.5)',
      marginTop: 4
    }
  }, r))))), /*#__PURE__*/React.createElement("div", {
    className: "as-eyebrow",
    style: {
      marginTop: 30,
      display: 'block'
    }
  }, "Topics"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginTop: 12
    }
  }, ['Bayesian', 'Deep Learning', 'MCMC', 'Gaussian Proc.', 'AI Agents', 'Diagnostics'].map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip"
  }, t)))), /*#__PURE__*/React.createElement(Rail, {
    n: "C",
    label: "History"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Attendance history"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "Applications have grown each year \u2014 this cohort (crimson) is the largest yet."), /*#__PURE__*/React.createElement("div", {
    className: "as-chart",
    style: {
      marginTop: 18,
      maxWidth: 460
    }
  }, bars.map((h, i) => /*#__PURE__*/React.createElement("i", {
    key: i,
    className: i === bars.length - 1 ? 'hi' : '',
    style: {
      height: h + '%'
    }
  })))), /*#__PURE__*/React.createElement(Rail, {
    n: "D",
    label: "Apply",
    accent: "red"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Express interest"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      marginTop: 18,
      maxWidth: 460
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, "Full name *"), /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, "Email *"), /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, "Career stage \u25BE"), /*#__PURE__*/React.createElement("button", {
    className: "as-btn solid",
    style: {
      justifyContent: 'center'
    }
  }, "Submit Interest"))))), /*#__PURE__*/React.createElement(SiteFooter, null));
}
window.PageDetail = PageDetail;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/page-detail.jsx", error: String((e && e.message) || e) }); }

// site/page-home.jsx
try { (() => {
/* Home — the approved hero, continued into What we do / Who we are / Why we exist. */
function PageHome({
  railVariant = 'matrix'
}) {
  const [mode, setMode] = React.useState('hist');
  const [ro, setRo] = React.useState({
    alpha: 2,
    beta: 2
  });
  const [ts, setTs] = React.useState({
    phi: 0.92,
    noise: 0.5
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: "home"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement("div", {
    className: "as-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-rain"
  }, /*#__PURE__*/React.createElement(CodeRainBG, {
    color: "#8c0527",
    alpha: 0.4
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-hero-l"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-tagline"
  }, "// advanced statistics. taught and applied.", /*#__PURE__*/React.createElement("span", {
    className: "as-cur"
  })), /*#__PURE__*/React.createElement("h1", {
    className: "as-title"
  }, "AstroStat", /*#__PURE__*/React.createElement("br", null), "Academy"), /*#__PURE__*/React.createElement("div", {
    className: "as-lede"
  }, "Take ", /*#__PURE__*/React.createElement("span", {
    className: "b"
  }, "control"), " of your statistics."), /*#__PURE__*/React.createElement("div", {
    className: "as-ctrl"
  }, /*#__PURE__*/React.createElement(HeroControls, {
    mode: mode,
    onMode: setMode
  }), mode === 'hist' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParamSlider, {
    label: "\u03B1",
    value: ro.alpha,
    min: 0.5,
    max: 6,
    onChange: v => setRo(r => ({
      ...r,
      alpha: v
    }))
  }), /*#__PURE__*/React.createElement(ParamSlider, {
    label: "\u03B2",
    value: ro.beta,
    min: 0.5,
    max: 6,
    onChange: v => setRo(r => ({
      ...r,
      beta: v
    }))
  })) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(ParamSlider, {
    label: "\u03C6",
    value: ts.phi,
    min: 0,
    max: 0.98,
    onChange: v => setTs(t => ({
      ...t,
      phi: v
    }))
  }), /*#__PURE__*/React.createElement(ParamSlider, {
    label: "\u03C3",
    value: ts.noise,
    min: 0.1,
    max: 1.2,
    onChange: v => setTs(t => ({
      ...t,
      noise: v
    }))
  }))), /*#__PURE__*/React.createElement("p", {
    className: "as-about"
  }, "We teach and mentor researchers and teams, carrying methods proven in research into practice \u2014 tuned to what each one actually needs.")), /*#__PURE__*/React.createElement("div", {
    className: "as-hero-r"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-figtop"
  }, "Fig. ", mode === 'hist' ? '01' : '02', " \u2014 ", mode === 'hist' ? 'Beta distribution' : 'Time series'), /*#__PURE__*/React.createElement(HeroWidget, {
    hideToggle: true,
    hideGrips: true,
    mode: mode,
    onMode: setMode,
    alpha: ro.alpha,
    beta: ro.beta,
    phi: ts.phi,
    noise: ts.noise,
    onReadout: (a, b) => setRo({
      alpha: a,
      beta: b
    }),
    accent: "#0465ad",
    data: "#8c0527",
    w: 360,
    h: 190
  }))), /*#__PURE__*/React.createElement(Rail, {
    n: "01",
    label: "Where we're headed",
    variant: railVariant,
    keyword: "vision"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Our Vision"), /*#__PURE__*/React.createElement("p", {
    className: "as-vision"
  }, "We cultivate the statistical ", /*#__PURE__*/React.createElement("span", {
    className: "b"
  }, "mastery and judgement"), " to turn information into knowledge, and navigate a world flooded by fast but unreliable answers.")), /*#__PURE__*/React.createElement(Rail, {
    n: "02",
    label: "Why it matters",
    accent: "red",
    variant: railVariant,
    keyword: "problem"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-band-split",
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 28,
      flexWrap: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '0 0 50%',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "The Problem"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "Whether you publish papers or bet budgets on a model, you have more tools and faster answers than ever \u2014 AutoML, dashboards, generative models that will write the analysis for you. But ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fbf6ec',
      fontWeight: 600
    }
  }, "a confident output is not a correct one"), ". Lean on methods you can't interrogate and you can't defend the result to a reviewer or a board, reproduce it next year, or tell a real effect from noise \u2014 and either way, your name is on it.")), /*#__PURE__*/React.createElement("div", {
    className: "as-void-viz",
    style: {
      flex: '0 0 40%',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(AstroTerminal, {
    accent: "#c8607a",
    w: "100%"
  })))), /*#__PURE__*/React.createElement(Rail, {
    n: "03",
    label: "Why we teach",
    variant: railVariant,
    keyword: "why"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Our Mission"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "We're an educational organization \u2014 we teach you ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fbf6ec',
      fontWeight: 600
    }
  }, "to do the analysis yourself, and to interpret and question the answers your tools hand back"), ", rather than take them at face value.")), /*#__PURE__*/React.createElement(Rail, {
    n: "04",
    label: "What we do",
    accent: "red",
    variant: railVariant,
    keyword: "do"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-band-split",
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 28,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '0 0 50%',
      minWidth: 280
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Our Activities"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "From intensive residential schools to applied consulting, we meet statistical problems wherever they live \u2014 across research and industry alike.")), /*#__PURE__*/React.createElement("div", {
    className: "as-modrow",
    style: {
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-mod",
    style: {
      '--mc': '#d06f86'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mtop"
  }, /*#__PURE__*/React.createElement("span", null, "MOD\xB701"), /*#__PURE__*/React.createElement(RailMatrix, {
    accent: "red",
    cols: 3,
    rows: 1,
    phase: 0,
    speed: 500
  })), /*#__PURE__*/React.createElement("div", {
    className: "mnm"
  }, "Schools"), /*#__PURE__*/React.createElement("div", {
    className: "mds"
  }, "For data professionals")), /*#__PURE__*/React.createElement("div", {
    className: "as-mod",
    style: {
      '--mc': '#3b9be0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mtop"
  }, /*#__PURE__*/React.createElement("span", null, "MOD\xB702"), /*#__PURE__*/React.createElement(RailMatrix, {
    accent: "blue",
    cols: 3,
    rows: 1,
    phase: 3,
    speed: 500
  })), /*#__PURE__*/React.createElement("div", {
    className: "mnm"
  }, "Hackatons"), /*#__PURE__*/React.createElement("div", {
    className: "mds"
  }, "For teams")), /*#__PURE__*/React.createElement("div", {
    className: "as-mod",
    style: {
      '--mc': '#d06f86'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mtop"
  }, /*#__PURE__*/React.createElement("span", null, "MOD\xB703"), /*#__PURE__*/React.createElement(RailMatrix, {
    accent: "red",
    cols: 3,
    rows: 1,
    phase: 6,
    speed: 500
  })), /*#__PURE__*/React.createElement("div", {
    className: "mnm"
  }, "Consulting"), /*#__PURE__*/React.createElement("div", {
    className: "mds"
  }, "For organizations"))))), /*#__PURE__*/React.createElement(Rail, {
    n: "05",
    label: "What we know",
    variant: railVariant,
    keyword: "expertise"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Our Expertise"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "The statistical and machine-learning methods we teach, apply, and research \u2014 chosen to fit each problem, not the other way around."), /*#__PURE__*/React.createElement("div", {
    className: "as-methods"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-mrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk top"
  }, "Statistics"), /*#__PURE__*/React.createElement("span", {
    className: "mv chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Hypothesis Testing"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Classical and Bayesian inference"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "MCMC"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Gaussian Processes"))), /*#__PURE__*/React.createElement("div", {
    className: "as-mrow red"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk top"
  }, "Machine Learning"), /*#__PURE__*/React.createElement("span", {
    className: "mv chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Classification"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Clustering"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Dimensionality Reduction"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Feature Analysis"))), /*#__PURE__*/React.createElement("div", {
    className: "as-mrow"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk top"
  }, "Deep Learning"), /*#__PURE__*/React.createElement("span", {
    className: "mv chips"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Convolutional Nets"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Autoencoding"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "Transformers"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "LLMs"), /*#__PURE__*/React.createElement("span", {
    className: "mc"
  }, "AI Agents"))), /*#__PURE__*/React.createElement("div", {
    className: "as-methods-more"
  }, "and many more", /*#__PURE__*/React.createElement("span", {
    className: "as-cur"
  })))), /*#__PURE__*/React.createElement(Rail, {
    n: "06",
    label: "Who we are",
    accent: "red",
    variant: railVariant,
    keyword: "who"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "The Team"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "A collective of working Researchers, Data Scientists and Machine-Learning experts drawn from academic institutes and companies across Europe."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "as-btn ghost"
  }, "Meet our people \u2192"))))), /*#__PURE__*/React.createElement(SiteFooter, null));
}
window.PageHome = PageHome;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/page-home.jsx", error: String((e && e.message) || e) }); }

// site/page-people.jsx
try { (() => {
/* People — live from assets/people/people.yml + per-person .md files.
   Same source of truth as the website UI kit; edit those files, not this. */

const PP_BASE = '../assets/people';
const PP_ROLE_META = {
  councellors: {
    label: 'Councellors',
    eyebrow: '',
    wide: true
  },
  lecturers: {
    label: 'Lecturers',
    eyebrow: 'red',
    wide: false
  },
  TAs: {
    label: 'Teaching assistants',
    eyebrow: '',
    wide: false
  },
  advisors: {
    label: 'Advisors',
    eyebrow: 'red',
    wide: false
  }
};
function ppParseRoster(text) {
  const out = [];
  let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, '');
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) {
      cur = {
        role: sec[1],
        slugs: []
      };
      out.push(cur);
      return;
    }
    const it = line.match(/^\s*-\s*(.+?)\s*$/);
    if (it && cur) cur.slugs.push(it[1]);
  });
  return out;
}
function ppParsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = {
    links: {}
  };
  let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s+/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1],
        val = kv[2].trim();
      if (key === 'links' && val === '') {
        inLinks = true;
        return;
      }
      if (inLinks && indented) {
        meta.links[key] = val;
        return;
      }
      inLinks = false;
      meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}
function ppInitials(name) {
  const c = name.replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return (c[0][0] + (c[c.length - 1][0] || '')).toUpperCase();
}
function PPAvatar({
  person
}) {
  const [failed, setFailed] = React.useState(false);
  const show = person.photoUrl && !failed;
  return /*#__PURE__*/React.createElement("span", {
    className: "as-av",
    style: {
      display: 'grid',
      placeItems: 'center',
      overflow: 'hidden',
      fontFamily: 'ui-monospace, monospace',
      fontWeight: 600,
      fontSize: 13,
      color: 'rgba(251,246,236,.7)'
    }
  }, show ? /*#__PURE__*/React.createElement("img", {
    src: person.photoUrl,
    alt: person.name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    },
    onError: () => setFailed(true)
  }) : ppInitials(person.name));
}
function PPWideCard({
  person
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-card",
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(PPAvatar, {
    person: person
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 16
    }
  }, person.name), person.affiliation && /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 11,
      color: 'rgba(251,246,236,.5)',
      margin: '4px 0 8px'
    }
  }, person.affiliation), person.title && /*#__PURE__*/React.createElement("div", {
    className: "as-chip"
  }, person.title), person.bio && /*#__PURE__*/React.createElement("div", {
    className: "as-p",
    style: {
      fontSize: 13,
      marginTop: 8
    }
  }, person.bio)));
}
function PPCompactCard({
  person
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-card",
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(PPAvatar, {
    person: person
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14
    }
  }, person.name), person.affiliation && /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 10,
      color: 'rgba(251,246,236,.45)'
    }
  }, person.affiliation));
}
async function ppLoad() {
  const roster = ppParseRoster(await fetch(`${PP_BASE}/people.yml`).then(r => {
    if (!r.ok) throw new Error('people.yml');
    return r.text();
  }));
  const sections = await Promise.all(roster.map(async ({
    role,
    slugs
  }) => {
    const people = (await Promise.all(slugs.map(async slug => {
      try {
        const md = await fetch(`${PP_BASE}/${role}/${slug}.md`).then(r => {
          if (!r.ok) throw new Error(`${role}/${slug}.md`);
          return r.text();
        });
        const p = ppParsePerson(md);
        if (!p.name) p.name = slug;
        p.photoUrl = `${PP_BASE}/${role}/${p.photo || slug + '.jpg'}`;
        return p;
      } catch (e) {
        console.warn('[people]', e.message);
        return null;
      }
    }))).filter(Boolean);
    const meta = PP_ROLE_META[role] || {
      label: role,
      eyebrow: '',
      wide: false
    };
    return {
      role,
      ...meta,
      people
    };
  }));
  return sections.filter(s => s.people.length);
}

/* The People page IS the personnel terminal: "Personnel terminal" head,
   "Select a name to open their file.", two-column name grid + CRT dossier.
   Implementation lives in explorations/page-people-terminal.jsx (OptConsole)
   so there is a single version — don't fork it here. */
function PagePeople() {
  return /*#__PURE__*/React.createElement(OptConsole, null);
}

/* Coming-soon template — Consulting (red) / Hackatons (blue). Two-primary system. */
function ComingSoon({
  active,
  eyebrow,
  eyebrowClass,
  title,
  body,
  rain,
  link
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: active
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement("div", {
    className: "as-soon"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-rain"
  }, /*#__PURE__*/React.createElement(CodeRainBG, {
    color: rain,
    alpha: 0.4
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-soon-in"
  }, /*#__PURE__*/React.createElement("span", {
    className: 'as-eyebrow ' + eyebrowClass
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1pg",
    style: {
      marginTop: 14
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "as-p",
    style: {
      margin: '14px auto 0'
    }
  }, body), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 26
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: 'as-btn ' + (eyebrowClass === 'red' ? 'red' : 'ghost')
  }, link, " \u2709")), /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 11,
      letterSpacing: '.2em',
      textTransform: 'uppercase',
      color: 'rgba(251,246,236,.35)',
      marginTop: 30
    }
  }, "// status: coming soon"))))), /*#__PURE__*/React.createElement(SiteFooter, null));
}
function PageConsulting() {
  return /*#__PURE__*/React.createElement(HeroConsole, {
    ctx: PH_CTX.consulting
  });
}
function PageHackatons() {
  return /*#__PURE__*/React.createElement(HeroConsole, {
    ctx: PH_CTX.hackatons
  });
}

/* Papers that credit the Academy. Fed by /api/papers (NASA ADS full-text
   search on the two acknowledgement phrases); falls back to the committed
   snapshot when the endpoint isn't there. Nothing here is hand-maintained. */
function CreditedPapers() {
  const [state, setState] = React.useState({
    status: 'loading',
    papers: [],
    updated: null
  });
  React.useEffect(() => {
    let live = true;
    (async () => {
      const tryFetch = async u => {
        const r = await fetch(u);
        if (!r.ok) throw new Error(String(r.status));
        return r.json();
      };
      let data = null;
      try {
        data = await tryFetch('/api/papers');
      } catch (e) {
        try {
          data = await tryFetch('../assets/papers.json');
        } catch (e2) {
          data = null;
        }
      }
      if (!live) return;
      if (!data) setState({
        status: 'error',
        papers: [],
        updated: null
      });else setState({
        status: 'ok',
        papers: data.papers || [],
        updated: data.updated || null
      });
    })();
    return () => {
      live = false;
    };
  }, []);
  const byYear = React.useMemo(() => {
    const g = new Map();
    for (const p of state.papers) {
      const y = p.year || '—';
      if (!g.has(y)) g.set(y, []);
      g.get(y).push(p);
    }
    return [...g.entries()].sort((a, b) => Number(b[0]) - Number(a[0]));
  }, [state.papers]);
  const authorLine = (a = []) => {
    if (!a.length) return '';
    const short = a.slice(0, 3).join('; ');
    return a.length > 3 ? short + ' et al.' : short;
  };
  const stamp = state.updated ? new Date(state.updated).toISOString().slice(0, 10) : null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 56
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-eyebrow",
    style: {
      display: 'block'
    }
  }, "Papers crediting us"), /*#__PURE__*/React.createElement("p", {
    className: "as-p",
    style: {
      maxWidth: 640,
      marginTop: 8
    }
  }, "Collected automatically from published acknowledgements. No list is kept by hand."), state.status === 'loading' && /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 12,
      color: 'var(--fg3)',
      marginTop: 20
    }
  }, "// fetching\u2026"), state.status === 'error' && /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 12,
      color: 'var(--fg3)',
      marginTop: 20
    }
  }, "// paper list unavailable"), state.status === 'ok' && !state.papers.length && /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 12,
      color: 'var(--fg3)',
      marginTop: 20
    }
  }, "// no papers indexed yet"), state.status === 'ok' && state.papers.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 11,
      letterSpacing: '.06em',
      color: 'var(--fg3)',
      borderBottom: '1px solid var(--border)',
      paddingBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", null, state.papers.length, " paper", state.papers.length === 1 ? '' : 's'), stamp && /*#__PURE__*/React.createElement("span", null, "updated ", stamp)), byYear.map(([year, list]) => /*#__PURE__*/React.createElement("div", {
    key: year,
    style: {
      display: 'grid',
      gridTemplateColumns: '64px minmax(0,1fr)',
      gap: 16,
      paddingTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 13,
      color: 'var(--blue)',
      paddingTop: 2
    }
  }, year), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, list.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.bibcode,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: p.url,
    target: "_blank",
    rel: "noopener noreferrer",
    style: {
      fontSize: 15,
      fontWeight: 600,
      lineHeight: 1.4,
      color: 'var(--fg1)',
      textDecoration: 'none'
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--fg3)',
      lineHeight: 1.5
    }
  }, authorLine(p.authors)), /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 14,
      fontSize: 11,
      letterSpacing: '.04em',
      color: 'var(--fg4)'
    }
  }, p.journal && /*#__PURE__*/React.createElement("span", null, p.journal), p.arxiv && /*#__PURE__*/React.createElement("span", null, "arXiv:", p.arxiv), typeof p.citations === 'number' && /*#__PURE__*/React.createElement("span", null, p.citations, " cited")))))))));
}

/* Acknowledge — how to credit the Academy in published work. */
function PageAcknowledge() {
  const ACK = 'We wish to thank the AstroStat Academy for providing training on the analysis methods adopted in this work.';
  const [copied, setCopied] = React.useState(false);
  const ct = React.useRef(null);
  const copy = () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(ACK);
      } else {
        throw new Error('fallback');
      }
    } catch (e) {
      try {
        const ta = document.createElement('textarea');
        ta.value = ACK;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      } catch (e2) {/* ignore */}
    }
    setCopied(true);
    clearTimeout(ct.current);
    ct.current = setTimeout(() => setCopied(false), 2000);
  };
  React.useEffect(() => () => clearTimeout(ct.current), []);
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: "acknowledge"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement(Rail, {
    n: "06",
    label: "Credit",
    variant: "glyph"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-eyebrow"
  }, "Acknowledge us"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1pg",
    style: {
      marginTop: 10
    }
  }, "Crediting", /*#__PURE__*/React.createElement("br", null), "AstroStat Academy"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "If a school, hackaton or consulting engagement contributed to your research, a short acknowledgement in your paper or talk helps us keep the programme running and reach new groups."), /*#__PURE__*/React.createElement("div", {
    className: "as-eyebrow",
    style: {
      marginTop: 32,
      display: 'block'
    }
  }, "Suggested acknowledgement"), /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      position: 'relative',
      border: '1px solid rgba(251,246,236,.25)',
      background: 'rgba(255,255,255,.03)',
      padding: '30px 22px 20px',
      fontSize: 14,
      lineHeight: 1.65,
      color: 'rgba(251,246,236,.82)',
      maxWidth: 640,
      marginTop: 12,
      fontStyle: 'italic'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 6,
      left: 16,
      fontSize: 44,
      lineHeight: 1,
      color: '#3b9be0',
      fontFamily: 'Georgia, serif'
    }
  }, "\u201C"), ACK), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 16,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: 'calc(100% + 8px)',
      left: 0,
      whiteSpace: 'nowrap',
      fontFamily: 'ui-monospace,monospace',
      fontSize: 11,
      letterSpacing: '.06em',
      color: '#fff',
      background: '#0465ad',
      padding: '6px 10px',
      opacity: copied ? 1 : 0,
      transform: copied ? 'translateY(0)' : 'translateY(4px)',
      pointerEvents: 'none',
      transition: 'opacity .18s, transform .18s'
    }
  }, "Text copied to clipboard"), /*#__PURE__*/React.createElement("button", {
    className: "as-btn solid",
    onClick: copy
  }, "Copy text")), /*#__PURE__*/React.createElement(CreditedPapers, null)))), /*#__PURE__*/React.createElement(SiteFooter, null));
}
Object.assign(window, {
  PagePeople,
  ComingSoon,
  PageConsulting,
  PageHackatons,
  PageAcknowledge,
  CreditedPapers
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/page-people.jsx", error: String((e && e.message) || e) }); }

// site/page-schools.jsx
try { (() => {
/* Schools — listing: page header, filters, responsive card grid. */
const SCHOOLS = [{
  status: 'Upcoming',
  year: '2026',
  title: 'Bayesian Inference for Astronomy',
  place: 'Rome',
  topics: ['Bayesian', 'MCMC']
}, {
  status: 'Past',
  year: '2025',
  title: 'Deep Learning on the GPU',
  place: 'Heidelberg',
  topics: ['Deep L.', 'GPU']
}, {
  status: 'Past',
  year: '2025',
  title: 'Time Series & Variability',
  place: 'Leiden',
  topics: ['Time ser.']
}, {
  status: 'Past',
  year: '2024',
  title: 'Machine Learning Foundations',
  place: 'Paris',
  topics: ['Bayesian', 'ML']
}, {
  status: 'Past',
  year: '2024',
  title: 'Gaussian Processes in Practice',
  place: 'Geneva',
  topics: ['GP', 'Kernels']
}, {
  status: 'Past',
  year: '2023',
  title: 'Hierarchical Models',
  place: 'Munich',
  topics: ['Bayesian']
}];
function SchoolCard({
  s
}) {
  const up = s.status === 'Upcoming';
  return /*#__PURE__*/React.createElement("div", {
    className: "as-card",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: 'as-badge' + (up ? '' : ' muted')
  }, s.status), /*#__PURE__*/React.createElement("span", {
    className: "as-mono",
    style: {
      fontSize: 11,
      color: 'rgba(251,246,236,.45)'
    }
  }, s.year)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 17,
      lineHeight: 1.2
    }
  }, s.title), /*#__PURE__*/React.createElement("div", {
    className: "as-mono",
    style: {
      fontSize: 11,
      color: 'rgba(251,246,236,.5)'
    }
  }, s.place), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap',
      marginTop: 2
    }
  }, s.topics.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip"
  }, t))));
}
function PageSchools() {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement(SiteNav, {
    active: "schools"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement(Corners, null), /*#__PURE__*/React.createElement(Rail, {
    n: "02",
    label: "Training"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-eyebrow"
  }, "Schools"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1pg",
    style: {
      marginTop: 10
    }
  }, "Residential schools", /*#__PURE__*/React.createElement("br", null), "in statistical astronomy"), /*#__PURE__*/React.createElement("p", {
    className: "as-p"
  }, "Week-long intensives taught by working researchers. Lectures in the morning, hands-on labs in the afternoon, real data throughout."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center',
      marginTop: 26,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "as-btn ghost"
  }, "Year \u25BE"), /*#__PURE__*/React.createElement("button", {
    className: "as-btn ghost"
  }, "Topic \u25BE"), /*#__PURE__*/React.createElement("span", {
    className: "as-mono",
    style: {
      fontSize: 11,
      color: 'rgba(251,246,236,.45)',
      marginLeft: 'auto'
    }
  }, SCHOOLS.length, " schools found")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 14,
      marginTop: 16
    }
  }, SCHOOLS.map((s, i) => /*#__PURE__*/React.createElement(SchoolCard, {
    key: i,
    s: s
  })))))), /*#__PURE__*/React.createElement(SiteFooter, null));
}
window.PageSchools = PageSchools;
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/page-schools.jsx", error: String((e && e.message) || e) }); }

// site/site-kit.jsx
try { (() => {
/* AstroStat Academy — full-site kit (Instrument Panel style).
   Chrome components: nav, footer, corner marks, rail modules.
   Styles live in css/kit-chrome.css (loaded via styles.css) — not in this file.
   Loads after site-effects.jsx — reuses CodeRainBG / HeroWidget / HeroControls / ParamSlider. */

function Corners() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-c as-br"
  }));
}
const NAV = [{
  id: 'home',
  label: 'Home'
}, {
  id: 'schools',
  label: 'Schools'
}, {
  id: 'hackatons',
  label: 'Hackatons'
}, {
  id: 'consulting',
  label: 'Consulting'
}, {
  id: 'people',
  label: 'People'
}, {
  id: 'acknowledge',
  label: 'Acknowledge us'
}];
function SiteNav({
  active = 'home',
  coord = 'RA 14ʰ02ᵐ38ˢ · DEC +54°21′09″'
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-nav"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../assets/logo-bone.svg",
    alt: ""
  }), "AstroStat Academy"), /*#__PURE__*/React.createElement("div", {
    className: "as-coord"
  }, coord), /*#__PURE__*/React.createElement("div", {
    className: "as-nl"
  }, NAV.map(n => /*#__PURE__*/React.createElement("span", {
    key: n.id,
    className: n.id === active ? 'on' : ''
  }, n.label))));
}
function SiteFooter() {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-foot"
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 AstroStat Academy"), /*#__PURE__*/React.createElement("div", {
    className: "fl"
  }, /*#__PURE__*/React.createElement("span", null, "Schools"), /*#__PURE__*/React.createElement("span", null, "People"), /*#__PURE__*/React.createElement("span", null, "Consulting")), /*#__PURE__*/React.createElement("span", null, "astrostat.academy"));
}

/* Left-rail section module. accent: 'blue' | 'red' */
/* Scanning LED matrix — a cols×rows grid with one cell lit, sweeping on a loop
   with a short fading trail. phase desyncs each instance. */
function RailMatrix({
  accent,
  cols = 8,
  rows = 2,
  phase = 0,
  speed = 150
}) {
  const total = cols * rows;
  const [t, setT] = React.useState(phase);
  React.useEffect(() => {
    const id = setInterval(() => setT(v => v + 1), speed);
    return () => clearInterval(id);
  }, [speed]);
  const active = t % total;
  const color = accent === 'red' ? '#c8607a' : '#3b9be0';
  const cells = [];
  for (let i = 0; i < total; i++) {
    const dist = (active - i + total) % total;
    const op = dist === 0 ? 1 : dist === 1 ? 0.5 : dist === 2 ? 0.28 : 0.14;
    cells.push(/*#__PURE__*/React.createElement("span", {
      key: i,
      className: "as-mx-c",
      style: {
        background: color,
        opacity: op
      }
    }));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "as-mx",
    style: {
      gridTemplateColumns: `repeat(${cols}, 1fr)`
    }
  }, cells);
}

/* Left-rail section module. accent: 'blue' | 'red'.
   variant: 'number' (default) | 'glyph' | 'label' | 'tag' | 'matrix'. */
function Rail({
  n,
  label,
  accent,
  variant = 'number',
  keyword,
  children
}) {
  const r = accent === 'red';
  let idx;
  if (variant === 'matrix') {
    idx = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(RailMatrix, {
      accent: accent,
      phase: (parseInt(n, 10) || 0) * 5
    }), /*#__PURE__*/React.createElement("div", {
      className: 'l' + (r ? ' red' : '')
    }, label));
  } else if (variant === 'glyph') {
    idx = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: 'as-rx' + (r ? ' red' : '')
    }, /*#__PURE__*/React.createElement("span", {
      className: "ring"
    })), /*#__PURE__*/React.createElement("div", {
      className: 'l' + (r ? ' red' : '')
    }, label));
  } else if (variant === 'label') {
    idx = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: 'as-rtick' + (r ? ' red' : '')
    }), /*#__PURE__*/React.createElement("div", {
      className: 'l lg' + (r ? ' red' : '')
    }, label));
  } else if (variant === 'tag') {
    idx = /*#__PURE__*/React.createElement("div", {
      className: 'as-rtag' + (r ? ' red' : '')
    }, /*#__PURE__*/React.createElement("span", {
      className: "sl"
    }, "//"), " ", keyword);
  } else {
    idx = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "n"
    }, n), /*#__PURE__*/React.createElement("div", {
      className: 'l' + (r ? ' red' : '')
    }, label));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "as-rail"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-rail-idx"
  }, idx), /*#__PURE__*/React.createElement("div", {
    className: "as-rail-body"
  }, children));
}
Object.assign(window, {
  Corners,
  SiteNav,
  SiteFooter,
  Rail,
  RailMatrix
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "site/site-kit.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
/* AstroStat Academy — UI kit: app shell + routing */

function App() {
  const [route, setRoute] = React.useState('home'); // home | schools | school | hackatons | consulting | people
  const [slug, setSlug] = React.useState(null);
  const [dark, setDark] = React.useState(true);
  const nav = r => {
    if (r === 'home') {
      setRoute('home');
    } else {
      setRoute(r);
    }
    setSlug(null);
    window.scrollTo({
      top: 0
    });
  };
  const openSchool = s => {
    setSlug(s);
    setRoute('school');
    window.scrollTo({
      top: 0
    });
  };
  let view;
  if (route === 'home') view = /*#__PURE__*/React.createElement(Home, {
    onNav: nav
  });else if (route === 'schools') view = /*#__PURE__*/React.createElement(SchoolsView, {
    onOpen: openSchool
  });else if (route === 'school') view = /*#__PURE__*/React.createElement(SchoolDetail, {
    slug: slug,
    onBack: () => nav('schools')
  });else if (route === 'people') view = /*#__PURE__*/React.createElement(People, {
    onNav: nav
  });else view = /*#__PURE__*/React.createElement(ComingSoon, {
    route: route
  });
  return /*#__PURE__*/React.createElement("div", {
    className: 'as-root' + (dark ? '' : ' as-light')
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-rain"
  }, dark && /*#__PURE__*/React.createElement(CodeRain, null)), /*#__PURE__*/React.createElement(Nav, {
    route: route,
    onNav: nav,
    dark: dark,
    onToggleTheme: () => setDark(d => !d)
  }), /*#__PURE__*/React.createElement("main", {
    className: "as-main"
  }, view), /*#__PURE__*/React.createElement(Footer, {
    onNav: nav
  }));
}

/* Demo mount — opt-in only. The compiled bundle is loaded by many pages that
   own their own #root, so this must never auto-mount there. The ui_kit's own
   demo HTML sets data-uikit-demo on its container. */
const appRoot = document.querySelector('#root[data-uikit-demo]');
if (appRoot) ReactDOM.createRoot(appRoot).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/chrome.jsx
try { (() => {
/* AstroStat Academy — UI kit: chrome (Nav, Footer, ThemeToggle) */

function ThemeToggle({
  dark,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "as-toggle",
    onClick: onToggle,
    "aria-label": dark ? 'Switch to light mode' : 'Switch to dark mode'
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-toggle-knob",
    style: {
      transform: dark ? 'translateX(20px)' : 'translateX(0)'
    }
  }, dark ? '☾' : '☼'));
}
function Nav({
  route,
  onNav,
  dark,
  onToggleTheme
}) {
  const links = [{
    id: 'schools',
    label: 'Schools'
  }, {
    id: 'hackatons',
    label: 'Hackatons'
  }, {
    id: 'consulting',
    label: 'Consulting'
  }];
  const active = id => route === id || id === 'schools' && route === 'school';
  return /*#__PURE__*/React.createElement("nav", {
    className: "as-nav-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-nav"
  }, /*#__PURE__*/React.createElement("a", {
    className: "as-brand",
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('home');
    }
  }, /*#__PURE__*/React.createElement("img", {
    className: "as-brand-mark",
    src: dark ? '../../assets/logo-bone.svg' : '../../assets/logo.svg',
    alt: "",
    "aria-hidden": "true"
  }), "AstroStat Academy"), /*#__PURE__*/React.createElement("ul", {
    className: "as-nav-links"
  }, links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l.id
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav(l.id);
    },
    className: active(l.id) ? 'as-link as-link-active' : 'as-link'
  }, l.label))), /*#__PURE__*/React.createElement("li", {
    "aria-hidden": "true",
    className: "as-nav-sep"
  }), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(ThemeToggle, {
    dark: dark,
    onToggle: onToggleTheme
  })), /*#__PURE__*/React.createElement("li", {
    "aria-hidden": "true",
    className: "as-nav-sep"
  }), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('people');
    },
    className: route === 'people' ? 'as-link as-link-active' : 'as-link'
  }, "People")))));
}
function Footer({
  onNav
}) {
  return /*#__PURE__*/React.createElement("footer", {
    className: "as-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-footer-inner"
  }, /*#__PURE__*/React.createElement("p", null, "\xA9 ", new Date().getFullYear(), " AstroStat Academy. All rights reserved."), /*#__PURE__*/React.createElement("div", {
    className: "as-footer-links"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('schools');
    }
  }, "Schools"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('consulting');
    }
  }, "Consulting"))));
}
Object.assign(window, {
  Nav,
  Footer,
  ThemeToggle
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.jsx
try { (() => {
/* AstroStat Academy — UI kit: school content data
   Derived from academy-website-short/src/content/schools/*.md.
   Attendee counts are approximate (used by the attendance chart). */

window.SCHOOLS = [{
  slug: 'school-2019-heraklion',
  title: 'AstroStat School I — Heraklion 2019',
  date: '2019-07-08',
  endDate: '2019-07-19',
  location: 'Heraklion, Crete, Greece',
  description: 'The inaugural AstroStat School: two weeks of foundational statistical training for astronomers, hosted in Heraklion.',
  lecturers: [],
  topics: ['Statistical methods', 'Bayesian inference', 'Hypothesis testing'],
  attendees: 28,
  body: 'The first edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2022-heraklion',
  title: 'AstroStat School II — Heraklion 2022',
  date: '2022-07-04',
  endDate: '2022-07-15',
  location: 'Heraklion, Crete, Greece',
  description: 'The second edition of the AstroStat School, returning to Heraklion with an expanded machine-learning track.',
  lecturers: [],
  topics: ['Bayesian inference', 'Machine learning for astronomy', 'MCMC methods'],
  attendees: 41,
  body: 'The second edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2023-heraklion',
  title: 'AstroStat School III — Heraklion 2023',
  date: '2023-07-10',
  endDate: '2023-07-21',
  location: 'Heraklion, Crete, Greece',
  description: 'The third edition of the AstroStat School, with deep-learning and Gaussian-process tutorials added to the programme.',
  lecturers: [],
  topics: ['Deep Learning', 'Gaussian Processes', 'Bayesian inference', 'Time Series Analysis'],
  attendees: 47,
  body: 'The third edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2024-heraklion',
  title: 'AstroStat School IV — Heraklion 2024',
  date: '2024-07-01',
  location: 'Heraklion, Crete, Greece',
  description: 'The fourth edition of the AstroStat School, hosted in Heraklion.',
  lecturers: [],
  topics: ['Statistical methods', 'Bayesian inference', 'Machine learning for astronomy'],
  attendees: 52,
  body: 'The fourth edition of the AstroStat School, hosted in Heraklion.\n\n> Exact dates and full programme details to be filled in.'
}, {
  slug: 'school-2025-heraklion',
  title: 'AstroStat School V — Heraklion 2025',
  date: '2025-07-07',
  endDate: '2025-07-18',
  location: 'Heraklion, Crete, Greece',
  description: 'The fifth edition of the AstroStat School, with a new GPU-parallelization and deep-learning intensive.',
  lecturers: [],
  topics: ['Deep Learning', 'GPU Parallelization', 'Markov Chain Monte Carlo', 'Gaussian Processes'],
  attendees: 58,
  body: 'The fifth edition of the AstroStat School, hosted in Heraklion, Crete.'
}, {
  slug: 'school-2025-sharjah',
  title: 'AstroStat School VI — Sharjah 2025',
  date: '2025-11-17',
  endDate: '2025-11-21',
  location: 'Sharjah, United Arab Emirates',
  description: 'The sixth AstroStat School, the first hosted outside Europe, in partnership with the Sharjah Academy for Astronomy, Space Sciences & Technology.',
  lecturers: [],
  topics: ['Classical & Bayesian Statistics', 'Machine Learning Practices', 'Time Series Analysis'],
  attendees: 44,
  body: 'The sixth AstroStat School — and the first edition hosted outside Europe — held in Sharjah, UAE.'
}, {
  slug: 'school-2026-rome',
  title: 'AstroStat School VII — Rome 2026',
  date: '2026-07-27',
  endDate: '2026-07-31',
  location: 'DotCampus, Rome, Italy',
  description: 'The seventh AstroStat School, hosted at DotCampus in Rome. A week of intensive lectures and hands-on tutorials covering classical and Bayesian statistics, deep learning, Gaussian processes, MCMC, and more.',
  lecturers: [{
    name: 'Dr. Paolo Bonfini',
    affiliation: 'UniversiData srl'
  }, {
    name: 'Dr. Konstantinos Kovlakas',
    affiliation: 'Institute of Space Sciences'
  }, {
    name: 'Dr. Grigoris Maravelias',
    affiliation: 'PeriAstron'
  }, {
    name: 'Andreas Tersenov',
    affiliation: 'FORTH & CEA Paris-Saclay'
  }, {
    name: 'Nikolas Vasilas',
    affiliation: 'Max Planck Institute for Extraterrestrial Physics'
  }, {
    name: 'Prof. Giorgos Vernardos',
    affiliation: 'Lehman College, CUNY'
  }],
  topics: ['Classical & Bayesian Statistics', 'AI Agents', 'Deep Learning', 'Gaussian Processes', 'Markov Chain Monte Carlo', 'Machine Learning Practices', 'Time Series Analysis', 'GPU Parallelization'],
  applicationUrl: '#apply',
  body: 'The seventh AstroStat School will be held from **27–31 July 2026** at **DotCampus, Rome**. The programme covers classical and Bayesian statistics, AI agents, deep learning, Gaussian processes, MCMC, machine-learning practices, time-series analysis, and GPU parallelization.\n\n## Detailed Schedule\n\nTo be announced.'
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/effects.jsx
try { (() => {
/* AstroStat Academy — UI kit: generative effects
   CodeRain (full-bleed background), Typewriter (rotating taglines),
   HeroStat (the interactive Gaussian-histogram / time-series hero widget).
   Simplified, cosmetic recreations of the site's canvas effects.        */

const RAIN_CHARS = 'αβγδεζηθικλμνξπρστφχψωΛΦΨΩΣ∑∏∫∮∂∇∆√∛∝∞≈≅≠≡≤≥±∓×÷∀∃∈∉⊂⊃⊆∪∩∅∴∵⊕⊗⊙ℓℏℝℕ☉★✦0123456789';
const RED_RGB = '140, 5, 39';
const BLUE_RGB = '4, 101, 173';

/* ── Full-page falling code rain (crimson, translucent) ─────────────── */
function CodeRain() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const FONT = 16,
      FRAME = 110;
    let columns = 0,
      drops = [],
      raf = 0,
      last = 0;
    const init = () => {
      const w = canvas.parentElement.clientWidth;
      const h = canvas.parentElement.clientHeight;
      canvas.width = w;
      canvas.height = h;
      columns = Math.floor(w / FONT);
      drops = Array.from({
        length: columns
      }, () => Math.random() * h / FONT);
    };
    const tick = now => {
      raf = requestAnimationFrame(tick);
      if (now - last < FRAME) return;
      last = now;
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = FONT + 'px ui-monospace, monospace';
      ctx.textBaseline = 'top';
      for (let i = 0; i < columns; i++) {
        ctx.fillStyle = `rgba(${RED_RGB}, 0.5)`;
        ctx.fillText(RAIN_CHARS[Math.random() * RAIN_CHARS.length | 0], i * FONT, drops[i] * FONT);
        if (drops[i] * FONT > canvas.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
      }
    };
    init();
    raf = requestAnimationFrame(tick);
    window.addEventListener('resize', init);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', init);
    };
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none'
    }
  });
}

/* ── Typewriter rotating taglines with blinking block cursor ─────────── */
function Typewriter({
  phrases
}) {
  const [text, setText] = React.useState('');
  const [del, setDel] = React.useState(false);
  const [idx, setIdx] = React.useState(0);
  const [cur, setCur] = React.useState(true);
  React.useEffect(() => {
    const id = setInterval(() => setCur(c => !c), 530);
    return () => clearInterval(id);
  }, []);
  React.useEffect(() => {
    const phrase = phrases[idx % phrases.length];
    let t;
    if (!del) {
      if (text.length < phrase.length) t = setTimeout(() => setText(phrase.slice(0, text.length + 1)), 72 * (0.6 + Math.random() * 0.8));else t = setTimeout(() => setDel(true), 2200);
    } else {
      if (text.length > 0) t = setTimeout(() => setText(text.slice(0, -1)), 28);else t = setTimeout(() => {
        setDel(false);
        setIdx(i => i + 1);
      }, 380);
    }
    return () => clearTimeout(t);
  }, [text, del, idx, phrases]);
  return /*#__PURE__*/React.createElement("span", null, text, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      opacity: cur ? 1 : 0
    }
  }, "\u2588"));
}

/* ── Interactive hero histogram — drag the blue dot (mean) / grips (σ) ── */
function HeroStat() {
  const ref = React.useRef(null);
  const state = React.useRef({
    mean: 0.5,
    sigma: 0.18,
    drag: 'none'
  });
  React.useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    const W = 400,
      H = 150,
      BASE = 120;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.scale(dpr, dpr);
    let raf = 0,
      last = 0;
    const draw = now => {
      raf = requestAnimationFrame(draw);
      if (now - last < 90) return;
      last = now;
      ctx.clearRect(0, 0, W, H);
      const {
        mean,
        sigma
      } = state.current;
      const cols = 26,
        bw = W / cols,
        amp = BASE * 0.92;
      const wig = now / 900;
      for (let k = 0; k < cols; k++) {
        const xf = (k + 0.5) / cols;
        const g = Math.exp(-0.5 * ((xf - mean) / Math.max(sigma, 0.01)) ** 2);
        const bh = Math.max(0, g * amp + Math.sin(wig + k * 0.73) * 4 * g);
        ctx.fillStyle = `rgba(${BLUE_RGB}, 0.30)`;
        ctx.fillRect(k * bw + 1.5, BASE - bh + 2, bw - 1, bh);
        ctx.fillStyle = `rgba(${RED_RGB}, ${0.55 + g * 0.35})`;
        ctx.fillRect(k * bw + 0.5, BASE - bh, bw - 1, bh);
      }
      // widget: pill + mean dot + grips
      const mx = mean * W,
        half = sigma * W;
      const lx = Math.max(8, mx - half),
        rx = Math.min(W - 8, mx + half);
      const py = BASE + 16,
        pulse = 0.5 + 0.5 * Math.sin(now / 2000 * Math.PI * 2);
      ctx.strokeStyle = `rgba(${BLUE_RGB}, 0.45)`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(lx, py - 3, rx - lx, 6, 3);
      ctx.stroke();
      const grip = x => {
        ctx.save();
        ctx.shadowColor = `rgba(${BLUE_RGB},0.5)`;
        ctx.shadowBlur = 3 + pulse * 4;
        ctx.fillStyle = `rgba(${BLUE_RGB}, ${0.65 + pulse * 0.1})`;
        ctx.beginPath();
        ctx.roundRect(x - 3, py - 8, 6, 16, 3);
        ctx.fill();
        ctx.restore();
      };
      grip(lx);
      grip(rx);
      ctx.save();
      ctx.shadowColor = `rgba(${BLUE_RGB},0.5)`;
      ctx.shadowBlur = 3 + pulse * 4;
      ctx.fillStyle = `rgba(${BLUE_RGB}, ${0.65 + pulse * 0.1})`;
      ctx.beginPath();
      ctx.arc(mx, py, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };
    raf = requestAnimationFrame(draw);
    const pos = e => {
      const r = canvas.getBoundingClientRect();
      return {
        x: e.clientX - r.left,
        y: e.clientY - r.top
      };
    };
    const down = e => {
      const {
        x
      } = pos(e);
      const {
        mean,
        sigma
      } = state.current;
      const mx = mean * W,
        lx = mx - sigma * W,
        rx = mx + sigma * W;
      if (Math.abs(x - mx) < 12) state.current.drag = 'move';else if (Math.abs(x - lx) < 10 || Math.abs(x - rx) < 10) state.current.drag = 'sigma';
      canvas.setPointerCapture(e.pointerId);
    };
    const move = e => {
      const {
        x
      } = pos(e);
      const d = state.current.drag;
      if (d === 'move') state.current.mean = Math.max(0.05, Math.min(0.95, x / W));else if (d === 'sigma') state.current.sigma = Math.max(0.05, Math.min(0.4, Math.abs(x - state.current.mean * W) / W));
      canvas.style.cursor = d !== 'none' ? 'grabbing' : 'grab';
    };
    const up = () => {
      state.current.drag = 'none';
      canvas.style.cursor = 'grab';
    };
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointermove', move);
    canvas.addEventListener('pointerup', up);
    return () => cancelAnimationFrame(raf);
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    style: {
      cursor: 'grab',
      touchAction: 'none'
    },
    title: "Drag the mean & \u03C3"
  });
}
Object.assign(window, {
  CodeRain,
  Typewriter,
  HeroStat
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/effects.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/home.jsx
try { (() => {
/* AstroStat Academy — UI kit: home view (hero, hex honeycomb, mission cards) */

function SectionHead({
  eyebrow,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "as-section-head"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-blue"
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "as-section-title"
  }, title), children && /*#__PURE__*/React.createElement("p", {
    className: "as-section-sub"
  }, children));
}
function HexNav({
  onNav
}) {
  const items = [{
    id: 'schools',
    n: '01',
    label: 'Schools',
    soon: false,
    x: 0,
    y: 0,
    primary: true
  }, {
    id: 'hackatons',
    n: '02',
    label: 'Hackatons',
    soon: true,
    x: 173,
    y: 0
  }, {
    id: 'consulting',
    n: '03',
    label: 'Consulting',
    soon: true,
    x: 87,
    y: 150
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "as-hex-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-hex-grid"
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.id,
    href: "#",
    className: "as-hex",
    style: {
      left: it.x,
      top: it.y
    },
    onClick: e => {
      e.preventDefault();
      onNav(it.id);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: 'as-hex-face ' + (it.primary ? 'as-hex-primary' : 'as-hex-dim')
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-hex-inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "as-hex-num"
  }, it.n), /*#__PURE__*/React.createElement("span", {
    className: it.primary ? 'as-hex-label' : 'as-hex-label as-hex-label-dim'
  }, it.label), it.soon && /*#__PURE__*/React.createElement("span", {
    className: "as-hex-soon"
  }, "Soon"))))));
}
function FeatureCard({
  tone,
  eyebrow,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'as-feature as-feature-' + tone
  }, /*#__PURE__*/React.createElement("p", {
    className: 'as-eyebrow as-eyebrow-' + tone
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "as-feature-body"
  }, children));
}
function Home({
  onNav
}) {
  const taglines = ['Advanced statistics. Taught and applied.', 'High-level statistical training and expert consulting.', 'The statistics support you need. Taught and delivered.'];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    className: "as-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-hero-inner"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-hero-tagline"
  }, /*#__PURE__*/React.createElement(Typewriter, {
    phrases: taglines
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-hero-title-wrap"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "as-hero-title"
  }, "AstroStat", /*#__PURE__*/React.createElement("br", null), "Academy"), /*#__PURE__*/React.createElement("div", {
    className: "as-hero-stat"
  }, /*#__PURE__*/React.createElement(HeroStat, null))), /*#__PURE__*/React.createElement("p", {
    className: "as-hero-sub"
  }, "Take control of your statistics."))), /*#__PURE__*/React.createElement("section", {
    className: "as-what"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "What we do",
    title: "Three ways we work"
  }, "Hands-on schools today, with hackatons and enterprise consulting on the way."), /*#__PURE__*/React.createElement(HexNav, {
    onNav: onNav
  })), /*#__PURE__*/React.createElement("section", {
    className: "as-who"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-who-inner"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-red"
  }, "Who we are"), /*#__PURE__*/React.createElement("h2", {
    className: "as-section-title"
  }, "A collective of astronomers & statisticians"), /*#__PURE__*/React.createElement("p", {
    className: "as-who-body"
  }, "AstroStat Academy is run by working astronomers, statisticians, and machine-learning practitioners drawn from research institutes and universities across Europe and beyond. Between us we have taught seven schools and supervised hundreds of early-career researchers, spanning Bayesian inference, Gaussian processes, MCMC, deep learning, and large-survey data analysis. We teach the tools we use in our own research."), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "as-btn as-btn-ghost",
    onClick: e => {
      e.preventDefault();
      onNav('people');
    }
  }, "Meet our people \u2192"))), /*#__PURE__*/React.createElement("section", {
    className: "as-mission"
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "Why we exist",
    title: "Mission & Goals"
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-mission-grid"
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    tone: "blue",
    eyebrow: "01 \xB7 Mission",
    title: "Our Mission"
  }, "Astronomy generates petabytes of data. Making sense of it requires rigorous statistical thinking. AstroStat Academy bridges the gap between modern statistics and observational astronomy through hands-on, expert-led schools for PhD students and early-career researchers."), /*#__PURE__*/React.createElement(FeatureCard, {
    tone: "red",
    eyebrow: "02 \xB7 Goals",
    title: "Our Goals"
  }, "We aim to raise statistical literacy across the astronomical community \u2014 equipping researchers with the modern probabilistic and machine-learning tools they need to extract knowledge from today's large surveys and tomorrow's petabyte telescopes."))));
}
Object.assign(window, {
  HexNav,
  FeatureCard,
  Home
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/people.jsx
try { (() => {
/* AstroStat Academy — UI kit: People page
   Renders LIVE from the roster + per-person files under assets/people/:

       assets/people/people.yml          section -> ordered list of slugs
       assets/people/<role>/<slug>.md    front-matter (name, affiliation,
                                         title, photo, links) + bio body
       assets/people/<role>/<slug>.jpg   headshot (optional)

   To change the page, edit those files — NOT this component.
   Remove a slug from people.yml and the person drops off the page while
   their .md / .jpg stay on disk. */

const PEOPLE_BASE = '../../assets/people';

// Section labels + layout, keyed by the role folder name.
const ROLE_META = {
  councellors: {
    label: 'Councellors',
    wide: true
  },
  lecturers: {
    label: 'Lecturers',
    wide: false
  },
  TAs: {
    label: 'Teaching assistants',
    wide: false
  },
  advisors: {
    label: 'Advisors',
    wide: false
  }
};

/* ── tiny parsers (no deps) ─────────────────────────────────────── */

// people.yml -> [{ role, slugs: [..] }] in file order.
function parseRoster(text) {
  const sections = [];
  let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, ''); // strip comments
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) {
      cur = {
        role: sec[1],
        slugs: []
      };
      sections.push(cur);
      return;
    }
    const item = line.match(/^\s*-\s*(.+?)\s*$/);
    if (item && cur) cur.slugs.push(item[1]);
  });
  return sections;
}

// <slug>.md -> { name, affiliation, title, photo, links{}, bio }
function parsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = {
    links: {}
  };
  let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s+/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1],
        val = kv[2].trim();
      if (key === 'links' && val === '') {
        inLinks = true;
        return;
      }
      if (inLinks && indented) {
        meta.links[key] = val;
        return;
      }
      inLinks = false;
      meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}

/* ── avatar (photo with initials fallback) ──────────────────────── */

function initials(name) {
  const clean = name.replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '');
  const parts = clean.split(/\s+/);
  return (parts[0][0] + (parts[parts.length - 1][0] || '')).toUpperCase();
}
function toneFor(name) {
  const tones = ['#0465ad', '#8c0527', '#008c8c']; // blue / crimson / teal
  const sum = name.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  return tones[sum % tones.length];
}
function Avatar({
  person,
  size
}) {
  const tone = toneFor(person.name);
  const [failed, setFailed] = React.useState(false);
  const show = person.photoUrl && !failed;
  return /*#__PURE__*/React.createElement("span", {
    className: "as-avatar",
    style: {
      width: size,
      height: size,
      borderColor: tone,
      color: tone,
      fontSize: size * 0.34,
      overflow: 'hidden'
    }
  }, show ? /*#__PURE__*/React.createElement("img", {
    src: person.photoUrl,
    alt: person.name,
    width: size,
    height: size,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    },
    onError: () => setFailed(true)
  }) : initials(person.name));
}
function PersonCard({
  person,
  wide
}) {
  const linkEntries = Object.entries(person.links || {});
  return /*#__PURE__*/React.createElement("div", {
    className: wide ? 'as-person as-person-wide' : 'as-person'
  }, /*#__PURE__*/React.createElement(Avatar, {
    person: person,
    size: wide ? 56 : 64
  }), /*#__PURE__*/React.createElement("div", {
    className: "as-person-meta"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-person-name"
  }, person.name), person.affiliation && /*#__PURE__*/React.createElement("p", {
    className: "as-person-aff"
  }, person.affiliation), person.title && /*#__PURE__*/React.createElement("span", {
    className: "as-person-role"
  }, person.title), person.bio && /*#__PURE__*/React.createElement("p", {
    className: "as-person-bio"
  }, person.bio), linkEntries.length > 0 && /*#__PURE__*/React.createElement("p", {
    className: "as-person-links"
  }, linkEntries.map(([label, url]) => /*#__PURE__*/React.createElement("a", {
    key: label,
    className: "as-inline-link",
    href: url,
    target: "_blank",
    rel: "noreferrer"
  }, label, " \u2192")))));
}

/* ── data loading ───────────────────────────────────────────────── */

async function loadPeople() {
  const rosterText = await fetch(`${PEOPLE_BASE}/people.yml`).then(r => {
    if (!r.ok) throw new Error('people.yml not found');
    return r.text();
  });
  const roster = parseRoster(rosterText);
  const sections = await Promise.all(roster.map(async ({
    role,
    slugs
  }) => {
    const people = (await Promise.all(slugs.map(async slug => {
      try {
        const md = await fetch(`${PEOPLE_BASE}/${role}/${slug}.md`).then(r => {
          if (!r.ok) throw new Error(`${role}/${slug}.md missing`);
          return r.text();
        });
        const person = parsePerson(md);
        if (!person.name) person.name = slug;
        const photo = person.photo || `${slug}.jpg`;
        person.photoUrl = `${PEOPLE_BASE}/${role}/${photo}`;
        return person;
      } catch (e) {
        console.warn('[people]', e.message);
        return null;
      }
    }))).filter(Boolean);
    const meta = ROLE_META[role] || {
      label: role,
      wide: false
    };
    return {
      role,
      label: meta.label,
      wide: meta.wide,
      people
    };
  }));
  return sections.filter(s => s.people.length);
}

/* ── page ───────────────────────────────────────────────────────── */

function People({
  onNav
}) {
  const [sections, setSections] = React.useState(null);
  const [error, setError] = React.useState(null);
  React.useEffect(() => {
    loadPeople().then(setSections).catch(e => setError(e.message));
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-blue"
  }, "People"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1"
  }, "Our People"), /*#__PURE__*/React.createElement("p", {
    className: "as-lead"
  }, "AstroStat Academy is run by working astronomers, statisticians, and machine-learning practitioners drawn from research institutes and universities across Europe and beyond.")), error && /*#__PURE__*/React.createElement("p", {
    className: "as-note as-provisional"
  }, "Couldn't load the roster (", error, ")."), !error && sections === null && /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, "Loading people\u2026"), sections && sections.map(section => /*#__PURE__*/React.createElement("section", {
    className: "as-people-section",
    key: section.role
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, section.label), /*#__PURE__*/React.createElement("div", {
    className: `as-people-grid ${section.wide ? 'as-people-grid-2' : 'as-people-grid-3'}`
  }, section.people.map(p => /*#__PURE__*/React.createElement(PersonCard, {
    key: p.name,
    person: p,
    wide: section.wide
  }))))), /*#__PURE__*/React.createElement("section", {
    className: "as-people-cta"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, "Want to lecture at a future school, or collaborate?", ' ', /*#__PURE__*/React.createElement("a", {
    className: "as-inline-link",
    href: "mailto:info@astrostat.academy"
  }, "Get in touch"), ".")));
}
Object.assign(window, {
  People
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/people.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/schools.jsx
try { (() => {
/* AstroStat Academy — UI kit: schools listing, detail, chart, form, placeholders */

const fmtRange = (d, e) => {
  const o = {
    month: 'short',
    day: 'numeric'
  };
  const a = new Date(d),
    b = e ? new Date(e) : null;
  if (b) return `${a.toLocaleDateString('en-US', o)} – ${b.toLocaleDateString('en-US', {
    ...o,
    year: 'numeric'
  })}`;
  return a.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};
const isPast = s => new Date(s.endDate || s.date) < new Date();
function StatusBadge({
  school
}) {
  const past = isPast(school);
  return /*#__PURE__*/React.createElement("span", {
    className: past ? 'as-badge as-badge-past' : 'as-badge as-badge-upcoming'
  }, past ? 'Past' : 'Upcoming');
}
function SchoolCard({
  school,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "as-school-card",
    onClick: e => {
      e.preventDefault();
      onOpen(school.slug);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-school-top"
  }, /*#__PURE__*/React.createElement(StatusBadge, {
    school: school
  }), /*#__PURE__*/React.createElement("span", {
    className: "as-school-date"
  }, new Date(school.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short'
  }))), /*#__PURE__*/React.createElement("h3", {
    className: "as-school-title"
  }, school.title), /*#__PURE__*/React.createElement("p", {
    className: "as-school-loc"
  }, school.location), /*#__PURE__*/React.createElement("p", {
    className: "as-school-desc"
  }, school.description), /*#__PURE__*/React.createElement("div", {
    className: "as-chips"
  }, school.topics.slice(0, 3).map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip"
  }, t)), school.topics.length > 3 && /*#__PURE__*/React.createElement("span", {
    className: "as-chip-more"
  }, "+", school.topics.length - 3, " more")), school.attendees && /*#__PURE__*/React.createElement("p", {
    className: "as-school-att"
  }, school.attendees, " attendees"));
}
function SchoolsView({
  onOpen
}) {
  const all = window.SCHOOLS;
  const [year, setYear] = React.useState('all');
  const [topic, setTopic] = React.useState('all');
  const years = ['all', ...Array.from(new Set(all.map(s => new Date(s.date).getFullYear().toString()))).sort().reverse()];
  const topics = ['all', ...Array.from(new Set(all.flatMap(s => s.topics))).sort()];
  const filtered = all.filter(s => year === 'all' || new Date(s.date).getFullYear().toString() === year).filter(s => topic === 'all' || s.topics.includes(topic)).sort((a, b) => new Date(b.date) - new Date(a.date));
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-panel"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-eyebrow as-eyebrow-blue"
  }, "Training"), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1"
  }, "Schools & Workshops"), /*#__PURE__*/React.createElement("p", {
    className: "as-lead"
  }, "Intensive statistical training for the astronomical community.")), /*#__PURE__*/React.createElement("div", {
    className: "as-filters"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, /*#__PURE__*/React.createElement("label", null, "Year"), /*#__PURE__*/React.createElement("select", {
    value: year,
    onChange: e => setYear(e.target.value)
  }, years.map(y => /*#__PURE__*/React.createElement("option", {
    key: y,
    value: y
  }, y === 'all' ? 'All years' : y)))), /*#__PURE__*/React.createElement("div", {
    className: "as-field"
  }, /*#__PURE__*/React.createElement("label", null, "Topic"), /*#__PURE__*/React.createElement("select", {
    value: topic,
    onChange: e => setTopic(e.target.value)
  }, topics.map(t => /*#__PURE__*/React.createElement("option", {
    key: t,
    value: t
  }, t === 'all' ? 'All topics' : t))))), /*#__PURE__*/React.createElement("p", {
    className: "as-count"
  }, filtered.length, " school", filtered.length !== 1 ? 's' : '', " found"), filtered.length === 0 ? /*#__PURE__*/React.createElement("p", {
    className: "as-empty"
  }, "No schools match your filters.") : /*#__PURE__*/React.createElement("div", {
    className: "as-school-grid"
  }, filtered.map(s => /*#__PURE__*/React.createElement(SchoolCard, {
    key: s.slug,
    school: s,
    onOpen: onOpen
  }))));
}

/* Simple SVG bar chart (cosmetic stand-in for the Plotly attendance chart) */
function AttendanceChart({
  highlight
}) {
  const data = window.SCHOOLS.filter(s => s.attendees).sort((a, b) => new Date(a.date) - new Date(b.date));
  const max = Math.max(...data.map(s => s.attendees));
  const W = 760,
    H = 300,
    pad = 44,
    gap = 0.35;
  const bw = (W - pad * 2) / data.length;
  return /*#__PURE__*/React.createElement("div", {
    className: "as-chart"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${W} ${H}`,
    width: "100%",
    preserveAspectRatio: "xMidYMid meet"
  }, [0, 0.25, 0.5, 0.75, 1].map(t => {
    const y = pad + (H - pad * 1.4) * (1 - t);
    return /*#__PURE__*/React.createElement("g", {
      key: t
    }, /*#__PURE__*/React.createElement("line", {
      x1: pad,
      y1: y,
      x2: W - pad / 2,
      y2: y,
      stroke: "rgba(255,255,255,0.10)"
    }), /*#__PURE__*/React.createElement("text", {
      x: pad - 8,
      y: y + 4,
      textAnchor: "end",
      fontSize: "11",
      fill: "rgba(251,246,236,0.55)"
    }, Math.round(max * t)));
  }), data.map((s, i) => {
    const bh = s.attendees / max * (H - pad * 1.4);
    const x = pad + i * bw + bw * gap / 2;
    const w = bw * (1 - gap);
    const hi = s.title === highlight;
    return /*#__PURE__*/React.createElement("g", {
      key: s.slug
    }, /*#__PURE__*/React.createElement("rect", {
      x: x,
      y: H - pad * 0.4 - bh,
      width: w,
      height: bh,
      rx: "3",
      fill: hi ? '#8c0527' : '#0465ad',
      opacity: "0.9"
    }, /*#__PURE__*/React.createElement("title", null, s.title, ": ", s.attendees, " attendees")), /*#__PURE__*/React.createElement("text", {
      x: x + w / 2,
      y: H - pad * 0.4 + 16,
      textAnchor: "middle",
      fontSize: "11",
      fill: "rgba(251,246,236,0.55)"
    }, new Date(s.date).toLocaleDateString('en-US', {
      month: 'short',
      year: 'numeric'
    })));
  })));
}
function ApplicationForm({
  schoolTitle
}) {
  const [sent, setSent] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const submit = e => {
    e.preventDefault();
    setBusy(true);
    setTimeout(() => {
      setBusy(false);
      setSent(true);
    }, 800);
  };
  if (sent) return /*#__PURE__*/React.createElement("div", {
    className: "as-form as-form-done"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-form-thanks"
  }, "Thank you!"), /*#__PURE__*/React.createElement("p", {
    className: "as-form-thanks-sub"
  }, "We've noted your interest in ", /*#__PURE__*/React.createElement("strong", null, schoolTitle), ". We'll be in touch."));
  return /*#__PURE__*/React.createElement("form", {
    className: "as-form",
    onSubmit: submit,
    noValidate: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Full name *"), /*#__PURE__*/React.createElement("input", {
    required: true,
    placeholder: "Jane Smith"
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Email address *"), /*#__PURE__*/React.createElement("input", {
    required: true,
    type: "email",
    placeholder: "jane@university.edu"
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Institution"), /*#__PURE__*/React.createElement("input", {
    placeholder: "University or research institute"
  })), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Career stage"), /*#__PURE__*/React.createElement("select", {
    defaultValue: ""
  }, /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, "Select\u2026"), /*#__PURE__*/React.createElement("option", null, "PhD student"), /*#__PURE__*/React.createElement("option", null, "Postdoctoral researcher"), /*#__PURE__*/React.createElement("option", null, "Faculty / staff scientist"), /*#__PURE__*/React.createElement("option", null, "Industry"), /*#__PURE__*/React.createElement("option", null, "Other"))), /*#__PURE__*/React.createElement("div", {
    className: "as-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "Message (optional)"), /*#__PURE__*/React.createElement("textarea", {
    rows: "3",
    placeholder: "Any questions or context you'd like to share\u2026"
  })), /*#__PURE__*/React.createElement("button", {
    className: "as-btn as-btn-primary as-btn-block",
    disabled: busy
  }, busy ? 'Sending…' : 'Submit Interest'));
}
function SchoolDetail({
  slug,
  onBack
}) {
  const s = window.SCHOOLS.find(x => x.slug === slug);
  if (!s) return null;
  const past = isPast(s);
  const html = s.body.replace(/^## (.*)$/gm, '<h2 class="as-prose-h2">$1</h2>').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/^> (.*)$/gm, '<blockquote class="as-prose-quote">$1</blockquote>').split('\n\n').map(p => p.startsWith('<') ? p : `<p>${p}</p>`).join('');
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "as-detail-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "as-detail-head-inner"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "as-btn as-btn-outline",
    onClick: e => {
      e.preventDefault();
      onBack();
    }
  }, "\u2190 All schools"), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '20px 0 14px'
    }
  }, /*#__PURE__*/React.createElement(StatusBadge, {
    school: s
  })), /*#__PURE__*/React.createElement("h1", {
    className: "as-detail-title"
  }, s.title), /*#__PURE__*/React.createElement("div", {
    className: "as-detail-meta"
  }, /*#__PURE__*/React.createElement("span", null, fmtRange(s.date, s.endDate)), /*#__PURE__*/React.createElement("span", null, s.location), s.attendees && /*#__PURE__*/React.createElement("span", null, s.attendees, " attendees")), s.applicationUrl && !past && /*#__PURE__*/React.createElement("a", {
    href: "#apply",
    className: "as-btn as-btn-primary",
    style: {
      marginTop: 24
    },
    onClick: e => {
      e.preventDefault();
      document.getElementById('as-apply').scrollIntoView({
        behavior: 'smooth'
      });
    }
  }, "Apply Now"))), /*#__PURE__*/React.createElement("div", {
    className: "as-detail-body"
  }, /*#__PURE__*/React.createElement("section", {
    className: "as-prose",
    dangerouslySetInnerHTML: {
      __html: html
    }
  }), s.lecturers.length > 0 && /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Lecturers"), /*#__PURE__*/React.createElement("div", {
    className: "as-lecturers"
  }, s.lecturers.map(l => /*#__PURE__*/React.createElement("div", {
    key: l.name,
    className: "as-lecturer"
  }, /*#__PURE__*/React.createElement("p", {
    className: "as-lecturer-name"
  }, l.name), l.affiliation && /*#__PURE__*/React.createElement("p", {
    className: "as-lecturer-aff"
  }, l.affiliation))))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Topics"), /*#__PURE__*/React.createElement("div", {
    className: "as-chips"
  }, s.topics.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    className: "as-chip as-chip-lg"
  }, t)))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Attendance History"), /*#__PURE__*/React.createElement(AttendanceChart, {
    highlight: s.title
  }), /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, "Highlighted bar = this school. All attendee counts are approximate.")), /*#__PURE__*/React.createElement("section", {
    id: "as-apply"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "as-h2"
  }, "Express Interest"), /*#__PURE__*/React.createElement("p", {
    className: "as-note",
    style: {
      marginBottom: 20
    }
  }, past ? 'Interested in future editions? Leave your details and we\'ll notify you.' : 'Not ready to apply? Leave your contact details and we\'ll keep you posted.'), /*#__PURE__*/React.createElement(ApplicationForm, {
    schoolTitle: s.title
  }))));
}
function ComingSoon({
  route
}) {
  const map = {
    hackatons: {
      tone: 'teal',
      eyebrow: 'Hackatons',
      title: 'Hackatons',
      body: 'Our first hackaton is in the works. Stay tuned for details.',
      email: 'info@astrostat.academy',
      q: 'Want to get involved?'
    },
    consulting: {
      tone: 'red',
      eyebrow: 'Consulting',
      title: 'Enterprise Consulting',
      body: 'Tailored statistical consulting for research groups, institutes, and space agencies. We help teams design analyses, choose models, and interpret results — coming soon.',
      email: 'consulting@astrostat.academy',
      q: 'Interested in working with us?'
    },
    people: {
      tone: 'blue',
      eyebrow: 'People',
      title: 'Our People',
      body: 'Our team of astronomers and statisticians will be listed here soon.',
      email: 'info@astrostat.academy',
      q: 'In the meantime, reach us at'
    }
  };
  const c = map[route];
  return /*#__PURE__*/React.createElement("div", {
    className: "as-page as-page-narrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'as-feature as-feature-' + c.tone,
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: 'as-eyebrow as-eyebrow-' + c.tone
  }, c.eyebrow), /*#__PURE__*/React.createElement("h1", {
    className: "as-h1",
    style: {
      marginBottom: 16
    }
  }, c.title), /*#__PURE__*/React.createElement("p", {
    className: "as-lead",
    style: {
      marginBottom: 20
    }
  }, c.body), /*#__PURE__*/React.createElement("p", {
    className: "as-note"
  }, c.q, " ", /*#__PURE__*/React.createElement("a", {
    className: "as-inline-link",
    href: 'mailto:' + c.email
  }, route === 'people' ? c.email : 'Get in touch'), ".")));
}
Object.assign(window, {
  SchoolsView,
  SchoolDetail,
  ComingSoon
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/schools.jsx", error: String((e && e.message) || e) }); }

__ds_ns.PageHeader = __ds_scope.PageHeader;

})();
