---
name: astrostat-academy-design
description: Use this skill to generate well-branded interfaces and assets for AstroStat Academy — statistics & machine-learning schools for astronomers — either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation

- `README.md` — brand context, content fundamentals, visual foundations, iconography, manifest.
- `colors_and_type.css` — import first; CSS variables for the palette (blue `#0465ad`, crimson `#8c0527`, bone `#fbf6ec`, ink `#000`, teal `#008c8c`), type scale (Inter + system mono), radii, brand-tinted shadows, spacing, gradients.
- `assets/` — brand assets (`favicon.svg` telescope mark).
- `preview/` — small spec cards (colours, type, spacing, components, brand).
- `ui_kits/website/` — interactive recreation of the marketing site; reusable JSX components.

## House rules (do not violate)

- **Dark-first.** Pure-black canvas, warm bone text, brand-tinted soft shadows (never neutral grey). A light theme on bone exists.
- **Tiny palette.** Blue = actions/links; crimson = the data motif (histograms, the falling code-rain glyphs, errors); teal = rare tertiary (hackatons). Use opacity tiers of bone for hierarchy.
- **Type:** Inter (400–700) for UI; monospace for eyebrows, taglines, decorative counters, and code-rain glyphs.
- **Motifs:** pill-shaped nav/buttons/badges, `rounded-2xl/3xl` gradient cards, hexagon honeycomb, oversized mono counters, generative statistical canvas (Gaussian/time-series), Greek + maths glyphs as iconography.
- **No emoji, no stock photography, no hand-drawn SVG illustration.** Iconography is typographic (→ ← ☾ ☼) + maths symbols.
- **Voice:** "we" (org) / "you" (reader); sentence-case headings; UPPERCASE number-prefixed eyebrows ("01 · MISSION"); Roman numerals for school editions; em-dashes; no hype.
