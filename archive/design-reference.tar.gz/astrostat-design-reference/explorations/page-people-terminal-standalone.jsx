/* People page — "personnel terminal" interaction study.
   A retro CRT television (Alien / Nostromo MU-TH-UR style) renders a person's
   dossier — visual ID + field of interest — when their name is clicked.

   Three placement options on the canvas, exploring WHERE the screen lives:
     1. DOCKED      — terminal permanently on the right; click loads the file.
     2. POWER-ON    — roster full width; click powers a CRT panel on over it.
     3. MU-TH-UR    — click takes over the whole frame as a fullscreen readout.

   Data loads LIVE from assets/people/ (same source as the other previews).
   Depends on styles.css (kit CSS layers) + site-kit.jsx (SiteNav, SiteFooter, Corners) +
   design-canvas.jsx. Self-contained data layer (tp* helpers). */

/* ── data ─────────────────────────────────────────────────────────────── */
const TP_BASE = '../assets/people';
const TP_ROLE = {
  councellors: 'Councellor',
  advisors:    'Advisory board',
  lecturers:   'Lecturer',
  TAs:         'Teaching assistant',
};
const TP_ORDER = ['councellors', 'advisors', 'lecturers', 'TAs'];

/* ── INLINED DATA (standalone build) ──────────────────────────────────────
   Mirror of assets/people/people.yml + each <role>/<slug>.md, embedded so the
   page works offline with no fetch(). Photos resolve via window.__resources
   (see the ext-resource-dependency meta tags in the HTML head). */
const TP_PHOTO_RES = {
  'councellors/paolo-bonfini': 'ph_paolo',
  'councellors/konstantinos-kovlakas': 'ph_kostas',
  'councellors/grigoris-maravelias': 'ph_grigoris',
  'councellors/andreas-tersenov': 'ph_andreas',
  'councellors/giorgos-vernardos': 'ph_giorgos',
  'advisors/nikolas-vasilas': 'ph_nikolas',
};
const TP_ROSTER = {
  councellors: ['paolo-bonfini', 'konstantinos-kovlakas', 'grigoris-maravelias', 'andreas-tersenov', 'giorgos-vernardos'],
  lecturers: [],
  TAs: [],
  advisors: ['nikolas-vasilas'],
};
const TP_MD = {
  'councellors/paolo-bonfini': `---
name: Dr. Paolo Bonfini
affiliation: UniversiData srl
title: Treasurer & Website Maintainer
photo: paolo-bonfini.jpg
links:
  linkedin: www.linkedin.com/in/paolo-bonfini-phd-085a6a179
---
Data Scientist and Research Engineer specializing in Artificial Intelligence in the corporate sector, with expertise in model selection and optimization.

Prior experience in Bioinformatics and over 10 years in Astrophysics, including a PhD completed in 2013, with specialization in galaxy morphology and evolution.`,
  'councellors/konstantinos-kovlakas': `---
name: Dr. Konstantinos Kovlakas
affiliation: Institute of Space Sciences (ICE-CSIC)
title: Data Analyst
photo: konstantinos-kovlakas.jpg
---
Binary populations and Bayesian inference. Shapes the statistical curriculum across editions.`,
  'councellors/grigoris-maravelias': `---
name: Dr. Grigoris Maravelias
affiliation: PeriAstron / IA-FORTH
title: Chair
photo: grigoris-maravelias.png
---
Massive stars and classification; leads community outreach and partner relations.`,
  'councellors/andreas-tersenov': `---
name: Andreas Tersenov
affiliation: FORTH & CEA Paris-Saclay
title: AI Workflow Architect
photo: andreas-tersenov.png
---
Weak gravitational lensing and machine-learning pipelines for cosmological inference.`,
  'councellors/giorgos-vernardos': `---
name: Prof. Giorgos Vernardos
affiliation: Lehman College, CUNY
title: Secretary
photo: giorgos-vernardos.png
---
Strong gravitational lensing and Bayesian modelling of lensed quasars and galaxies.`,
  'advisors/nikolas-vasilas': `---
name: Nikolas Vasilas
affiliation: Max Planck Institute for Extraterrestrial Physics
title: Community & Alumni Manager
photo: nikolas-vasilas.jpg
---
Machine learning for large astronomical surveys and automated source classification.`,
};

function tpParseRoster(text) {
  const out = []; let cur = null;
  text.split(/\r?\n/).forEach(raw => {
    const line = raw.replace(/#.*$/, '');
    if (!line.trim()) return;
    const sec = line.match(/^([A-Za-z][\w-]*):\s*(\[\s*\])?\s*$/);
    if (sec) { cur = { role: sec[1], slugs: [] }; out.push(cur); return; }
    const it = line.match(/^\s*-\s*(.+?)\s*$/);
    if (it && cur) cur.slugs.push(it[1]);
  });
  return out;
}
function tpParsePerson(text) {
  const m = text.match(/^\s*---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  const meta = { links: {} }; let body = text;
  if (m) {
    body = m[2] || '';
    let inLinks = false;
    m[1].split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      const indented = /^\s/.test(line);
      const kv = line.match(/^\s*([\w-]+):\s*(.*)$/);
      if (!kv) return;
      const key = kv[1], val = kv[2].trim();
      if (key === 'links' && val === '') { inLinks = true; return; }
      if (inLinks && indented) { if (val) meta.links[key] = val; return; }
      inLinks = false;
      if (val !== '') meta[key] = val;
    });
  }
  meta.bio = body.trim();
  return meta;
}
async function tpLoad() {
  const flat = [];
  TP_ORDER.forEach(role => {
    (TP_ROSTER[role] || []).forEach((slug, i) => {
      const id = `${role}/${slug}`;
      const md = TP_MD[id];
      if (!md) { console.warn('[term] missing', id); return; }
      const p = tpParsePerson(md);
      const res = TP_PHOTO_RES[id];
      flat.push({
        id, roleKey: role, role: TP_ROLE[role] || role,
        name: p.name || slug, inst: p.affiliation || '', title: p.title || '',
        bio: p.bio || '', links: p.links || {},
        photoUrl: (res && window.__resources && window.__resources[res]) || '',
        order: TP_ORDER.indexOf(role) * 100 + i,
      });
    });
  });
  flat.sort((a, b) => a.order - b.order);
  return flat;
}

function tpInitials(name) {
  const c = String(name).replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return (c[0][0] + (c[c.length - 1][0] || '')).toUpperCase();
}
function tpSurname(name) {
  const c = String(name).replace(/^(Dr\.|Prof\.|Mr\.|Ms\.)\s+/i, '').split(/\s+/);
  return c[c.length - 1].toUpperCase();
}
function tpHex(id) {
  let h = 0; for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return ('0000' + (h & 0xffff).toString(16).toUpperCase()).slice(-4);
}

/* ── styles ───────────────────────────────────────────────────────────── */
const TERM_CSS = `
  :root { --ph:#9fd4f5; --ph-dim:rgba(159,212,245,.62); --ph-faint:rgba(159,212,245,.26); --ph-glow:rgba(59,155,224,.45); --rec:#c8607a; }

  /* roster (left / underneath) */
  .tp-roster { display:flex; flex-direction:column; gap:2px; }
  .tp-rgroup { display:grid; gap:2px 18px; }
  .tp-rgrp { font-family:ui-monospace,monospace; font-size:9.5px; letter-spacing:.2em; text-transform:uppercase; color:rgba(251,246,236,.34); margin:18px 0 7px; display:flex; align-items:center; gap:10px; }
  .tp-rgrp::after { content:""; flex:1; height:1px; background:rgba(251,246,236,.13); }
  .tp-item { display:flex; align-items:center; gap:12px; width:100%; text-align:left; background:transparent; border:1px solid transparent; border-bottom:1px solid rgba(251,246,236,.09); color:inherit; padding:9px 10px; cursor:pointer; transition:background .14s, border-color .14s; }
  .tp-item:hover { background:rgba(59,155,224,.07); }
  .tp-item.on { background:rgba(59,155,224,.12); border-color:rgba(59,155,224,.4); }
  .tp-idx { font-family:ui-monospace,monospace; font-size:10px; color:rgba(251,246,236,.32); width:26px; flex:none; }
  .tp-item.on .tp-idx { color:var(--ph); }
  .tp-nm { font-weight:600; font-size:14px; line-height:1.2; }
  .tp-af { font-family:ui-monospace,monospace; font-size:10.5px; color:rgba(251,246,236,.45); margin-top:3px; }
  .tp-go { margin-left:auto; font-family:ui-monospace,monospace; font-size:10px; letter-spacing:.12em; color:rgba(251,246,236,.28); flex:none; }
  .tp-item:hover .tp-go, .tp-item.on .tp-go { color:var(--ph); }

  /* CRT screen — flush instrument-panel readout (no plastic bezel) */
  .crt { position:relative; border:1px solid rgba(251,246,236,.22); background:rgba(255,255,255,.03); height:100%; display:flex; padding:1px; }
  .crt .as-c { z-index:9; }
  .crt-screen { position:relative; flex:1; min-height:0; overflow:hidden; background:radial-gradient(130% 130% at 50% 22%, #08161f 0%, #050d14 55%, #03080d 100%); }
  .crt-inner { position:absolute; inset:0; padding:22px 24px; color:var(--ph); font-family:ui-monospace,monospace; text-shadow:0 0 6px var(--ph-glow); overflow:hidden; }
  /* scanlines + sweep + flicker overlays (vignette removed for a flatter, integrated look) */
  .crt-scan { position:absolute; inset:0; pointer-events:none; background:repeating-linear-gradient(to bottom, rgba(0,0,0,0) 0 2px, rgba(0,0,0,.16) 2px 3.5px); z-index:4; }
  .crt-sweep { position:absolute; left:0; right:0; height:60px; pointer-events:none; z-index:5; background:linear-gradient(to bottom, rgba(159,212,245,0), rgba(159,212,245,.05) 55%, rgba(159,212,245,0)); animation:crtSweep 5.5s linear infinite; }
  .crt-vig { display:none; }
  .crt-flick { position:absolute; inset:0; pointer-events:none; z-index:7; background:rgba(159,212,245,.5); opacity:0; animation:crtFlick 7s steps(1) infinite; }
  @keyframes crtSweep { from{ transform:translateY(-70px);} to{ transform:translateY(560px);} }
  @keyframes crtFlick { 0%,97%,100%{opacity:0;} 97.5%{opacity:.05;} 98.5%{opacity:.02;} }
  @keyframes crtOn { 0%{ transform:scaleY(.004); filter:brightness(3); opacity:.2;} 45%{ transform:scaleY(.02); filter:brightness(2.4);} 70%{ transform:scaleY(1); filter:brightness(1.5);} 100%{ transform:scaleY(1); filter:brightness(1);} }
  .crt.power .crt-screen { animation:crtOn .42s ease-out both; }

  /* dossier */
  .dsr { position:absolute; inset:0; display:flex; flex-direction:column; padding:20px 24px; }
  .dsr-top { display:flex; justify-content:space-between; align-items:center; font-size:10.5px; letter-spacing:.18em; color:var(--ph-dim); border-bottom:1px solid var(--ph-faint); padding-bottom:9px; }
  .dsr-rec { display:flex; align-items:center; gap:7px; color:var(--rec); text-shadow:0 0 7px rgba(200,96,122,.5); }
  .dsr-rec i { width:7px; height:7px; border-radius:50%; background:var(--rec); display:inline-block; animation:blink 1.1s steps(1) infinite; }
  @keyframes blink { 50%{opacity:.15;} }
  .dsr-body { display:grid; grid-template-columns:150px 1fr; gap:20px; margin-top:18px; flex:1; min-height:0; }

  .tphoto { position:relative; aspect-ratio:1; border:1px solid var(--ph-faint); overflow:hidden; background:#050d14; }
  .tphoto img { width:100%; height:100%; object-fit:cover; filter:grayscale(1) sepia(1) hue-rotate(165deg) saturate(2.2) brightness(1.05) contrast(.95); opacity:.92; mix-blend-mode:screen; }
  .tphoto-lost { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:10px; }
  .tphoto-lost .tpi { font-size:46px; font-weight:700; color:var(--ph-dim); letter-spacing:.04em; }
  .tphoto-lost .tpl { font-size:8.5px; letter-spacing:.18em; color:var(--ph-faint); }
  .tphoto-hold { position:absolute; left:0; right:0; height:14px; background:linear-gradient(rgba(159,212,245,.14),rgba(159,212,245,0)); animation:hold 3.2s linear infinite; }
  @keyframes hold { from{ transform:translateY(-16px);} to{ transform:translateY(170px);} }
  .tphoto-cap { position:absolute; bottom:0; left:0; right:0; font-size:8px; letter-spacing:.16em; color:var(--ph-dim); background:rgba(5,13,20,.72); padding:4px 6px; text-align:center; }

  .dsr-id { font-size:10px; letter-spacing:.16em; color:var(--ph-faint); }
  .dsr-name { font-size:30px; font-weight:700; line-height:1; letter-spacing:.01em; margin:7px 0 0; color:#eaf6ff; text-shadow:0 0 12px var(--ph-glow); }
  .dsr-role { font-size:11.5px; letter-spacing:.12em; text-transform:uppercase; color:var(--ph-dim); margin-top:9px; }
  .dsr-aff { font-size:12px; color:var(--ph-dim); margin-top:3px; }
  .dsr-field { margin-top:18px; }
  .dsr-field .lbl { font-size:9.5px; letter-spacing:.22em; color:var(--ph-faint); display:block; margin-bottom:7px; }
  .dsr-field p { font-size:14px; line-height:1.55; color:#cfe8fa; margin:0; max-width:42ch; white-space:pre-line; }
  .dsr-field .none { color:var(--ph-faint); font-size:12.5px; }
  .dsr-linkrow { display:flex; flex-wrap:wrap; gap:8px 18px; }
  .dsr-link { font-family:ui-monospace,monospace; font-size:11px; letter-spacing:.1em; color:var(--ph); text-decoration:none; border-bottom:1px solid var(--ph-faint); padding-bottom:2px; transition:color .14s, border-color .14s; }
  .dsr-link:hover { color:#eaf6ff; border-color:var(--ph); }
  .dsr-foot { margin-top:auto; padding-top:12px; border-top:1px solid var(--ph-faint); display:flex; justify-content:space-between; align-items:center; gap:14px; font-size:10px; letter-spacing:.1em; color:var(--ph-faint); }
  .dsr-hint { color:var(--ph-dim); animation:blink 2.4s steps(1) infinite; }
  .dsr-cur::after { content:"\u2588"; color:var(--ph); animation:blink 1s steps(1) infinite; margin-left:2px; }

  /* boot */
  .boot { position:absolute; inset:0; padding:22px 24px; color:var(--ph); font-family:ui-monospace,monospace; font-size:13px; line-height:1.9; background:#050d14; z-index:3; }
  .boot .bl { opacity:0; animation:bootIn .12s ease-out forwards; }
  .boot .ok { color:var(--rec); }
  @keyframes bootIn { from{ opacity:0; clip-path:inset(0 100% 0 0);} to{ opacity:1; clip-path:inset(0 0 0 0);} }
  .dsr-wrap { position:absolute; inset:0; }
  .dsr-wrap.show { animation:fadeUp .4s ease-out .04s both; }
  @keyframes fadeUp { from{opacity:0; transform:translateY(6px);} to{opacity:1; transform:translateY(0);} }

  /* standby */
  .stby { position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px; color:var(--ph-dim); font-family:ui-monospace,monospace; text-align:center; }
  .stby .big { font-size:13px; letter-spacing:.26em; }
  .stby .hint { font-size:11px; letter-spacing:.14em; color:var(--ph-faint); }
  .stby .ring { width:54px; height:54px; border:1px solid var(--ph-faint); border-top-color:var(--ph); border-radius:50%; animation:spin 1.5s linear infinite; }
  @keyframes spin { to{ transform:rotate(360deg);} }

  /* option 2 overlay panel */
  .tp-stage { position:relative; }
  .tp-panel { position:absolute; top:0; right:0; bottom:0; width:54%; z-index:20; filter:drop-shadow(-20px 0 50px rgba(0,0,0,.6)); }
  .tp-panel .crt { border-radius:12px 0 0 12px; }
  .tp-x { position:absolute; top:24px; right:26px; z-index:30; width:30px; height:30px; border:1px solid var(--ph-faint); background:rgba(2,18,12,.6); color:var(--ph); font-family:ui-monospace,monospace; cursor:pointer; border-radius:4px; }
  .tp-x:hover { background:rgba(59,155,224,.16); }

  /* option 3 fullscreen */
  .tp-full { position:absolute; inset:0; z-index:40; }
  .tp-full .crt { border-radius:0; border:0; }
  .tp-return { position:absolute; top:22px; left:24px; z-index:50; font-family:ui-monospace,monospace; font-size:11px; letter-spacing:.14em; color:var(--ph); background:rgba(2,18,12,.55); border:1px solid var(--ph-faint); padding:8px 14px; cursor:pointer; }
  .tp-return:hover { background:rgba(59,155,224,.14); }
  .dsr.big .dsr-body { grid-template-columns:220px 1fr; gap:34px; }
  .dsr.big .dsr-name { font-size:44px; }
  .dsr.big .dsr-field p { font-size:17px; max-width:48ch; }

  .tp-hint { font-family:ui-monospace,monospace; font-size:10.5px; letter-spacing:.12em; color:var(--ph-dim); border:1px solid var(--ph-faint); padding:6px 12px; display:inline-flex; align-items:center; gap:9px; }
  .tp-hint i { width:6px; height:6px; border-radius:50%; background:var(--ph); display:inline-block; box-shadow:0 0 8px var(--ph); }
`;
function TermCSS() { return <style>{TERM_CSS}</style>; }

/* ── visual id ────────────────────────────────────────────────────────── */
function TPhoto({ p }) {
  const [bad, setBad] = React.useState(false);
  const show = p.photoUrl && !bad;
  return (
    <div className="tphoto">
      {show
        ? <img src={p.photoUrl} alt={p.name} onError={() => setBad(true)} />
        : <div className="tphoto-lost"><span className="tpi">{tpInitials(p.name)}</span><span className="tpl">NO VISUAL · ARCHIVE</span></div>}
      <div className="tphoto-hold"></div>
      <div className="tphoto-cap">VISUAL ID // {tpHex(p.id)}</div>
    </div>
  );
}

/* ── dossier (boot → file) ────────────────────────────────────────────── */
function Dossier({ p, big, power, closable }) {
  const [phase, setPhase] = React.useState('boot');
  React.useEffect(() => {
    setPhase('boot');
    const t = setTimeout(() => setPhase('show'), 620);
    return () => clearTimeout(t);
  }, [p.id]);

  const bootLines = [
    `> QUERY PERSONNEL :: ${tpSurname(p.name)}`,
    '> UPLINK ASTROSTAT-NET ........ OK',
    '> DECRYPT DOSSIER 0x' + tpHex(p.id) + ' .... OK',
    '> RENDER VISUAL ID',
  ];

  return (
    <div className={'crt' + (power ? ' power' : '')}>
      <span className="as-c as-tl"></span><span className="as-c as-tr"></span>
      <span className="as-c as-bl"></span><span className="as-c as-br"></span>
      <div className="crt-screen">
        <div className="crt-inner">
          {phase === 'boot' && (
            <div className="boot">
              {bootLines.map((l, i) => (
                <div key={i} className="bl" style={{ animationDelay: `${i * 0.12}s` }}>
                  {l.replace(/OK$/, '')}{/OK$/.test(l) && <span className="ok">OK</span>}
                </div>
              ))}
            </div>
          )}
          <div className={'dsr-wrap' + (phase === 'show' ? ' show' : '')}>
            <div className={'dsr' + (big ? ' big' : '')}>
              <div className="dsr-top">
                <span>{big ? 'MU-TH-UR 6000 // PERSONNEL FILE' : 'PERSONNEL FILE // ASTROSTAT-NET'}</span>
                <span className="dsr-rec"><i></i> REC</span>
              </div>
              <div className="dsr-body">
                <TPhoto p={p} />
                <div>
                  <div className="dsr-id">FILE 0x{tpHex(p.id)} — CLEARANCE 3</div>
                  <h3 className="dsr-name">{p.name}</h3>
                  <div className="dsr-role">{p.role}{p.title ? ` · ${p.title}` : ''}</div>
                  <div className="dsr-aff">{p.inst}</div>
                  <div className="dsr-field">
                    <span className="lbl">FIELD OF INTEREST</span>
                    {p.bio ? <p>{p.bio}</p> : <p className="none">// no record on file</p>}
                  </div>
                  {p.links && Object.keys(p.links).length > 0 && (
                    <div className="dsr-field dsr-links">
                      <span className="lbl">UPLINK</span>
                      <div className="dsr-linkrow">
                        {Object.entries(p.links).map(([k, v]) => {
                          const href = /^https?:\/\//.test(v) ? v : `https://${v}`;
                          return <a key={k} className="dsr-link" href={href} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>▸ {k.toUpperCase()}</a>;
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="dsr-foot">
                <span>STATUS: ACTIVE · NODE ASX-{tpHex(p.id).slice(0, 2)}</span>
                {closable && <span className="dsr-hint">◄ CLICK SCREEN TO CLOSE</span>}
                <span className="dsr-cur">READY</span>
              </div>
            </div>
          </div>
        </div>
        <div className="crt-sweep"></div>
        <div className="crt-scan"></div>
        <div className="crt-vig"></div>
        <div className="crt-flick"></div>
      </div>
    </div>
  );
}

function Standby() {
  return (
    <div className="crt">
      <span className="as-c as-tl"></span><span className="as-c as-tr"></span>
      <span className="as-c as-bl"></span><span className="as-c as-br"></span>
      <div className="crt-screen">
        <div className="crt-inner">
          <div className="stby">
            <div className="ring"></div>
            <div className="big">ASTROSTAT-NET // STANDBY</div>
            <div className="hint">◄ SELECT PERSONNEL TO OPEN FILE</div>
          </div>
        </div>
        <div className="crt-sweep"></div>
        <div className="crt-scan"></div>
        <div className="crt-vig"></div>
        <div className="crt-flick"></div>
      </div>
    </div>
  );
}

/* ── shared roster ────────────────────────────────────────────────────── */
function Roster({ people, selId, onSelect, cols = 1 }) {
  const groups = [];
  people.forEach((p, i) => {
    let g = groups.find(x => x.role === p.roleKey);
    if (!g) { g = { role: p.roleKey, label: p.role, items: [] }; groups.push(g); }
    g.items.push({ ...p, n: i + 1 });
  });
  return (
    <div className="tp-roster">
      {groups.map(g => (
        <React.Fragment key={g.role}>
          <div className="tp-rgrp">{g.label}</div>
          <div className="tp-rgroup" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))` }}>
            {g.items.map(p => (
              <button key={p.id} className={'tp-item' + (p.id === selId ? ' on' : '')} onClick={(e) => { e.stopPropagation(); onSelect(p.id); }}>
                <span className="tp-idx">{String(p.n).padStart(2, '0')}</span>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div className="tp-nm">{p.name}</div>
                  <div className="tp-af">{p.title || p.role}</div>
                </div>
                <span className="tp-go">OPEN ▸</span>
              </button>
            ))}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}

function useRoster() {
  const [people, setPeople] = React.useState(null);
  React.useEffect(() => { tpLoad().then(setPeople).catch(e => { console.warn(e); setPeople([]); }); }, []);
  return people;
}

function TermShell({ children }) {
  return (
    <div className="as-page">
      <TermCSS />
      <SiteNav active="people" />
      <div className="as-wrap">
        <div className="as-panel"><Corners />
          {children}
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}

function TermHead({ tag }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
      <div>
        <span className="as-eyebrow">The collective</span>
        <h1 className="as-h1pg" style={{ marginTop: 10 }}>Personnel<br />terminal</h1>
      </div>
      {tag && <span className="tp-hint"><i></i>{tag}</span>}
    </div>
  );
}

/* ════════════════ OPTION 1 — DOCKED (always on the right) ════════════════ */
function OptDocked() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  React.useEffect(() => { if (people && people.length && sel == null) setSel(people[0].id); }, [people]);
  const p = people && people.find(x => x.id === sel);
  return (
    <TermShell>
      <TermHead tag="DOCKED · ALWAYS ON" />
      <p className="as-p" style={{ marginTop: 14, maxWidth: 520 }}>The screen lives on the right at all times. Selecting a name re-tunes it to that file.</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.08fr', gap: 26, marginTop: 22, alignItems: 'stretch', minHeight: 0 }}>
        <div style={{ minWidth: 0, maxHeight: 520, overflow: 'auto', paddingRight: 6 }}>
          {people === null ? <p className="pp-inst">// loading…</p> : <Roster people={people} selId={sel} onSelect={setSel} />}
        </div>
        <div style={{ minHeight: 520 }}>
          {p ? <Dossier p={p} /> : <Standby />}
        </div>
      </div>
    </TermShell>
  );
}

/* ════════════════ OPTION 2 — POWER-ON (boots in on click) ════════════════ */
function OptPowerOn() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return (
    <TermShell>
      <TermHead tag="POWER-ON · ENTERS ON CLICK" />
      <p className="as-p" style={{ marginTop: 14, maxWidth: 520 }}>The roster runs full width. Clicking a name powers a CRT panel on over it; dismiss to power down.</p>
      <div className="tp-stage" style={{ marginTop: 22, minHeight: 540 }}>
        <div style={{ maxWidth: 560 }}>
          {people === null ? <p className="pp-inst">// loading…</p> : <Roster people={people} selId={sel} onSelect={setSel} />}
        </div>
        {p && (
          <div className="tp-panel" style={{ height: 540 }}>
            <Dossier p={p} power key={p.id} />
            <button className="tp-x" onClick={() => setSel(null)} title="Power off">✕</button>
          </div>
        )}
        {!p && (
          <div style={{ position: 'absolute', top: 0, right: 0, height: 540, width: '54%', display: 'grid', placeItems: 'center', border: '1px dashed rgba(59,155,224,.22)' }}>
            <span className="tp-hint"><i></i>SCREEN OFF — SELECT A NAME</span>
          </div>
        )}
      </div>
    </TermShell>
  );
}

/* ════════════════ OPTION 3 — MU-TH-UR (fullscreen takeover) ═══════════════ */
function OptFullscreen() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return (
    <TermShell>
      <TermHead tag="MU-TH-UR · FULLSCREEN" />
      <p className="as-p" style={{ marginTop: 14, maxWidth: 520 }}>Clicking a name hands the whole frame to the terminal — a full readout. Return to the roster to browse on.</p>
      <div className="tp-stage" style={{ marginTop: 22, minHeight: 560 }}>
        <div>
          {people === null ? <p className="pp-inst">// loading…</p> : <Roster people={people} selId={sel} onSelect={setSel} cols={2} />}
        </div>
        {p && (
          <div className="tp-full">
            <Dossier p={p} big power key={p.id} />
            <button className="tp-return" onClick={() => setSel(null)}>◄ RETURN TO ROSTER</button>
          </div>
        )}
      </div>
    </TermShell>
  );
}

/* ════════ OPTION — ALWAYS-ON CONSOLE (docked right + 2-col roster) ════════
   The terminal is permanently docked on the right in STANDBY; the roster keeps
   the full left width as two columns. Selecting a name opens that file on the
   ever-present screen. Best-of-both: the "computer" feel without the cramp. */
function OptConsole() {
  const people = useRoster();
  const [sel, setSel] = React.useState(null);
  const p = people && people.find(x => x.id === sel);
  return (
    <TermShell>
      <div onClick={() => p && setSel(null)}>
        <TermHead />
        <p className="as-p" style={{ marginTop: 14, maxWidth: 560 }}>The terminal stays docked on the right in standby. The roster runs two columns; selecting a name opens that file on the ever-present screen.</p>
        <div style={{ display: 'grid', gridTemplateColumns: '0.92fr 1.12fr', gap: 26, marginTop: 22, alignItems: 'stretch' }}>
          <div style={{ minWidth: 0 }}>
            {people === null ? <p className="pp-inst">// loading…</p> : <Roster people={people} selId={sel} onSelect={setSel} cols={2} />}
          </div>
          <div style={{ minHeight: 600, position: 'sticky', top: 16 }} onClick={(e) => e.stopPropagation()}>
            {p ? <Dossier p={p} key={p.id} /> : <Standby />}
          </div>
        </div>
      </div>
    </TermShell>
  );
}

Object.assign(window, { OptConsole, OptDocked, OptPowerOn, OptFullscreen });
