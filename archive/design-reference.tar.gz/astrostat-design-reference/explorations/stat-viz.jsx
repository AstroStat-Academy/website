/* Statistics-themed animated visuals for filling the rail-band void.
   Each is sized to sit on the right of a rail body (~260×150). Brand colours only.
   Exposed on window at the end for the Babel-scope sharing rule. */

const VIZ_BLUE = '#3b9be0';
const VIZ_BLUEDIM = 'rgba(59,155,224,.9)';
const VIZ_RED = '#c8607a';
const vizColor = (accent) => (accent === 'red' ? VIZ_RED : VIZ_BLUE);

function useTick(ms, deps = []) {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setT(v => v + 1), ms);
    return () => clearInterval(id);
  }, deps);
  return t;
}

/* 1 — Live histogram: bars resample toward a bell shape, heights ease each tick */
function VizHistogram({ accent, w = 260, h = 150 }) {
  const c = vizColor(accent);
  const n = 13;
  const target = React.useRef([...Array(n)].map((_, i) => {
    const x = (i - (n - 1) / 2) / 3;
    return Math.exp(-x * x / 2);
  }));
  const [hgt, setHgt] = React.useState(() => target.current.map(() => 0.1));
  useTick(140, []);
  React.useEffect(() => {
    const id = setInterval(() => {
      setHgt(prev => prev.map((v, i) => {
        const jitter = target.current[i] * (0.75 + Math.random() * 0.5);
        return v + (jitter - v) * 0.25;
      }));
    }, 140);
    return () => clearInterval(id);
  }, []);
  const bw = w / n;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <line x1="0" y1={h - 12} x2={w} y2={h - 12} stroke="rgba(251,246,236,.2)" strokeWidth="1" />
      {hgt.map((v, i) => {
        const bh = Math.max(3, v * (h - 26));
        return <rect key={i} x={i * bw + 2} y={h - 12 - bh} width={bw - 4} height={bh} fill={c} opacity={0.35 + v * 0.5} />;
      })}
    </svg>
  );
}

/* 2 — Scatter + least-squares line: points jitter around a trend, line tracks them */
function VizScatter({ accent, w = 260, h = 150 }) {
  const c = vizColor(accent);
  const n = 22;
  const base = React.useRef([...Array(n)].map(() => ({ x: Math.random(), n1: Math.random(), n2: Math.random() })));
  const t = useTick(90, []);
  const pad = 12;
  const pts = base.current.map((p, i) => {
    const wobble = Math.sin(t / 8 + i) * 0.04 + (p.n1 - 0.5) * 0.16;
    const x = pad + p.x * (w - 2 * pad);
    const yv = 0.15 + p.x * 0.6 + wobble;
    const y = pad + yv * (h - 2 * pad);
    return { x, y };
  });
  const mx = pts.reduce((s, p) => s + p.x, 0) / n, my = pts.reduce((s, p) => s + p.y, 0) / n;
  let num = 0, den = 0;
  pts.forEach(p => { num += (p.x - mx) * (p.y - my); den += (p.x - mx) * (p.x - mx); });
  const slope = num / den, b = my - slope * mx;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <line x1={pad} y1={slope * pad + b} x2={w - pad} y2={slope * (w - pad) + b} stroke={c} strokeWidth="1.5" opacity="0.85" />
      {pts.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="2.6" fill={c} opacity="0.7" />)}
    </svg>
  );
}

/* 3 — Gaussian curve with a sliding shaded quantile area */
function VizBellCurve({ accent, w = 260, h = 150 }) {
  const c = vizColor(accent);
  const t = useTick(60, []);
  const pad = 12, span = w - 2 * pad, base = h - 16;
  const gauss = (x) => { const d = (x - 0.5) * 6; return Math.exp(-(d * d) / 2); };
  const path = [];
  for (let i = 0; i <= 60; i++) {
    const fx = i / 60, x = pad + fx * span, y = base - gauss(fx) * (h - 34);
    path.push(`${i === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  const cut = 0.5 + Math.sin(t / 30) * 0.32;
  const area = [`M${pad} ${base}`];
  for (let i = 0; i <= 60; i++) {
    const fx = i / 60; if (fx > cut) break;
    area.push(`L${(pad + fx * span).toFixed(1)} ${(base - gauss(fx) * (h - 34)).toFixed(1)}`);
  }
  area.push(`L${(pad + cut * span).toFixed(1)} ${base}Z`);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <line x1={pad} y1={base} x2={w - pad} y2={base} stroke="rgba(251,246,236,.2)" strokeWidth="1" />
      <path d={area.join(' ')} fill={c} opacity="0.22" />
      <path d={path.join(' ')} fill="none" stroke={c} strokeWidth="1.8" />
      <line x1={pad + cut * span} y1={base} x2={pad + cut * span} y2={base - gauss(cut) * (h - 34)} stroke={c} strokeWidth="1" opacity="0.7" />
    </svg>
  );
}

/* 4 — Random walk / live signal trace scrolling left */
function VizRandomWalk({ accent, w = 260, h = 150 }) {
  const c = vizColor(accent);
  const [pts, setPts] = React.useState(() => [...Array(40)].map(() => 0.5));
  React.useEffect(() => {
    const id = setInterval(() => {
      setPts(prev => {
        const last = prev[prev.length - 1];
        let nx = last + (Math.random() - 0.5) * 0.18;
        nx = Math.max(0.08, Math.min(0.92, nx));
        return [...prev.slice(1), nx];
      });
    }, 110);
    return () => clearInterval(id);
  }, []);
  const step = w / (pts.length - 1);
  const d = pts.map((v, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)} ${(v * (h - 20) + 10).toFixed(1)}`).join(' ');
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <line x1="0" y1={h / 2} x2={w} y2={h / 2} stroke="rgba(251,246,236,.14)" strokeWidth="1" strokeDasharray="3 4" />
      <path d={d} fill="none" stroke={c} strokeWidth="1.8" />
      <circle cx={w} cy={pts[pts.length - 1] * (h - 20) + 10} r="3" fill={c} />
    </svg>
  );
}

/* 5 — Convergence: running mean of noisy samples settling toward a line */
function VizConvergence({ accent, w = 260, h = 150 }) {
  const c = vizColor(accent);
  const [data, setData] = React.useState({ pts: [], mean: [] });
  React.useEffect(() => {
    let running = 0, k = 0;
    const id = setInterval(() => {
      setData(prev => {
        k++; const s = 0.5 + (Math.random() - 0.5) * (0.8 / Math.sqrt(k));
        running += s; const m = running / k;
        const pts = [...prev.pts, s].slice(-46), mean = [...prev.mean, m].slice(-46);
        if (k > 200) { running = 0; k = 0; return { pts: [], mean: [] }; }
        return { pts, mean };
      });
    }, 90);
    return () => clearInterval(id);
  }, []);
  const N = 46, step = w / (N - 1);
  const y = (v) => (1 - v) * (h - 20) + 10;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <line x1="0" y1={y(0.5)} x2={w} y2={y(0.5)} stroke="rgba(251,246,236,.2)" strokeWidth="1" strokeDasharray="3 4" />
      {data.pts.map((v, i) => <circle key={i} cx={i * step} cy={y(v)} r="1.8" fill={c} opacity="0.35" />)}
      <path d={data.mean.map((v, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)} ${y(v).toFixed(1)}`).join(' ')} fill="none" stroke={c} strokeWidth="1.8" />
    </svg>
  );
}

/* 6 — the original animated pixel matrix, enlarged */
function VizPixels({ accent, w = 260, h = 150 }) {
  const cols = 16, rows = Math.round(cols * h / w);
  const total = cols * rows;
  const c = vizColor(accent);
  const t = useTick(70, []);
  const active = t % total;
  const cw = w / cols;
  const cells = [];
  for (let i = 0; i < total; i++) {
    const dist = (active - i + total) % total;
    const op = dist === 0 ? 1 : dist === 1 ? 0.5 : dist === 2 ? 0.28 : dist === 3 ? 0.16 : 0.07;
    const cx = (i % cols) * cw, cy = Math.floor(i / cols) * cw;
    cells.push(<rect key={i} x={cx + 1} y={cy + 1} width={cw - 2} height={cw - 2} fill={c} opacity={op} />);
  }
  return <svg width={w} height={rows * cw} viewBox={`0 0 ${w} ${rows * cw}`}>{cells}</svg>;
}

Object.assign(window, { VizHistogram, VizScatter, VizBellCurve, VizRandomWalk, VizConvergence, VizPixels, VizTerminal });

/* Terminal — a fake LLM-on-a-Linux-shell streaming pseudo-statistical blather,
   typed out line by line with a blinking caret, then looping. */
function VizTerminal({ accent = 'red', w = 380, h = 210 }) {
  const c = vizColor(accent);
  const SCRIPT = [
    { t: 'in', s: '$ astro-llm "is my p-value significant?"' },
    { t: 'sys', s: '▸ loading posterior weights ........ ok' },
    { t: 'out', s: 'Fitting a hierarchical model to your' },
    { t: 'out', s: 'noise. Bootstrapping 10,000 resamples…' },
    { t: 'ok', s: '✓ p = 0.049 → "basically significant"' },
    { t: 'warn', s: '⚠ assumptions: not checked' },
    { t: 'warn', s: '⚠ multiple comparisons: ignored' },
    { t: 'out', s: 'Recommendation: ship it. Looks right.' },
    { t: 'in', s: '$ _' },
  ];
  const [ln, setLn] = React.useState(0);
  const [ch, setCh] = React.useState(0);
  React.useEffect(() => {
    const cur = SCRIPT[ln];
    if (!cur) { const r = setTimeout(() => { setLn(0); setCh(0); }, 2200); return () => clearTimeout(r); }
    if (ch < cur.s.length) { const id = setTimeout(() => setCh(ch + 1), 26); return () => clearTimeout(id); }
    const id = setTimeout(() => { setLn(ln + 1); setCh(0); }, cur.t === 'in' ? 420 : 240);
    return () => clearTimeout(id);
  }, [ln, ch]);
  const colorFor = (t) => t === 'in' ? '#fbf6ec' : t === 'ok' ? '#3fb9b9' : t === 'warn' ? c : t === 'sys' ? 'rgba(251,246,236,.45)' : 'rgba(251,246,236,.72)';
  const shown = SCRIPT.slice(0, ln);
  const typing = SCRIPT[ln];
  return (
    <div style={{ width: w, height: h, border: '1px solid rgba(251,246,236,.24)', background: '#040404', fontFamily: 'ui-monospace,monospace', fontSize: 12, lineHeight: 1.55, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 10px', borderBottom: '1px solid rgba(251,246,236,.16)' }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: c, opacity: .8 }}></span>
        <span style={{ fontSize: 10, letterSpacing: '.12em', textTransform: 'uppercase', color: 'rgba(251,246,236,.4)' }}>astro-llm — bash</span>
      </div>
      <div style={{ padding: '10px 12px', flex: 1, overflow: 'hidden' }}>
        {shown.map((l, i) => <div key={i} style={{ color: colorFor(l.t), whiteSpace: 'pre' }}>{l.s}</div>)}
        {typing && <div style={{ color: colorFor(typing.t), whiteSpace: 'pre' }}>{typing.s.slice(0, ch)}<span style={{ display: 'inline-block', width: 7, height: 13, background: c, verticalAlign: '-2px', animation: 'vtb 1s steps(1) infinite' }}></span></div>}
      </div>
      <style>{`@keyframes vtb{50%{opacity:0}}`}</style>
    </div>
  );
}
